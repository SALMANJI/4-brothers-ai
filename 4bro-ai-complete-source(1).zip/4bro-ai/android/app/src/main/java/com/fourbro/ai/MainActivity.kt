package com.fourbro.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.fourbro.ai.ui.assistant.AssistantTabsScreen
import com.fourbro.ai.ui.home.FourBroViewModel
import com.fourbro.ai.ui.home.HomeScreen
import com.fourbro.ai.ui.onboarding.OnboardingScreen
import com.fourbro.ai.ui.settings.SettingsAndPrivacyScreen
import com.fourbro.ai.ui.splash.SplashScreen
import com.fourbro.ai.ui.studio.StudioAndResearchScreen
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.FourBroTheme
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val viewModel: FourBroViewModel = viewModel()
            val darkTheme by viewModel.darkTheme.collectAsState()
            val onboardingDone by viewModel.onboardingDone.collectAsState()
            val banner by viewModel.statusBanner.collectAsState()

            var splashFinished by remember { mutableStateOf(false) }
            var currentNavTab by remember { mutableIntStateOf(0) }
            var assistantInitialTab by remember { mutableIntStateOf(0) }
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(banner) {
                banner?.let {
                    snackbarHostState.showSnackbar(it)
                    viewModel.clearBanner()
                }
            }

            FourBroTheme(darkTheme = darkTheme) {
                when {
                    !splashFinished -> {
                        SplashScreen(onFinished = { splashFinished = true })
                    }

                    !onboardingDone -> {
                        OnboardingScreen(
                            initialOwnerName = viewModel.prefs.ownerName,
                            initialLanguage = viewModel.prefs.preferredLanguage,
                            initialBackendUrl = viewModel.prefs.backendUrl,
                            onComplete = { name, lang, url ->
                                viewModel.completeOnboarding(name, lang, url)
                            }
                        )
                    }

                    else -> {
                        Scaffold(
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            bottomBar = {
                                NavigationBar(containerColor = PureBlackGlass) {
                                    val items = listOf(
                                        Triple(0, "Home", Icons.Default.Home),
                                        Triple(1, "Assistant", Icons.Default.Checklist),
                                        Triple(2, "Studios", Icons.Default.AutoAwesome),
                                        Triple(3, "Settings", Icons.Default.Settings)
                                    )
                                    items.forEach { (idx, label, icon) ->
                                        NavigationBarItem(
                                            selected = currentNavTab == idx,
                                            onClick = { currentNavTab = idx },
                                            icon = {
                                                Icon(
                                                    icon,
                                                    contentDescription = label,
                                                    tint = if (currentNavTab == idx) CyanGlow else TextSecondary
                                                )
                                            },
                                            label = {
                                                Text(
                                                    label,
                                                    color = if (currentNavTab == idx) CyanGlow else TextSecondary
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        ) { innerPadding ->
                            Box(modifier = Modifier.padding(innerPadding)) {
                                when (currentNavTab) {
                                    0 -> HomeScreen(
                                        viewModel = viewModel,
                                        onOpenSettings = { currentNavTab = 3 },
                                        onOpenNotificationsTab = {
                                            assistantInitialTab = 1
                                            currentNavTab = 1
                                        }
                                    )
                                    1 -> AssistantTabsScreen(viewModel, initialTab = assistantInitialTab)
                                    2 -> StudioAndResearchScreen(viewModel)
                                    else -> SettingsAndPrivacyScreen(viewModel)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

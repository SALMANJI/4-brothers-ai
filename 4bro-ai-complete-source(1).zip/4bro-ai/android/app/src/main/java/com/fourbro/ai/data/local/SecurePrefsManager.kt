package com.fourbro.ai.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePrefsManager(context: Context) {
    private val prefs: SharedPreferences = createPrefs(context)

    private fun createPrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "fourbro_secure_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Exception) {
            // Safe fallback if hardware keystore unavailable on emulator/legacy ROM
            context.getSharedPreferences("fourbro_prefs_fallback", Context.MODE_PRIVATE)
        }
    }

    var onboardingCompleted: Boolean
        get() = prefs.getBoolean("onboarding_completed", false)
        set(value) = prefs.edit().putBoolean("onboarding_completed", value).apply()

    var ownerName: String
        get() = prefs.getString("owner_name", "Dost") ?: "Dost"
        set(value) = prefs.edit().putString("owner_name", value).apply()

    var preferredLanguage: String
        get() = prefs.getString("preferred_language", "roman_ur") ?: "roman_ur"
        set(value) = prefs.edit().putString("preferred_language", value).apply()

    var backendUrl: String
        get() = prefs.getString("backend_url", "") ?: ""
        set(value) = prefs.edit().putString("backend_url", value.trim().trimEnd('/')).apply()

    var deviceToken: String
        get() = prefs.getString("device_token", "") ?: ""
        set(value) = prefs.edit().putString("device_token", value.trim()).apply()

    var voiceSpeed: Float
        get() = prefs.getFloat("voice_speed", 1.0f)
        set(value) = prefs.edit().putFloat("voice_speed", value.coerceIn(0.7f, 1.5f)).apply()

    var voiceVolume: Float
        get() = prefs.getFloat("voice_volume", 1.0f)
        set(value) = prefs.edit().putFloat("voice_volume", value.coerceIn(0.1f, 1.0f)).apply()

    var voiceMuted: Boolean
        get() = prefs.getBoolean("voice_muted", false)
        set(value) = prefs.edit().putBoolean("voice_muted", value).apply()

    var darkTheme: Boolean
        get() = prefs.getBoolean("dark_theme", true)
        set(value) = prefs.edit().putBoolean("dark_theme", value).apply()

    var overlayX: Int
        get() = prefs.getInt("overlay_x", 24)
        set(value) = prefs.edit().putInt("overlay_x", value).apply()

    var overlayY: Int
        get() = prefs.getInt("overlay_y", 260)
        set(value) = prefs.edit().putInt("overlay_y", value).apply()

    var handsFreeEnabled: Boolean
        get() = prefs.getBoolean("hands_free_enabled", false)
        set(value) = prefs.edit().putBoolean("hands_free_enabled", value).apply()

    var customPersonality: String
        get() = prefs.getString("custom_personality", "") ?: ""
        set(value) = prefs.edit().putString("custom_personality", value.trim()).apply()

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}

package com.fourbro.ai.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface FourBroApiService {
    @GET("/health")
    suspend fun health(): Response<HealthResponseDto>

    @POST("/api/v1/chat")
    suspend fun chat(@Body request: ChatRequestDto): Response<ChatResponseDto>

    @POST("/api/v1/chat/tool-result")
    suspend fun reportToolResult(@Body request: ToolResultRequestDto): Response<Map<String, Any>>

    @POST("/api/v1/speech/transcribe")
    suspend fun transcribe(@Body request: TranscribeRequestDto): Response<TranscribeResponseDto>

    @POST("/api/v1/speech/synthesize")
    suspend fun synthesize(@Body request: SynthesizeRequestDto): Response<SynthesizeResponseDto>

    @POST("/api/v1/research/search")
    suspend fun research(@Body request: ResearchRequestDto): Response<ResearchResponseDto>

    @POST("/api/v1/content/youtube")
    suspend fun generateYouTube(@Body request: YouTubeRequestDto): Response<YouTubeResponseDto>

    @POST("/api/v1/content/facebook")
    suspend fun generateFacebook(@Body request: FacebookRequestDto): Response<FacebookResponseDto>
}

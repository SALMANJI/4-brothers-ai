package com.fourbro.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val FourBroDarkScheme = darkColorScheme(
    primary = CyanGlow,
    onPrimary = PureBlackGlass,
    secondary = SoftBlueGlow,
    onSecondary = NavyDeep,
    tertiary = RoyalBlueAccent,
    background = NavyDeep,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = ErrorCrimson
)

private val FourBroLightScheme = lightColorScheme(
    primary = RoyalBlueAccent,
    onPrimary = TextPrimary,
    secondary = CyanGlow,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    onSurfaceVariant = LightTextSecondary,
    error = ErrorCrimson
)

@Composable
fun FourBroTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) FourBroDarkScheme else FourBroLightScheme

    MaterialTheme(
        colorScheme = colors,
        typography = FourBroTypography,
        content = content
    )
}

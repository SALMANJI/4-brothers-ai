package com.fourbro.ai.automation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

data class AutomationResult(
    val success: Boolean,
    val message: String
)

object SafeAutomationManager {

    fun executeIntentAction(context: Context, action: String, target: String): AutomationResult {
        return when (action.uppercase()) {
            "COPY_CLIPBOARD" -> {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    ?: return AutomationResult(false, "Clipboard service unavailable.")
                clipboard.setPrimaryClip(ClipData.newPlainText("4BRO AI", target))
                AutomationResult(true, "Text clipboard par copy ho gaya hai.")
            }

            "SHARE_TEXT" -> {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, target)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(sendIntent, "4BRO AI Share").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                AutomationResult(true, "Android Share Sheet khul gaya hai.")
            }

            "OPEN_URL" -> {
                if (!target.startsWith("https://") && !target.startsWith("http://")) {
                    return AutomationResult(false, "Sirf safe http/https links hi khol sakte hain.")
                }
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(target)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
                AutomationResult(true, "Link browser mein khol diya gaya hai.")
            }

            "OPEN_APP" -> {
                val launch = context.packageManager.getLaunchIntentForPackage(target)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    AutomationResult(true, "App khol di gayi hai.")
                } else {
                    AutomationResult(false, "Yeh app ($target) phone par install nahi mili.")
                }
            }

            "OPEN_SETTINGS" -> {
                val settingsAction = when (target.lowercase()) {
                    "overlay" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION
                    } else {
                        Settings.ACTION_SETTINGS
                    }
                    "alarm" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
                    } else {
                        Settings.ACTION_SETTINGS
                    }
                    "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    else -> Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                }
                val intent = Intent(settingsAction).apply {
                    if (settingsAction == Settings.ACTION_MANAGE_OVERLAY_PERMISSION ||
                        settingsAction == Settings.ACTION_APPLICATION_DETAILS_SETTINGS ||
                        settingsAction == Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
                    ) {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    if (settingsAction == Settings.ACTION_APP_NOTIFICATION_SETTINGS) {
                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                AutomationResult(true, "Settings page khol diya gaya hai.")
            }

            else -> AutomationResult(false, "Unsupported safe action: $action")
        }
    }
}

package com.fourbro.ai.ui.home

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.fourbro.ai.config.FourBroEditableConfig
import com.fourbro.ai.ui.mascot.FourBroRobotMascot
import com.fourbro.ai.ui.mascot.RobotState
import com.fourbro.ai.ui.theme.BorderSubtle
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.ErrorCrimson
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavyElevated
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.RoyalBlueAccent
import com.fourbro.ai.ui.theme.SuccessEmerald
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary
import com.fourbro.ai.ui.theme.WarningAmber

@Composable
fun HomeScreen(
    viewModel: FourBroViewModel,
    onOpenSettings: () -> Unit,
    onOpenNotificationsTab: () -> Unit
) {
    val context = LocalContext.current
    val messages by viewModel.currentMessages.collectAsState()
    val sessions by viewModel.sessionIds.collectAsState()
    val reminders by viewModel.reminders.collectAsState()
    val connection by viewModel.connectionStatus.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val robotState by viewModel.robotState.collectAsState()
    val isListening by viewModel.voiceController.isListening.collectAsState()
    val isSpeaking by viewModel.voiceController.isSpeaking.collectAsState()
    val micAmplitude by viewModel.voiceController.amplitude.collectAsState()
    val pendingConfirm by viewModel.pendingConfirmation.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var voiceModeMuted by remember { mutableStateOf(viewModel.prefs.voiceMuted) }

    val upcomingCount = reminders.count { it.status == "SCHEDULED" && it.triggerAtMillis > System.currentTimeMillis() }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.voiceController.startListening(
                languageCode = viewModel.prefs.preferredLanguage,
                onResult = { spoken -> viewModel.sendMessage(spoken) },
                onError = { err -> viewModel.sendMessage("Voice error: $err") }
            )
        }
    }

    fun triggerVoiceInput() {
        if (isListening) {
            viewModel.voiceController.stopListening()
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            viewModel.voiceController.startListening(
                languageCode = viewModel.prefs.preferredLanguage,
                onResult = { spoken -> viewModel.sendMessage(spoken) },
                onError = { _ -> }
            )
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
    ) {
        // 1. Top Bar: 4BRO AI Logo + Connection Status + Notifications + History + Profile + Settings
        Surface(color = PureBlackGlass, tonalElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(NavyElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("4B", color = CyanGlow, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = FourBroEditableConfig.APP_TITLE,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.ExtraBold
                        )
                        val dotColor = when (connection) {
                            ConnectionStatus.Connected -> SuccessEmerald
                            ConnectionStatus.WakingUp -> WarningAmber
                            ConnectionStatus.AuthError -> ErrorCrimson
                            else -> TextSecondary
                        }
                        Text(
                            text = "● ${connection.label}",
                            style = MaterialTheme.typography.labelMedium,
                            color = dotColor,
                            modifier = Modifier.clickable { viewModel.pingBackendHealth() }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showHistoryDialog = true }) {
                        Icon(Icons.Default.History, contentDescription = "History", tint = TextPrimary)
                    }
                    IconButton(onClick = onOpenNotificationsTab) {
                        BadgedBox(
                            badge = {
                                if (upcomingCount > 0) {
                                    Badge { Text(upcomingCount.toString()) }
                                }
                            }
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = "Reminders", tint = TextPrimary)
                        }
                    }
                    IconButton(onClick = { showProfileDialog = true }) {
                        Icon(Icons.Default.Person, contentDescription = "Profile & Privacy", tint = TextPrimary)
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = CyanGlow)
                    }
                }
            }
        }

        if (isProcessing) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = CyanGlow,
                trackColor = NavySurface
            )
        }

        // 2. Robot Mascot + Greeting + Voice Controls
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = NavySurface),
            border = BorderStroke(1.dp, BorderSubtle),
            shape = RoundedCornerShape(18.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FourBroRobotMascot(
                    state = robotState,
                    size = 96.dp,
                    audioAmplitude = micAmplitude,
                    onTap = { triggerVoiceInput() }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = viewModel.getGreetingText(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        // Voice Mode Mute/Unmute
                        AssistChip(
                            onClick = {
                                voiceModeMuted = !voiceModeMuted
                                viewModel.prefs.voiceMuted = voiceModeMuted
                                if (voiceModeMuted) viewModel.voiceController.stopSpeaking()
                            },
                            label = { Text(if (voiceModeMuted) "Muted" else "Voice On") },
                            leadingIcon = {
                                Icon(
                                    if (voiceModeMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = NavyElevated,
                                labelColor = CyanGlow,
                                leadingIconContentColor = CyanGlow
                            )
                        )
                        // Interrupt or Repeat
                        if (isSpeaking) {
                            AssistChip(
                                onClick = { viewModel.voiceController.stopSpeaking() },
                                label = { Text("Stop") },
                                leadingIcon = {
                                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = NavyElevated,
                                    labelColor = ErrorCrimson,
                                    leadingIconContentColor = ErrorCrimson
                                )
                            )
                        } else {
                            AssistChip(
                                onClick = { viewModel.repeatLastVoice() },
                                label = { Text("Repeat") },
                                leadingIcon = {
                                    Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(16.dp))
                                },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = NavyElevated,
                                    labelColor = TextPrimary,
                                    leadingIconContentColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // 3. Quick Actions Strip (Editable from FourBroEditableConfig)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(FourBroEditableConfig.DEFAULT_QUICK_ACTIONS) { (label, command) ->
                AssistChip(
                    onClick = { viewModel.sendMessage(command) },
                    label = { Text(label) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = NavyElevated,
                        labelColor = CyanGlow
                    ),
                    border = BorderStroke(1.dp, BorderSubtle)
                )
            }
        }

        // 4. Chat History Feed
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NavySurface),
                        border = BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Misal commands:", color = CyanGlow, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("• \"4BRO, Waqas se lene wale 5000 note karo\"", color = TextSecondary)
                            Text("• \"4BRO, mujhe kal subah 9 baje yaad dilana\"", color = TextSecondary)
                            Text("• \"4BRO, meri YouTube Shorts ki script bana do\"", color = TextSecondary)
                        }
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "user"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = if (isUser) RoyalBlueAccent else NavySurface,
                        shape = RoundedCornerShape(
                            topStart = 16.dp,
                            topEnd = 16.dp,
                            bottomStart = if (isUser) 16.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 16.dp
                        ),
                        border = if (isUser) null else BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth(0.86f)
                    ) {
                        Text(
                            text = msg.text,
                            color = TextPrimary,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }

        // 5. Bottom Input Bar: Text Input + Send + Microphone Button
        Surface(color = PureBlackGlass) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Urdu, Roman Urdu ya English likhein...") },
                    modifier = Modifier.weight(1f),
                    maxLines = 3,
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            val toSend = inputText
                            inputText = ""
                            viewModel.sendMessage(toSend)
                        }
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(NavyElevated)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = CyanGlow)
                }
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = { triggerVoiceInput() },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (isListening) ErrorCrimson else CyanGlow)
                ) {
                    Icon(
                        if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Microphone",
                        tint = PureBlackGlass
                    )
                }
            }
        }
    }

    // Confirmation Dialog for Sensitive Actions
    pendingConfirm?.let { (prompt, _) ->
        AlertDialog(
            onDismissRequest = { viewModel.confirmPendingActions(false) },
            title = { Text("Aapki Ijazat Chahiye") },
            text = { Text(prompt) },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmPendingActions(true) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass)
                ) {
                    Text("Haan, Karein")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.confirmPendingActions(false) }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Conversation History Dialog
    if (showHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showHistoryDialog = false },
            title = { Text("Conversation History") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            viewModel.startNewSession()
                            showHistoryDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+ Nayi Baat-Cheet Shuru Karein")
                    }
                    Text("Saved Sessions: ${sessions.size}", color = TextSecondary)
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistoryDialog = false }) { Text("Close") }
            }
        )
    }

    // Profile & Privacy Quick Summary Dialog
    if (showProfileDialog) {
        AlertDialog(
            onDismissRequest = { showProfileDialog = false },
            title = { Text("Profile & Privacy") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Owner: ${viewModel.prefs.ownerName}")
                    Text("Language: ${viewModel.prefs.preferredLanguage}")
                    Text("Local DB: Encrypted Room SQLite")
                    Text("PIN/OTP Policy: Kabhi store nahi hota.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showProfileDialog = false
                    onOpenSettings()
                }) { Text("Full Settings") }
            },
            dismissButton = {
                TextButton(onClick = { showProfileDialog = false }) { Text("OK") }
            }
        )
    }
}

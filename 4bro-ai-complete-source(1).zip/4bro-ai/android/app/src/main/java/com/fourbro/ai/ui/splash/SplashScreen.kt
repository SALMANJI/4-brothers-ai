package com.fourbro.ai.ui.splash

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fourbro.ai.ui.mascot.FourBroRobotMascot
import com.fourbro.ai.ui.mascot.RobotState
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onFinished: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    var robotState by remember { mutableStateOf(RobotState.Sleeping) }
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(550),
        label = "splashAlpha"
    )

    LaunchedEffect(Unit) {
        visible = true
        delay(350)
        robotState = RobotState.WakingUp
        delay(650)
        robotState = RobotState.Idle
        delay(650)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(NavyDeep, NavySurface, NavyDeep))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .alpha(alpha)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            FourBroRobotMascot(
                state = robotState,
                size = 180.dp
            )
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "4BRO AI",
                style = MaterialTheme.typography.headlineLarge,
                color = TextPrimary,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Aapka Apna Smart Dost",
                style = MaterialTheme.typography.titleMedium,
                color = CyanGlow
            )
            Spacer(modifier = Modifier.height(28.dp))
            LinearProgressIndicator(
                color = CyanGlow,
                trackColor = NavySurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Tayyari ho rahi hai...",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
        }
    }
}

package com.fourbro.ai.config

/**
 * =========================================================================
 * 4BRO AI — AAPKA APNA ASAN EDITABLE CONFIG FILE
 * =========================================================================
 * Aap is file ko apne phone par GitHub app ya Chrome mein "Edit (Pencil)"
 * daba kar asani se badal sakte hain. Sirf quotes ("...") ke andar text
 * badlein aur Commit dabayein — GitHub khud nayi APK bana dega!
 * (Aur zyada tar cheezein to app ke andar Settings se bhi seedha badal sakti hain!)
 */
object FourBroEditableConfig {

    // 1. App ka Title aur Tagline
    const val APP_TITLE = "4BRO AI"
    const val APP_TAGLINE = "Aapka Apna Smart Dost"

    // 2. Shuruati Greeting (Jab app khule)
    const val GREETING_ROMAN_URDU = "Assalam-o-Alaikum %s! Boliye aaj kya madad karoon?"
    const val GREETING_URDU = "السلام علیکم %s! بتائیے آج کیا مدد کروں؟"
    const val GREETING_ENGLISH = "Assalam-o-Alaikum %s! How can I help you today?"

    // 3. Default AI Personality Note (App ke Settings se bhi live badal sakte hain)
    const val DEFAULT_CUSTOM_PERSONALITY =
        "Friendly, respectful, natural Pakistani tone, helpful aur halka sa mazaahiya."

    // 4. Home Screen ke Quick Action Buttons (Label | Command jo AI ko jayegi)
    val DEFAULT_QUICK_ACTIONS = listOf(
        "New Note" to "Mera ek naya note save karo",
        "Reminder" to "Mujhe ek reminder set karna hai",
        "Udhaar/Hisaab" to "Mera aaj ka finance summary dikhao",
        "YT Script" to "Mujhe ek YouTube video ki script banwani hai",
        "Research" to "Aaj ke trending topics par research karo"
    )
}

package com.fourbro.ai.ui.assistant

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.fourbro.ai.data.local.FinanceCalculator
import com.fourbro.ai.ui.home.FourBroViewModel
import com.fourbro.ai.ui.theme.BorderSubtle
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.ErrorCrimson
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.SuccessEmerald
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary
import com.fourbro.ai.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AssistantTabsScreen(
    viewModel: FourBroViewModel,
    initialTab: Int = 0
) {
    var selectedTab by remember { mutableIntStateOf(initialTab) }
    val tabs = listOf("Notes", "Reminders", "Tasks", "Finance")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
    ) {
        TabRow(selectedTabIndex = selectedTab, containerColor = PureBlackGlass, contentColor = CyanGlow) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        when (selectedTab) {
            0 -> NotesSection(viewModel)
            1 -> RemindersSection(viewModel)
            2 -> TasksSection(viewModel)
            else -> FinanceSection(viewModel)
        }
    }
}

@Composable
private fun NotesSection(viewModel: FourBroViewModel) {
    val notes by viewModel.notes.collectAsState()
    var query by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }

    val filtered = notes.filter {
        query.isBlank() || it.title.contains(query, true) || it.content.contains(query, true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Naya Note Likhein", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Detail") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            if (title.isNotBlank() && content.isNotBlank()) {
                                viewModel.addOrUpdateNote(title = title.trim(), content = content.trim(), category = category.trim())
                                title = ""; content = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Note Save Karein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Notes Search Karein") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(filtered, key = { it.id }) { note ->
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${note.title} • [${note.category}]", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(note.content, color = TextSecondary)
                    }
                    IconButton(onClick = { viewModel.deleteNote(note.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorCrimson)
                    }
                }
            }
        }
    }
}

@Composable
private fun RemindersSection(viewModel: FourBroViewModel) {
    val reminders by viewModel.reminders.collectAsState()
    var title by remember { mutableStateOf("") }
    var minutesStr by remember { mutableStateOf("15") }
    val sdf = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.US) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Reminder Set Karein", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Kya yaad dilana hai?") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = minutesStr, onValueChange = { minutesStr = it }, label = { Text("Kitne minute baad? (e.g. 15)") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            val mins = minutesStr.toLongOrNull() ?: 15L
                            if (title.isNotBlank() && mins > 0) {
                                viewModel.addReminder(title.trim(), "", System.currentTimeMillis() + mins * 60_000L)
                                title = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Reminder Lagayein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        items(reminders, key = { it.id }) { rem ->
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(rem.title, color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("${sdf.format(Date(rem.triggerAtMillis))} • ${rem.status}", color = CyanGlow)
                    }
                    if (rem.status == "SCHEDULED") {
                        OutlinedButton(onClick = { viewModel.cancelReminder(rem.id) }) {
                            Text("Cancel", color = ErrorCrimson)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TasksSection(viewModel: FourBroViewModel) {
    val tasks by viewModel.tasks.collectAsState()
    var title by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("MEDIUM") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Naya Task Add Karein", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("LOW", "MEDIUM", "HIGH").forEach { p ->
                            OutlinedButton(
                                onClick = { priority = p },
                                border = BorderStroke(1.dp, if (priority == p) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(p, color = if (priority == p) CyanGlow else TextSecondary) }
                        }
                    }
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                viewModel.addTask(title.trim(), priority)
                                title = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Task Add Karein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        items(tasks, key = { it.id }) { task ->
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.isCompleted, onCheckedChange = { viewModel.toggleTask(task) })
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            color = if (task.isCompleted) TextSecondary else TextPrimary,
                            textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null
                        )
                        Text("Priority: ${task.priority}", color = CyanGlow, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun FinanceSection(viewModel: FourBroViewModel) {
    val transactions by viewModel.transactions.collectAsState()
    val summary by viewModel.financeSummary.collectAsState()

    var type by remember { mutableStateOf("RECEIVABLE") }
    var amountStr by remember { mutableStateOf("") }
    var person by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, CyanGlow)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Hisaab Summary", color = CyanGlow, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { viewModel.exportFinanceCsv() }) {
                            Icon(Icons.Default.Share, contentDescription = "Export CSV", tint = CyanGlow)
                        }
                    }
                    Text("Total Income: ${FinanceCalculator.formatAmount(summary.totalIncomeMinor)}", color = SuccessEmerald)
                    Text("Total Expense: ${FinanceCalculator.formatAmount(summary.totalExpenseMinor)}", color = ErrorCrimson)
                    Text("Lene Wale Paise: ${FinanceCalculator.formatAmount(summary.totalReceivableMinor)}", color = CyanGlow)
                    Text("Dene Wale Paise: ${FinanceCalculator.formatAmount(summary.totalPayableMinor)}", color = WarningAmber)
                    summary.counterpartyBalances.forEach { b ->
                        val label = if (b.netReceivableMinor > 0) {
                            "• ${b.counterparty} se lene hain: ${FinanceCalculator.formatAmount(b.netReceivableMinor)}"
                        } else {
                            "• ${b.counterparty} ko dene hain: ${FinanceCalculator.formatAmount(-b.netReceivableMinor)}"
                        }
                        Text(label, color = TextPrimary)
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nayi Entry (History hamesha mehfooz rehti hai)", color = TextPrimary, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("INCOME", "EXPENSE", "RECEIVABLE").forEach { t ->
                            OutlinedButton(
                                onClick = { type = t },
                                border = BorderStroke(1.dp, if (type == t) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(t, maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("PAYABLE", "PAYMENT_RECEIVED", "PAYMENT_MADE").forEach { t ->
                            OutlinedButton(
                                onClick = { type = t },
                                border = BorderStroke(1.dp, if (type == t) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(t.replace("PAYMENT_", "PAY_"), maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                    OutlinedTextField(value = amountStr, onValueChange = { amountStr = it }, label = { Text("Amount (PKR)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = person, onValueChange = { person = it }, label = { Text("Shaks ka Naam (e.g. Waqas)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            val amt = amountStr.toDoubleOrNull() ?: 0.0
                            if (amt > 0.0) {
                                viewModel.addFinanceEntry(type, amt, person, "General", note)
                                amountStr = ""; person = ""; note = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Record Save Karein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        items(transactions, key = { it.id }) { tx ->
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "[${tx.type}] ${FinanceCalculator.formatAmount(tx.amountMinor, tx.currency)}" +
                                if (tx.counterparty.isNotBlank()) " • ${tx.counterparty}" else "",
                            color = if (tx.isReversed) TextSecondary else TextPrimary,
                            textDecoration = if (tx.isReversed) TextDecoration.LineThrough else null,
                            fontWeight = FontWeight.Bold
                        )
                        if (tx.note.isNotBlank()) Text(tx.note, color = TextSecondary)
                    }
                    if (!tx.isReversed) {
                        OutlinedButton(onClick = { viewModel.reverseFinanceEntry(tx) }) {
                            Text("Reverse", color = WarningAmber)
                        }
                    }
                }
            }
        }
    }
}

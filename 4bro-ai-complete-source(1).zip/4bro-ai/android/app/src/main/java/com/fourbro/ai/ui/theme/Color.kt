package com.fourbro.ai.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDeep = Color(0xFF070D1F)
val NavySurface = Color(0xFF0D1630)
val NavyElevated = Color(0xFF132042)
val PureBlackGlass = Color(0xFF040711)

val CyanGlow = Color(0xFF00D4FF)
val CyanBright = Color(0xFF00F0FF)
val SoftBlueGlow = Color(0xFF38BDF8)
val RoyalBlueAccent = Color(0xFF2563EB)

val SuccessEmerald = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorCrimson = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF1E3A5F)

// Light mode support for accessibility toggle
val LightBackground = Color(0xFFF1F5F9)
val LightSurface = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

package com.fourbro.ai.ui.onboarding

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.fourbro.ai.ui.mascot.FourBroRobotMascot
import com.fourbro.ai.ui.mascot.RobotState
import com.fourbro.ai.ui.theme.BorderSubtle
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavyElevated
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary

@Composable
fun OnboardingScreen(
    initialOwnerName: String,
    initialLanguage: String,
    initialBackendUrl: String,
    onComplete: (ownerName: String, language: String, backendUrl: String) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var ownerName by remember { mutableStateOf(initialOwnerName) }
    var selectedLanguage by remember { mutableStateOf(initialLanguage) }
    var backendUrl by remember { mutableStateOf(initialBackendUrl) }

    val robotState = when (step) {
        0 -> RobotState.Idle
        1 -> RobotState.Speaking
        else -> RobotState.Waiting
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Step ${step + 1} of 3",
            style = MaterialTheme.typography.labelMedium,
            color = CyanGlow
        )
        Spacer(modifier = Modifier.height(12.dp))
        FourBroRobotMascot(state = robotState, size = 148.dp)
        Spacer(modifier = Modifier.height(16.dp))

        when (step) {
            0 -> {
                Text(
                    text = "4BRO AI mein Khush Amdeed!",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Main aapka personal AI dost hoon. Apna naam aur pasandida zubaan chunein.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                OutlinedTextField(
                    value = ownerName,
                    onValueChange = { ownerName = it },
                    label = { Text("Aapka Naam (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Zubaan (Language):",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "roman_ur" to "Roman Urdu",
                        "ur" to "اردو",
                        "en" to "English"
                    ).forEach { (code, label) ->
                        val selected = selectedLanguage == code
                        OutlinedButton(
                            onClick = { selectedLanguage = code },
                            modifier = Modifier.weight(1f),
                            border = BorderStroke(
                                1.5.dp,
                                if (selected) CyanGlow else BorderSubtle
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) NavyElevated else NavySurface,
                                contentColor = if (selected) CyanGlow else TextPrimary
                            )
                        ) {
                            Text(label, maxLines = 1)
                        }
                    }
                }
            }

            1 -> {
                Text(
                    text = "4BRO Backend & Voice",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Aapke Notes, Reminders aur Finance hamesha aapke phone par offline mehfooz rehte hain. AI dimaag aur Natural Male Voice ke liye apna Backend URL daalein (ya baad mein Settings se badlein).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                OutlinedTextField(
                    value = backendUrl,
                    onValueChange = { backendUrl = it },
                    label = { Text("Backend HTTPS URL") },
                    placeholder = { Text("https://fourbro-backend.onrender.com") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            else -> {
                Text(
                    text = "Aapki Privacy aur Permissions",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("• Microphone: Sirf tab chalta hai jab aap Mic dabayein.", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("• Notifications & Alarms: Waqt par reminders dene ke liye.", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("• Floating Robot Bubble: Bilkul optional hai — aap jab chahein ON/OFF kar sakte hain.", color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
                        Text("• Security: Hum kabhi aapka bank PIN, password ya OTP nahi mangte.", color = CyanGlow, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step > 0) {
                OutlinedButton(
                    onClick = { step -= 1 },
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Text("Peeche", color = TextPrimary)
                }
            }
            Button(
                onClick = {
                    if (step < 2) {
                        step += 1
                    } else {
                        onComplete(
                            ownerName.trim().ifEmpty { "Dost" },
                            selectedLanguage,
                            backendUrl.trim()
                        )
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanGlow,
                    contentColor = PureBlackGlass
                )
            ) {
                Text(
                    text = if (step < 2) "Aage Barhein" else "4BRO Shuru Karein",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

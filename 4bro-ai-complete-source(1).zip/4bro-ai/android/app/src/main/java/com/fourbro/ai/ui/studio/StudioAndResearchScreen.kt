package com.fourbro.ai.ui.studio

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fourbro.ai.automation.SafeAutomationManager
import com.fourbro.ai.ui.home.FourBroViewModel
import com.fourbro.ai.ui.theme.BorderSubtle
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary
import com.fourbro.ai.ui.theme.WarningAmber

@Composable
fun StudioAndResearchScreen(viewModel: FourBroViewModel) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("YouTube", "Facebook", "Research")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
    ) {
        TabRow(selectedTabIndex = selectedTab, containerColor = PureBlackGlass, contentColor = CyanGlow) {
            tabs.forEachIndexed { idx, title ->
                Tab(
                    selected = selectedTab == idx,
                    onClick = { selectedTab = idx },
                    text = { Text(title, fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        when (selectedTab) {
            0 -> YouTubeStudioTab(viewModel)
            1 -> FacebookStudioTab(viewModel)
            else -> ResearchTab(viewModel)
        }
    }
}

@Composable
private fun YouTubeStudioTab(viewModel: FourBroViewModel) {
    val context = LocalContext.current
    val result by viewModel.youtubeResult.collectAsState()
    var topic by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("long") }
    var durationStr by remember { mutableStateOf("5") }
    var aspectRatio by remember { mutableStateOf("16:9") }
    var style by remember { mutableStateOf("Engaging storytelling") }
    var useLiveTrends by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("YouTube Content Studio", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("Video Topic") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("short" to "Shorts (9:16)", "long" to "Long Video (16:9)").forEach { (fmt, lbl) ->
                            OutlinedButton(
                                onClick = {
                                    format = fmt
                                    aspectRatio = if (fmt == "short") "9:16" else "16:9"
                                    durationStr = if (fmt == "short") "1" else "5"
                                },
                                border = BorderStroke(1.dp, if (format == fmt) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(lbl, maxLines = 1) }
                        }
                    }
                    OutlinedTextField(value = durationStr, onValueChange = { durationStr = it }, label = { Text("Duration (Minutes)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = style, onValueChange = { style = it }, label = { Text("Style (e.g. Documentary / Funny)") }, modifier = Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = useLiveTrends, onCheckedChange = { useLiveTrends = it })
                        Text("Live Trending Research shaamil karein", color = TextPrimary)
                    }
                    Button(
                        onClick = {
                            if (topic.isNotBlank()) {
                                viewModel.generateYouTubePackage(
                                    topic = topic.trim(),
                                    format = format,
                                    durationMin = durationStr.toDoubleOrNull() ?: 5.0,
                                    aspectRatio = aspectRatio,
                                    style = style,
                                    useLiveTrends = useLiveTrends
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Complete Script & Prompts Banayein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        result?.let { yt ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, CyanGlow)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Character Bible: ${yt.characterBible}", color = CyanGlow)
                        Text("Hooks:", color = TextPrimary, fontWeight = FontWeight.Bold)
                        yt.hooks.forEach { Text("• $it", color = TextSecondary) }
                        Text("Titles: ${yt.titles.joinToString(" | ")}", color = TextPrimary)
                        OutlinedButton(
                            onClick = {
                                SafeAutomationManager.executeIntentAction(context, "COPY_CLIPBOARD", yt.fullScript)
                            }
                        ) { Text("Full Script Copy Karein") }
                    }
                }
            }

            items(yt.scenes) { scene ->
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Scene ${scene.sceneNumber} (${scene.timeRange})", color = CyanGlow, fontWeight = FontWeight.Bold)
                        Text("Dialogue: ${scene.dialogue}", color = TextPrimary)
                        Text("Image Prompt (EN): ${scene.imagePromptEn}", color = TextSecondary)
                        Text("Video Prompt (EN): ${scene.videoPromptEn}", color = TextSecondary)
                        Text("Motion: ${scene.motionInstruction} | FX: ${scene.effectsInstruction}", color = WarningAmber, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun FacebookStudioTab(viewModel: FourBroViewModel) {
    val context = LocalContext.current
    val result by viewModel.facebookResult.collectAsState()
    var topic by remember { mutableStateOf("") }
    var goal by remember { mutableStateOf("engagement") }
    var includeResearch by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Facebook Page Manager", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = topic, onValueChange = { topic = it }, label = { Text("Post / Campaign Topic") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("engagement", "education", "calendar").forEach { g ->
                            OutlinedButton(
                                onClick = { goal = g },
                                border = BorderStroke(1.dp, if (goal == g) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(g, maxLines = 1) }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = includeResearch, onCheckedChange = { includeResearch = it })
                        Text("Audience/Monetization Research shaamil karein", color = TextPrimary)
                    }
                    Button(
                        onClick = {
                            if (topic.isNotBlank()) {
                                viewModel.generateFacebookPackage(topic.trim(), goal, includeResearch)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Draft & Calendar Banayein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        result?.let { fb ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, CyanGlow)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Draft (Approval Required Before Publishing)", color = WarningAmber, fontWeight = FontWeight.Bold)
                        Text(fb.postDraft, color = TextPrimary)
                        Text(fb.hashtags.joinToString(" "), color = CyanGlow)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                SafeAutomationManager.executeIntentAction(context, "COPY_CLIPBOARD", fb.postDraft)
                            }) { Text("Copy Draft") }
                            OutlinedButton(onClick = {
                                SafeAutomationManager.executeIntentAction(context, "SHARE_TEXT", fb.postDraft)
                            }) { Text("Approve & Share") }
                        }
                    }
                }
            }

            items(fb.contentCalendar) { day ->
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Day ${day.day} • ${day.bestFormat}: ${day.theme}", color = CyanGlow, fontWeight = FontWeight.Bold)
                        Text(day.postHook, color = TextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResearchTab(viewModel: FourBroViewModel) {
    val context = LocalContext.current
    val result by viewModel.researchResult.collectAsState()
    var query by remember { mutableStateOf("") }
    var depth by remember { mutableStateOf("quick") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cited Internet Research", color = CyanGlow, fontWeight = FontWeight.Bold)
                    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Research Topic") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("quick" to "Quick Search", "deep" to "Deep Research").forEach { (d, lbl) ->
                            OutlinedButton(
                                onClick = { depth = d },
                                border = BorderStroke(1.dp, if (depth == d) CyanGlow else BorderSubtle),
                                modifier = Modifier.weight(1f)
                            ) { Text(lbl) }
                        }
                    }
                    Button(
                        onClick = { if (query.isNotBlank()) viewModel.runWebResearch(query.trim(), depth) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Real Search Shuru Karein", fontWeight = FontWeight.Bold) }
                }
            }
        }

        result?.let { r ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, CyanGlow)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Retrieved: ${r.retrievedAt}", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                        Text(r.summary, color = TextPrimary)
                        if (r.verifiedFacts.isNotEmpty()) {
                            Text("Verified Facts:", color = CyanGlow, fontWeight = FontWeight.Bold)
                            r.verifiedFacts.forEach { Text("• $it", color = TextPrimary) }
                        }
                        if (r.uncertainties.isNotEmpty()) {
                            Text("Uncertainties:", color = WarningAmber, fontWeight = FontWeight.Bold)
                            r.uncertainties.forEach { Text("• $it", color = WarningAmber) }
                        }
                        OutlinedButton(onClick = {
                            SafeAutomationManager.executeIntentAction(context, "SHARE_TEXT", r.exportMarkdown)
                        }) { Text("Export Markdown Report") }
                    }
                }
            }

            items(r.sources) { src ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavySurface),
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.clickable {
                        SafeAutomationManager.executeIntentAction(context, "OPEN_URL", src.url)
                    }
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("[${src.id}] ${src.title}", color = CyanGlow, fontWeight = FontWeight.Bold)
                        Text("Date: ${src.publishedDate ?: "Unavailable"}", color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                        Text(src.url, color = TextSecondary, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

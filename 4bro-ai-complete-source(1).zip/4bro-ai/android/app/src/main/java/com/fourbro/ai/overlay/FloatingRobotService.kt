package com.fourbro.ai.overlay

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.fourbro.ai.FourBroApp
import com.fourbro.ai.MainActivity
import com.fourbro.ai.R
import com.fourbro.ai.data.local.SecurePrefsManager
import kotlin.math.abs

/**
 * Android 13/14/15/16 compliant Floating 4BRO Robot Bubble.
 * - Attaches visible TYPE_APPLICATION_OVERLAY window BEFORE/on promoting foreground service
 *   (prevents Android 15 ForegroundServiceStartNotAllowedException).
 * - Saves user's preferred X/Y coordinates in SecurePrefsManager.
 * - Includes explicit Stop button in both bubble menu & persistent notification.
 */
class FloatingRobotService : Service() {

    private var windowManager: WindowManager? = null
    private var bubbleView: View? = null
    private var menuView: View? = null
    private lateinit var prefs: SecurePrefsManager
    private lateinit var bubbleParams: WindowManager.LayoutParams

    @SuppressLint("ClickableViewAccessibility")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        prefs = SecurePrefsManager(this)
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // CRITICAL for Android 15+: Attach visible overlay window first before foreground service
        if (bubbleView == null) {
            attachBubbleWindow()
        }

        promoteForegroundNotification()
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachBubbleWindow() {
        val density = resources.displayMetrics.density
        val sizePx = (62 * density).toInt()

        bubbleParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.overlayX
            y = prefs.overlayY
        }

        val bubbleText = TextView(this).apply {
            text = "4B"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#00F0FF"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#0D1630"))
                setStroke((3 * density).toInt(), Color.parseColor("#00D4FF"))
            }
            elevation = 8 * density
        }

        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isClick = true

        bubbleText.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isClick = true
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) {
                        isClick = false
                        bubbleParams.x = initialX + dx
                        bubbleParams.y = initialY + dy
                        windowManager?.updateViewLayout(bubbleText, bubbleParams)
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        toggleMiniMenu()
                    } else {
                        prefs.overlayX = bubbleParams.x
                        prefs.overlayY = bubbleParams.y
                    }
                    true
                }

                else -> false
            }
        }

        bubbleView = bubbleText
        windowManager?.addView(bubbleText, bubbleParams)
    }

    private fun toggleMiniMenu() {
        if (menuView != null) {
            windowManager?.removeView(menuView)
            menuView = null
            return
        }

        val density = resources.displayMetrics.density
        val menuParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleParams.x
            y = bubbleParams.y + (70 * density).toInt()
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), (10 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 16 * density
                setColor(Color.parseColor("#070D1F"))
                setStroke((2 * density).toInt(), Color.parseColor("#00D4FF"))
            }
        }

        fun makeAction(label: String, colorHex: String, onClick: () -> Unit): TextView {
            return TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.parseColor(colorHex))
                setPadding(8, 12, 8, 12)
                setOnClickListener { onClick() }
            }
        }

        container.addView(makeAction("Open 4BRO AI", "#00F0FF") {
            removeMenu()
            val launch = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            startActivity(launch)
        })

        container.addView(makeAction("Minimize Menu", "#94A3B8") {
            removeMenu()
        })

        container.addView(makeAction("Close Bubble", "#EF4444") {
            stopOverlay()
        })

        menuView = container
        windowManager?.addView(container, menuParams)
    }

    private fun removeMenu() {
        menuView?.let {
            runCatching { windowManager?.removeView(it) }
        }
        menuView = null
    }

    private fun promoteForegroundNotification() {
        val stopIntent = Intent(this, FloatingRobotService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            101,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openPending = PendingIntent.getActivity(
            this,
            102,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, FourBroApp.CHANNEL_OVERLAY)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("4BRO Floating Bubble Active")
            .setContentText("Bubble ko drag karein ya band karne ke liye Close dabayein.")
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Close Bubble", stopPending)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun stopOverlay() {
        removeMenu()
        bubbleView?.let {
            runCatching { windowManager?.removeView(it) }
        }
        bubbleView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        removeMenu()
        bubbleView?.let {
            runCatching { windowManager?.removeView(it) }
        }
        bubbleView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.fourbro.ai.overlay.STOP"
        private const val NOTIF_ID = 4101
    }
}

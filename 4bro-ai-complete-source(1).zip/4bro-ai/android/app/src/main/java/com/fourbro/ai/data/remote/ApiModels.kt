package com.fourbro.ai.data.remote

import com.google.gson.JsonElement

data class HealthResponseDto(
    val status: String,
    val service: String,
    val version: String,
    val timestamp: String,
    val capabilities: Map<String, String>
)

data class ChatRequestDto(
    val sessionId: String,
    val message: String,
    val preferredLanguage: String? = null,
    val ownerName: String? = null
)

data class DeviceActionDto(
    val tool: String,
    val args: Map<String, JsonElement>,
    val requiresConfirmation: Boolean = false
)

data class ChatResponseDto(
    val sessionId: String,
    val status: String,
    val provider: String,
    val displayText: String,
    val ttsSpeechText: String,
    val detectedLanguage: String,
    val robotState: String,
    val requiresConfirmation: Boolean,
    val confirmationPrompt: String? = null,
    val deviceActions: List<DeviceActionDto> = emptyList(),
    val serverToolRequests: List<DeviceActionDto> = emptyList()
)

data class ToolResultRequestDto(
    val sessionId: String,
    val tool: String,
    val status: String,
    val summary: String
)

data class TranscribeRequestDto(
    val audioBase64: String,
    val mimeType: String,
    val languageHint: String = "auto"
)

data class TranscribeResponseDto(
    val status: String,
    val provider: String,
    val text: String,
    val language: String,
    val message: String? = null
)

data class SynthesizeRequestDto(
    val text: String,
    val language: String = "ur-PK",
    val rate: Float = 1.0f,
    val volume: Float = 1.0f
)

data class SynthesizeResponseDto(
    val status: String,
    val provider: String,
    val voiceName: String,
    val audioBase64: String? = null,
    val fallbackHint: String? = null
)

data class ResearchRequestDto(
    val query: String,
    val depth: String = "quick",
    val language: String = "roman_ur"
)

data class ResearchSourceDto(
    val id: Int,
    val title: String,
    val url: String,
    val snippet: String,
    val publishedDate: String?
)

data class ResearchResponseDto(
    val status: String,
    val provider: String,
    val query: String,
    val retrievedAt: String,
    val sources: List<ResearchSourceDto> = emptyList(),
    val verifiedFacts: List<String> = emptyList(),
    val opinionsAndClaims: List<String> = emptyList(),
    val uncertainties: List<String> = emptyList(),
    val summary: String,
    val exportMarkdown: String
)

data class YouTubeRequestDto(
    val topic: String,
    val format: String = "long",
    val durationMinutes: Double = 5.0,
    val aspectRatio: String = "16:9",
    val language: String = "roman_ur",
    val style: String = "engaging storytelling",
    val characterDescription: String? = null,
    val useLiveTrends: Boolean = false
)

data class YouTubeSceneDto(
    val sceneNumber: Int,
    val timeRange: String,
    val dialogue: String,
    val visualPromptEn: String,
    val imagePromptEn: String,
    val videoPromptEn: String,
    val motionInstruction: String,
    val effectsInstruction: String
)

data class ThumbnailConceptDto(
    val titleOverlay: String,
    val visualDescriptionEn: String
)

data class YouTubeResponseDto(
    val status: String,
    val topic: String,
    val format: String,
    val durationMinutes: Double,
    val aspectRatio: String,
    val language: String,
    val characterBible: String,
    val hooks: List<String> = emptyList(),
    val fullScript: String,
    val scenes: List<YouTubeSceneDto> = emptyList(),
    val titles: List<String> = emptyList(),
    val description: String,
    val tags: List<String> = emptyList(),
    val hashtags: List<String> = emptyList(),
    val thumbnailConcepts: List<ThumbnailConceptDto> = emptyList()
)

data class FacebookRequestDto(
    val topic: String,
    val goal: String = "engagement",
    val language: String = "roman_ur",
    val includeResearch: Boolean = false,
    val daysInCalendar: Int = 7
)

data class FacebookCalendarItemDto(
    val day: Int,
    val theme: String,
    val postHook: String,
    val bestFormat: String
)

data class FacebookResponseDto(
    val status: String,
    val topic: String,
    val goal: String,
    val approvalRequiredBeforePublish: Boolean,
    val publishingStatus: String,
    val postIdeas: List<String> = emptyList(),
    val postDraft: String,
    val captions: List<String> = emptyList(),
    val hashtags: List<String> = emptyList(),
    val contentCalendar: List<FacebookCalendarItemDto> = emptyList()
)

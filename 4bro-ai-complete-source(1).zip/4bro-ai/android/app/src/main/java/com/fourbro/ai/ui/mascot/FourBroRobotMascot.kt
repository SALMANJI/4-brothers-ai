package com.fourbro.ai.ui.mascot

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.fourbro.ai.ui.theme.CyanBright
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.ErrorCrimson
import com.fourbro.ai.ui.theme.SoftBlueGlow
import com.fourbro.ai.ui.theme.SuccessEmerald
import com.fourbro.ai.ui.theme.WarningAmber
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun FourBroRobotMascot(
    state: RobotState,
    modifier: Modifier = Modifier,
    size: Dp = 156.dp,
    audioAmplitude: Float = 0f,
    onTap: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "robotLoop")

    // Hover cycle (gentle float; calmer when sleeping)
    val hoverPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == RobotState.Sleeping) 4200 else 2600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "hover"
    )

    // Wave phase for Speaking / Listening / Processing
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave"
    )

    // Pulse alpha
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Natural eye blink timer in Idle / Waiting
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(state) {
        while (state == RobotState.Idle || state == RobotState.Waiting || state == RobotState.Working) {
            delay(3600)
            isBlinking = true
            delay(130)
            isBlinking = false
        }
        isBlinking = false
    }

    val accentColor by animateColorAsState(
        targetValue = when (state) {
            RobotState.Error -> ErrorCrimson
            RobotState.Warning -> WarningAmber
            RobotState.Success -> SuccessEmerald
            RobotState.Sleeping -> SoftBlueGlow.copy(alpha = 0.30f)
            RobotState.Waiting -> SoftBlueGlow
            else -> CyanGlow
        },
        animationSpec = tween(220),
        label = "accent"
    )

    val eyeColor by animateColorAsState(
        targetValue = when (state) {
            RobotState.Error -> ErrorCrimson
            RobotState.Warning -> WarningAmber
            RobotState.Success -> SuccessEmerald
            RobotState.Sleeping -> SoftBlueGlow.copy(alpha = 0.28f)
            else -> CyanBright
        },
        animationSpec = tween(220),
        label = "eye"
    )

    val headTilt by animateFloatAsState(
        targetValue = when (state) {
            RobotState.Listening -> -4f
            RobotState.Thinking -> 6f
            RobotState.Warning -> -5f
            RobotState.Error -> (sin(wavePhase.toDouble() * 3.0) * 3.5).toFloat()
            else -> 0f
        },
        animationSpec = tween(250),
        label = "tilt"
    )

    val hopOffset by animateFloatAsState(
        targetValue = when (state) {
            RobotState.Success -> -0.055f
            RobotState.WakingUp -> -0.04f
            else -> 0f
        },
        animationSpec = tween(260),
        label = "hop"
    )

    val interactionSource = remember { MutableInteractionSource() }
    val clickableMod = if (onTap != null) {
        modifier
            .size(size)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onTap)
    } else {
        modifier.size(size)
    }

    Canvas(modifier = clickableMod) {
        val w = this.size.width
        val h = this.size.height

        val hoverOffset = when (state) {
            RobotState.Sleeping -> sin(hoverPhase.toDouble()).toFloat() * h * 0.006f
            RobotState.Error -> 0f
            else -> sin(hoverPhase.toDouble()).toFloat() * h * 0.018f
        } + (hopOffset * h)

        // Floor glow shadow
        val glowAlpha = if (state == RobotState.Sleeping) 0.10f else 0.32f * pulse
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(accentColor.copy(alpha = glowAlpha), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.91f),
                radius = w * 0.34f
            ),
            topLeft = Offset(w * 0.16f, h * 0.85f),
            size = Size(w * 0.68f, h * 0.11f)
        )

        // Concentric listening rings behind robot
        if (state == RobotState.Listening) {
            val ampBoost = (audioAmplitude.coerceIn(0f, 1f)) * 0.08f
            drawCircle(
                color = CyanGlow.copy(alpha = 0.25f * pulse),
                radius = w * (0.42f + ampBoost),
                center = Offset(w * 0.5f, h * 0.42f + hoverOffset),
                style = Stroke(width = w * 0.012f)
            )
            drawCircle(
                color = SoftBlueGlow.copy(alpha = 0.16f * pulse),
                radius = w * (0.48f + ampBoost * 1.4f),
                center = Offset(w * 0.5f, h * 0.42f + hoverOffset),
                style = Stroke(width = w * 0.008f)
            )
        }

        // Canonical Proportions (NEVER distorted across states)
        val cx = w * 0.5f
        val headTop = h * 0.19f + hoverOffset
        val headWidth = w * 0.57f
        val headHeight = h * 0.37f
        val headLeft = cx - headWidth / 2f

        val torsoTop = headTop + headHeight + h * 0.028f
        val torsoWidth = w * 0.39f
        val torsoHeight = h * 0.24f
        val torsoLeft = cx - torsoWidth / 2f

        // 1. Torso & Arms
        val armSwing = when (state) {
            RobotState.Working -> sin(wavePhase.toDouble() * 2.0).toFloat() * 14f
            RobotState.Speaking -> sin(wavePhase.toDouble()).toFloat() * 8f
            RobotState.Success -> -18f
            else -> 0f
        }

        // Left Arm
        rotate(degrees = 14f + armSwing, pivot = Offset(torsoLeft - w * 0.05f, torsoTop + torsoHeight * 0.35f)) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF1E3363), Color(0xFF0F1B3A))),
                topLeft = Offset(torsoLeft - w * 0.105f, torsoTop + h * 0.015f),
                size = Size(w * 0.082f, h * 0.155f),
                cornerRadius = CornerRadius(w * 0.041f, w * 0.041f)
            )
            drawRoundRect(
                color = accentColor.copy(alpha = 0.7f),
                topLeft = Offset(torsoLeft - w * 0.105f, torsoTop + h * 0.015f),
                size = Size(w * 0.082f, h * 0.155f),
                cornerRadius = CornerRadius(w * 0.041f, w * 0.041f),
                style = Stroke(width = w * 0.008f)
            )
        }

        // Right Arm
        rotate(degrees = -14f - armSwing, pivot = Offset(torsoLeft + torsoWidth + w * 0.05f, torsoTop + torsoHeight * 0.35f)) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF1E3363), Color(0xFF0F1B3A))),
                topLeft = Offset(torsoLeft + torsoWidth + w * 0.023f, torsoTop + h * 0.015f),
                size = Size(w * 0.082f, h * 0.155f),
                cornerRadius = CornerRadius(w * 0.041f, w * 0.041f)
            )
            drawRoundRect(
                color = accentColor.copy(alpha = 0.7f),
                topLeft = Offset(torsoLeft + torsoWidth + w * 0.023f, torsoTop + h * 0.015f),
                size = Size(w * 0.082f, h * 0.155f),
                cornerRadius = CornerRadius(w * 0.041f, w * 0.041f),
                style = Stroke(width = w * 0.008f)
            )
        }

        // Torso Shell
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0xFF1E3363), Color(0xFF0F1B3A))),
            topLeft = Offset(torsoLeft, torsoTop),
            size = Size(torsoWidth, torsoHeight),
            cornerRadius = CornerRadius(w * 0.11f, w * 0.11f)
        )
        drawRoundRect(
            color = accentColor,
            topLeft = Offset(torsoLeft, torsoTop),
            size = Size(torsoWidth, torsoHeight),
            cornerRadius = CornerRadius(w * 0.11f, w * 0.11f),
            style = Stroke(width = w * 0.011f)
        )

        // Chest Core
        val coreCenter = Offset(cx, torsoTop + torsoHeight * 0.5f)
        drawCircle(color = Color(0xFF030816), radius = w * 0.075f, center = coreCenter)
        drawCircle(
            color = accentColor.copy(alpha = if (state == RobotState.Sleeping) 0.25f else pulse),
            radius = w * 0.075f,
            center = coreCenter,
            style = Stroke(width = w * 0.008f)
        )
        if (state == RobotState.Processing || state == RobotState.Working) {
            rotate(degrees = (wavePhase * 57.3f), pivot = coreCenter) {
                drawArc(
                    color = CyanBright,
                    startAngle = 0f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(coreCenter.x - w * 0.048f, coreCenter.y - w * 0.048f),
                    size = Size(w * 0.096f, w * 0.096f),
                    style = Stroke(width = w * 0.01f, cap = StrokeCap.Round)
                )
            }
        } else {
            drawCircle(
                color = accentColor.copy(alpha = if (state == RobotState.Sleeping) 0.2f else 0.85f),
                radius = w * 0.025f,
                center = coreCenter
            )
        }

        // 2. Head Group (rotates slightly for expressive tilt)
        rotate(degrees = headTilt, pivot = Offset(cx, headTop + headHeight / 2f)) {
            // Antenna Stem & Orb
            val antennaOrbY = headTop - h * 0.095f
            drawLine(
                color = accentColor,
                start = Offset(cx, headTop),
                end = Offset(cx, antennaOrbY + w * 0.025f),
                strokeWidth = w * 0.018f,
                cap = StrokeCap.Round
            )
            val orbRadius = if (state == RobotState.Thinking || state == RobotState.Working) {
                w * (0.033f + 0.008f * pulse)
            } else {
                w * 0.032f
            }
            drawCircle(
                color = accentColor,
                radius = orbRadius,
                center = Offset(cx, antennaOrbY)
            )

            // Ear Nodes
            val earW = w * 0.055f
            val earH = headHeight * 0.40f
            val earY = headTop + headHeight * 0.30f
            drawRoundRect(
                color = accentColor,
                topLeft = Offset(headLeft - earW * 0.85f, earY),
                size = Size(earW, earH),
                cornerRadius = CornerRadius(earW / 2f, earW / 2f)
            )
            drawRoundRect(
                color = accentColor,
                topLeft = Offset(headLeft + headWidth - earW * 0.15f, earY),
                size = Size(earW, earH),
                cornerRadius = CornerRadius(earW / 2f, earW / 2f)
            )

            // Head Shell
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF1E3363), Color(0xFF0F1B3A))),
                topLeft = Offset(headLeft, headTop),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(w * 0.13f, w * 0.13f)
            )
            drawRoundRect(
                color = accentColor,
                topLeft = Offset(headLeft, headTop),
                size = Size(headWidth, headHeight),
                cornerRadius = CornerRadius(w * 0.13f, w * 0.13f),
                style = Stroke(width = w * 0.013f)
            )

            // Dark Glass Visor
            val visorMarginX = headWidth * 0.105f
            val visorMarginY = headHeight * 0.145f
            val visorLeft = headLeft + visorMarginX
            val visorTop = headTop + visorMarginY
            val visorW = headWidth - visorMarginX * 2f
            val visorH = headHeight - visorMarginY * 2f

            drawRoundRect(
                color = Color(0xFF030816),
                topLeft = Offset(visorLeft, visorTop),
                size = Size(visorW, visorH),
                cornerRadius = CornerRadius(w * 0.08f, w * 0.08f)
            )
            drawRoundRect(
                color = Color(0xFF1E3A5F),
                topLeft = Offset(visorLeft, visorTop),
                size = Size(visorW, visorH),
                cornerRadius = CornerRadius(w * 0.08f, w * 0.08f),
                style = Stroke(width = w * 0.006f)
            )

            // Eyes inside Visor
            val leftEyeX = visorLeft + visorW * 0.28f
            val rightEyeX = visorLeft + visorW * 0.72f
            val eyeY = visorTop + visorH * 0.43f
            val eyeRx = visorW * 0.095f
            val eyeRy = visorH * 0.18f

            val eyeOffsetX = if (state == RobotState.Thinking) visorW * 0.04f else 0f
            val eyeOffsetY = if (state == RobotState.Thinking) -visorH * 0.04f else 0f

            when {
                state == RobotState.Sleeping || isBlinking -> {
                    // Peaceful closed eyes
                    drawLine(
                        color = eyeColor,
                        start = Offset(leftEyeX - eyeRx, eyeY),
                        end = Offset(leftEyeX + eyeRx, eyeY),
                        strokeWidth = w * 0.014f,
                        cap = StrokeCap.Round
                    )
                    drawLine(
                        color = eyeColor,
                        start = Offset(rightEyeX - eyeRx, eyeY),
                        end = Offset(rightEyeX + eyeRx, eyeY),
                        strokeWidth = w * 0.014f,
                        cap = StrokeCap.Round
                    )
                }

                state == RobotState.Success -> {
                    // Happy crescent ^ ^ eyes
                    val leftArc = Path().apply {
                        moveTo(leftEyeX - eyeRx, eyeY + eyeRy * 0.25f)
                        quadraticTo(leftEyeX, eyeY - eyeRy, leftEyeX + eyeRx, eyeY + eyeRy * 0.25f)
                    }
                    val rightArc = Path().apply {
                        moveTo(rightEyeX - eyeRx, eyeY + eyeRy * 0.25f)
                        quadraticTo(rightEyeX, eyeY - eyeRy, rightEyeX + eyeRx, eyeY + eyeRy * 0.25f)
                    }
                    drawPath(leftArc, color = eyeColor, style = Stroke(w * 0.016f, cap = StrokeCap.Round))
                    drawPath(rightArc, color = eyeColor, style = Stroke(w * 0.016f, cap = StrokeCap.Round))
                }

                state == RobotState.Error -> {
                    // X _ X error eyes
                    val r = eyeRx * 0.85f
                    listOf(leftEyeX, rightEyeX).forEach { ex ->
                        drawLine(eyeColor, Offset(ex - r, eyeY - r), Offset(ex + r, eyeY + r), w * 0.014f, StrokeCap.Round)
                        drawLine(eyeColor, Offset(ex - r, eyeY + r), Offset(ex + r, eyeY - r), w * 0.014f, StrokeCap.Round)
                    }
                }

                else -> {
                    val scaleY = if (state == RobotState.Listening || state == RobotState.WakingUp) 1.15f else 1.0f
                    listOf(leftEyeX, rightEyeX).forEach { ex ->
                        drawOval(
                            color = eyeColor,
                            topLeft = Offset(ex + eyeOffsetX - eyeRx, eyeY + eyeOffsetY - eyeRy * scaleY),
                            size = Size(eyeRx * 2f, eyeRy * 2f * scaleY)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.88f),
                            radius = eyeRx * 0.32f,
                            center = Offset(ex + eyeOffsetX - eyeRx * 0.28f, eyeY + eyeOffsetY - eyeRy * 0.35f)
                        )
                    }
                }
            }

            // Mouth / Waveform inside Visor
            val mouthY = visorTop + visorH * 0.77f
            when (state) {
                RobotState.Speaking, RobotState.Listening -> {
                    val bars = 5
                    val barSpacing = visorW * 0.085f
                    val startX = cx - ((bars - 1) * barSpacing) / 2f
                    val amp = if (state == RobotState.Listening) {
                        0.4f + audioAmplitude.coerceIn(0f, 1f) * 0.6f
                    } else {
                        0.75f
                    }
                    for (i in 0 until bars) {
                        val barFactor = abs(sin(wavePhase.toDouble() + i * 0.9)).toFloat() * amp
                        val barH = visorH * (0.04f + 0.13f * barFactor)
                        val bx = startX + i * barSpacing
                        drawLine(
                            color = eyeColor,
                            start = Offset(bx, mouthY - barH / 2f),
                            end = Offset(bx, mouthY + barH / 2f),
                            strokeWidth = w * 0.014f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                RobotState.Thinking, RobotState.Processing -> {
                    // 3 thinking dots
                    val dotSpacing = visorW * 0.11f
                    for (i in -1..1) {
                        val activeAlpha = if (((wavePhase * 1.5f).toInt() % 3) - 1 == i) 1f else 0.35f
                        drawCircle(
                            color = eyeColor.copy(alpha = activeAlpha),
                            radius = w * 0.013f,
                            center = Offset(cx + i * dotSpacing, mouthY)
                        )
                    }
                }

                RobotState.Error, RobotState.Warning -> {
                    val frown = Path().apply {
                        moveTo(cx - visorW * 0.13f, mouthY + visorH * 0.03f)
                        quadraticTo(cx, mouthY - visorH * 0.07f, cx + visorW * 0.13f, mouthY + visorH * 0.03f)
                    }
                    drawPath(frown, color = eyeColor, style = Stroke(w * 0.014f, cap = StrokeCap.Round))
                }

                RobotState.Sleeping -> {
                    // Small peaceful dot mouth
                    drawCircle(
                        color = eyeColor,
                        radius = w * 0.012f,
                        center = Offset(cx, mouthY)
                    )
                }

                else -> {
                    // Friendly smile curve
                    val smile = Path().apply {
                        moveTo(cx - visorW * 0.14f, mouthY - visorH * 0.02f)
                        quadraticTo(cx, mouthY + visorH * 0.09f, cx + visorW * 0.14f, mouthY - visorH * 0.02f)
                    }
                    drawPath(smile, color = eyeColor, style = Stroke(w * 0.014f, cap = StrokeCap.Round))
                }
            }
        }

        // Sleeping floating "Z" indicator
        if (state == RobotState.Sleeping) {
            val zDrift = (hoverPhase / (2f * PI.toFloat())) * h * 0.08f
            val zx = cx + w * 0.24f
            val zy = headTop - zDrift
            val zs = w * 0.045f
            val zPath = Path().apply {
                moveTo(zx, zy)
                lineTo(zx + zs, zy)
                lineTo(zx, zy + zs)
                lineTo(zx + zs, zy + zs)
            }
            drawPath(
                zPath,
                color = SoftBlueGlow.copy(alpha = (1f - (hoverPhase / (2f * PI.toFloat()))).coerceIn(0.1f, 0.7f)),
                style = Stroke(width = w * 0.01f, cap = StrokeCap.Round)
            )
        }
    }
}

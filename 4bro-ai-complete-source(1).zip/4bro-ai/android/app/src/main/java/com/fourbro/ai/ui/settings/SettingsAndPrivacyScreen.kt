package com.fourbro.ai.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fourbro.ai.ui.home.FourBroViewModel
import com.fourbro.ai.ui.theme.BorderSubtle
import com.fourbro.ai.ui.theme.CyanGlow
import com.fourbro.ai.ui.theme.ErrorCrimson
import com.fourbro.ai.ui.theme.NavyDeep
import com.fourbro.ai.ui.theme.NavySurface
import com.fourbro.ai.ui.theme.PureBlackGlass
import com.fourbro.ai.ui.theme.TextPrimary
import com.fourbro.ai.ui.theme.TextSecondary

@Composable
fun SettingsAndPrivacyScreen(viewModel: FourBroViewModel) {
    var ownerName by remember { mutableStateOf(viewModel.prefs.ownerName) }
    var language by remember { mutableStateOf(viewModel.prefs.preferredLanguage) }
    var backendUrl by remember { mutableStateOf(viewModel.prefs.backendUrl) }
    var deviceToken by remember { mutableStateOf(viewModel.prefs.deviceToken) }
    var customPersonality by remember { mutableStateOf(viewModel.prefs.customPersonality) }
    var voiceSpeed by remember { mutableFloatStateOf(viewModel.prefs.voiceSpeed) }
    var voiceVolume by remember { mutableFloatStateOf(viewModel.prefs.voiceVolume) }
    var voiceMuted by remember { mutableStateOf(viewModel.prefs.voiceMuted) }
    var darkTheme by remember { mutableStateOf(viewModel.prefs.darkTheme) }
    var handsFree by remember { mutableStateOf(viewModel.prefs.handsFreeEnabled) }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showPrivacyPolicy by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDeep)
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings, Customization & Privacy", color = CyanGlow, fontWeight = FontWeight.ExtraBold)

        // 1. Live Self-Editable Identity & AI Personality
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Aap Khud Badal Sakte Hain (No Coding Needed)", color = CyanGlow, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = ownerName, onValueChange = { ownerName = it }, label = { Text("Aapka Naam") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = customPersonality,
                    onValueChange = { customPersonality = it },
                    label = { Text("4BRO AI Personality Style") },
                    placeholder = { Text("e.g. Zyada friendly aur halka mazaahiya") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("roman_ur" to "Roman Urdu", "ur" to "اردو", "en" to "English").forEach { (code, lbl) ->
                        OutlinedButton(
                            onClick = { language = code },
                            border = BorderStroke(1.dp, if (language == code) CyanGlow else BorderSubtle),
                            modifier = Modifier.weight(1f)
                        ) { Text(lbl, maxLines = 1) }
                    }
                }
            }
        }

        // 2. Voice & Theme Controls
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Voice & Appearance", color = CyanGlow, fontWeight = FontWeight.Bold)
                Text("Voice Speed: ${String.format("%.1fx", voiceSpeed)}", color = TextPrimary)
                Slider(value = voiceSpeed, onValueChange = { voiceSpeed = it }, valueRange = 0.7f..1.5f)
                Text("Voice Volume: ${(voiceVolume * 100).toInt()}%", color = TextPrimary)
                Slider(value = voiceVolume, onValueChange = { voiceVolume = it }, valueRange = 0.1f..1.0f)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Voice Mute", color = TextPrimary)
                    Switch(checked = voiceMuted, onCheckedChange = { voiceMuted = it })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Dark Navy Mode", color = TextPrimary)
                    Switch(checked = darkTheme, onCheckedChange = { darkTheme = it })
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Hands-Free Mic Notification Mode", color = TextPrimary)
                    Switch(checked = handsFree, onCheckedChange = {
                        handsFree = it
                        viewModel.toggleHandsFreeMode(it)
                    })
                }
            }
        }

        // 3. Backend Server Connection
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backend Connection (HTTPS Only)", color = CyanGlow, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = backendUrl, onValueChange = { backendUrl = it }, label = { Text("Backend HTTPS URL") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = deviceToken, onValueChange = { deviceToken = it }, label = { Text("FOURBRO_DEVICE_TOKEN") }, modifier = Modifier.fillMaxWidth())
                Button(
                    onClick = {
                        viewModel.updateSettings(
                            ownerName, language, backendUrl, deviceToken,
                            customPersonality, voiceSpeed, voiceVolume, voiceMuted, darkTheme
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Tamam Settings Save Karein", fontWeight = FontWeight.Bold) }
            }
        }

        // 4. Floating Robot Bubble
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Floating 4BRO Bubble (Optional)", color = CyanGlow, fontWeight = FontWeight.Bold)
                Text("Screen ke upar draggable bubble chalane ke liye Overlay permission zaroori hai.", color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.startFloatingBubble() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanGlow, contentColor = PureBlackGlass),
                        modifier = Modifier.weight(1f)
                    ) { Text("Start Bubble") }
                    OutlinedButton(
                        onClick = { viewModel.stopFloatingBubble() },
                        modifier = Modifier.weight(1f)
                    ) { Text("Stop Bubble", color = ErrorCrimson) }
                }
            }
        }

        // 5. Data Backup, Privacy Policy & Delete All
        Card(colors = CardDefaults.cardColors(containerColor = NavySurface), border = BorderStroke(1.dp, BorderSubtle)) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Data & Privacy Controls", color = CyanGlow, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { viewModel.exportAllDataJson() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Tamam Data Backup Export (JSON)")
                }
                OutlinedButton(onClick = { showPrivacyPolicy = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Privacy Policy Parhein")
                }
                Button(
                    onClick = { showDeleteConfirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson, contentColor = TextPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Tamam Local Data Delete Karein") }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Pakka Delete Karein?") },
            text = { Text("Is se aapke phone par save tamam Notes, Reminders, Tasks, Finance records aur Chat delete ho jayenge.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteAllUserData()
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson)
                ) { Text("Haan, Delete Karein") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }

    if (showPrivacyPolicy) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicy = false },
            title = { Text("4BRO AI Privacy Policy") },
            text = {
                Text(
                    "1. Notes, Tasks, Reminders aur Finance Ledger sirf aapke phone par local Room DB mein save hote hain.\n" +
                    "2. AI chat, cloud voice ya internet research ke waqt sirf wohi message aapke private HTTPS backend par jata hai.\n" +
                    "3. 4BRO AI kabhi aapka banking PIN, password ya OTP nahi mangta aur na store karta hai.\n" +
                    "4. Aap kisi bhi waqt apna poora data export ya delete kar sakte hain."
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyPolicy = false }) { Text("Samajh Aa Gaya") }
            }
        )
    }
}

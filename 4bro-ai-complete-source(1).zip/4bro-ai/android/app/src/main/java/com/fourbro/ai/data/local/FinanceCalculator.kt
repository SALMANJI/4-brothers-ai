package com.fourbro.ai.data.local

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CounterpartyBalance(
    val counterparty: String,
    val netReceivableMinor: Long // Positive = owed TO owner; Negative = owner owes them
)

data class FinanceSummary(
    val totalIncomeMinor: Long,
    val totalExpenseMinor: Long,
    val totalReceivableMinor: Long,
    val totalPayableMinor: Long,
    val netCashMinor: Long,
    val counterpartyBalances: List<CounterpartyBalance>
)

object FinanceCalculator {

    fun toMinorUnits(amountMajor: Double): Long {
        return kotlin.math.round(amountMajor * 100.0).toLong()
    }

    fun formatAmount(amountMinor: Long, currency: String = "PKR"): String {
        val major = amountMinor / 100.0
        return if (amountMinor % 100L == 0L) {
            String.format(Locale.US, "%s %,d", currency, amountMinor / 100L)
        } else {
            String.format(Locale.US, "%s %,.2f", currency, major)
        }
    }

    fun computeSummary(transactions: List<FinanceTransactionEntity>): FinanceSummary {
        var income = 0L
        var expense = 0L
        val peopleMap = linkedMapOf<String, Long>()

        for (tx in transactions) {
            if (tx.isReversed) continue
            val person = tx.counterparty.trim()
            when (tx.type) {
                "INCOME" -> income += tx.amountMinor
                "EXPENSE" -> expense += tx.amountMinor
                "RECEIVABLE" -> {
                    if (person.isNotEmpty()) {
                        peopleMap[person] = (peopleMap[person] ?: 0L) + tx.amountMinor
                    }
                }
                "PAYMENT_RECEIVED" -> {
                    income += tx.amountMinor
                    if (person.isNotEmpty()) {
                        peopleMap[person] = (peopleMap[person] ?: 0L) - tx.amountMinor
                    }
                }
                "PAYABLE" -> {
                    if (person.isNotEmpty()) {
                        peopleMap[person] = (peopleMap[person] ?: 0L) - tx.amountMinor
                    }
                }
                "PAYMENT_MADE" -> {
                    expense += tx.amountMinor
                    if (person.isNotEmpty()) {
                        peopleMap[person] = (peopleMap[person] ?: 0L) + tx.amountMinor
                    }
                }
            }
        }

        val balances = peopleMap.entries
            .filter { it.value != 0L }
            .map { CounterpartyBalance(it.key, it.value) }

        val totalReceivable = balances.filter { it.netReceivableMinor > 0 }.sumOf { it.netReceivableMinor }
        val totalPayable = balances.filter { it.netReceivableMinor < 0 }.sumOf { -it.netReceivableMinor }

        return FinanceSummary(
            totalIncomeMinor = income,
            totalExpenseMinor = expense,
            totalReceivableMinor = totalReceivable,
            totalPayableMinor = totalPayable,
            netCashMinor = income - expense,
            counterpartyBalances = balances
        )
    }

    fun exportCsv(transactions: List<FinanceTransactionEntity>): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val sb = StringBuilder()
        sb.appendLine("id,date,type,amount,currency,counterparty,category,note,isReversed")
        for (tx in transactions) {
            val amountStr = String.format(Locale.US, "%.2f", tx.amountMinor / 100.0)
            val safeNote = tx.note.replace("\"", "\"\"")
            val safePerson = tx.counterparty.replace("\"", "\"\"")
            val safeCat = tx.category.replace("\"", "\"\"")
            sb.appendLine(
                "${tx.id},\"${sdf.format(Date(tx.createdAt))}\",${tx.type},$amountStr,${tx.currency},\"$safePerson\",\"$safeCat\",\"$safeNote\",${tx.isReversed}"
            )
        }
        return sb.toString()
    }
}

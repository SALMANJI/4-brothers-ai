package com.fourbro.ai.ui.mascot

enum class RobotState {
    Idle,
    Listening,
    Thinking,
    Processing,
    Speaking,
    Working,
    Waiting,
    Success,
    Warning,
    Error,
    Sleeping,
    WakingUp;

    companion object {
        fun fromBackendString(value: String?): RobotState {
            return entries.firstOrNull { it.name.equals(value, ignoreCase = true) } ?: Speaking
        }
    }
}

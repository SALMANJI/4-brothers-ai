package com.fourbro.ai.ui.home

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fourbro.ai.automation.ReminderScheduler
import com.fourbro.ai.automation.SafeAutomationManager
import com.fourbro.ai.config.FourBroEditableConfig
import com.fourbro.ai.data.local.ChatMessageEntity
import com.fourbro.ai.data.local.FinanceCalculator
import com.fourbro.ai.data.local.FinanceSummary
import com.fourbro.ai.data.local.FinanceTransactionEntity
import com.fourbro.ai.data.local.FourBroDatabase
import com.fourbro.ai.data.local.NoteEntity
import com.fourbro.ai.data.local.ReminderEntity
import com.fourbro.ai.data.local.SecurePrefsManager
import com.fourbro.ai.data.local.TaskEntity
import com.fourbro.ai.data.remote.ApiClientFactory
import com.fourbro.ai.data.remote.ChatRequestDto
import com.fourbro.ai.data.remote.DeviceActionDto
import com.fourbro.ai.data.remote.FacebookRequestDto
import com.fourbro.ai.data.remote.FacebookResponseDto
import com.fourbro.ai.data.remote.FourBroApiService
import com.fourbro.ai.data.remote.ResearchRequestDto
import com.fourbro.ai.data.remote.ResearchResponseDto
import com.fourbro.ai.data.remote.ToolResultRequestDto
import com.fourbro.ai.data.remote.YouTubeRequestDto
import com.fourbro.ai.data.remote.YouTubeResponseDto
import com.fourbro.ai.domain.ToolBridge
import com.fourbro.ai.overlay.FloatingRobotService
import com.fourbro.ai.ui.mascot.RobotState
import com.fourbro.ai.voice.HandsFreeVoiceService
import com.fourbro.ai.voice.VoiceController
import com.google.gson.GsonBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class ConnectionStatus(val label: String) {
    Connected("Online"),
    WakingUp("Waking Up..."),
    Offline("Offline Mode"),
    NotConfigured("Setup Backend"),
    AuthError("Token Error")
}

class FourBroViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    val prefs = SecurePrefsManager(context)
    private val db = FourBroDatabase.getInstance(context)
    private val toolBridge = ToolBridge(context, db)
    val voiceController = VoiceController(context, prefs, viewModelScope)

    private var apiService: FourBroApiService? =
        ApiClientFactory.create(prefs.backendUrl, prefs.deviceToken)

    private val _onboardingDone = MutableStateFlow(prefs.onboardingCompleted)
    val onboardingDone: StateFlow<Boolean> = _onboardingDone

    private val _darkTheme = MutableStateFlow(prefs.darkTheme)
    val darkTheme: StateFlow<Boolean> = _darkTheme

    private val _currentSessionId = MutableStateFlow("session_default")
    val currentSessionId: StateFlow<String> = _currentSessionId

    private val _connectionStatus = MutableStateFlow(
        if (prefs.backendUrl.isBlank()) ConnectionStatus.NotConfigured else ConnectionStatus.WakingUp
    )
    val connectionStatus: StateFlow<ConnectionStatus> = _connectionStatus

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _robotState = MutableStateFlow(RobotState.Idle)
    val robotState: StateFlow<RobotState> = _robotState

    private val _pendingConfirmation = MutableStateFlow<Pair<String, List<DeviceActionDto>>?>(null)
    val pendingConfirmation: StateFlow<Pair<String, List<DeviceActionDto>>?> = _pendingConfirmation

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner

    // Live DB Streams
    val notes = db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reminders = db.reminderDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasks = db.taskDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions = db.financeDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val financeSummary: StateFlow<FinanceSummary> = combine(transactions) { arr ->
        FinanceCalculator.computeSummary(arr[0])
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        FinanceCalculator.computeSummary(emptyList())
    )

    val sessionIds = db.chatDao().observeSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages = _currentSessionId
        .flatMapLatest { sid -> db.chatDao().observeSession(sid) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Studio & Research States
    private val _researchResult = MutableStateFlow<ResearchResponseDto?>(null)
    val researchResult: StateFlow<ResearchResponseDto?> = _researchResult

    private val _youtubeResult = MutableStateFlow<YouTubeResponseDto?>(null)
    val youtubeResult: StateFlow<YouTubeResponseDto?> = _youtubeResult

    private val _facebookResult = MutableStateFlow<FacebookResponseDto?>(null)
    val facebookResult: StateFlow<FacebookResponseDto?> = _facebookResult

    init {
        viewModelScope.launch {
            voiceController.isListening.collect { listening ->
                if (listening) _robotState.value = RobotState.Listening
            }
        }
        viewModelScope.launch {
            voiceController.isSpeaking.collect { speaking ->
                if (speaking) {
                    _robotState.value = RobotState.Speaking
                } else if (_robotState.value == RobotState.Speaking) {
                    _robotState.value = RobotState.Idle
                }
            }
        }
        pingBackendHealth()
    }

    fun getGreetingText(): String {
        val name = prefs.ownerName
        return when (prefs.preferredLanguage) {
            "ur" -> String.format(FourBroEditableConfig.GREETING_URDU, name)
            "en" -> String.format(FourBroEditableConfig.GREETING_ENGLISH, name)
            else -> String.format(FourBroEditableConfig.GREETING_ROMAN_URDU, name)
        }
    }

    fun completeOnboarding(name: String, language: String, backendUrl: String) {
        prefs.ownerName = name
        prefs.preferredLanguage = language
        if (backendUrl.isNotBlank()) {
            prefs.backendUrl = backendUrl
            apiService = ApiClientFactory.create(prefs.backendUrl, prefs.deviceToken)
        }
        prefs.onboardingCompleted = true
        _onboardingDone.value = true
        pingBackendHealth()
    }

    fun updateSettings(
        ownerName: String,
        language: String,
        backendUrl: String,
        deviceToken: String,
        customPersonality: String,
        voiceSpeed: Float,
        voiceVolume: Float,
        voiceMuted: Boolean,
        darkTheme: Boolean
    ) {
        prefs.ownerName = ownerName
        prefs.preferredLanguage = language
        prefs.backendUrl = backendUrl
        prefs.deviceToken = deviceToken
        prefs.customPersonality = customPersonality
        prefs.voiceSpeed = voiceSpeed
        prefs.voiceVolume = voiceVolume
        prefs.voiceMuted = voiceMuted
        prefs.darkTheme = darkTheme
        _darkTheme.value = darkTheme
        apiService = ApiClientFactory.create(prefs.backendUrl, prefs.deviceToken)
        _statusBanner.value = "Settings mehfooz ho gayi hain!"
        pingBackendHealth()
    }

    fun pingBackendHealth() {
        val service = apiService
        if (service == null) {
            _connectionStatus.value = ConnectionStatus.NotConfigured
            return
        }
        viewModelScope.launch {
            _connectionStatus.value = ConnectionStatus.WakingUp
            try {
                val res = withContext(Dispatchers.IO) { service.health() }
                _connectionStatus.value = if (res.isSuccessful) {
                    ConnectionStatus.Connected
                } else {
                    ConnectionStatus.Offline
                }
            } catch (_: Exception) {
                _connectionStatus.value = ConnectionStatus.Offline
            }
        }
    }

    fun startNewSession() {
        _currentSessionId.value = "session_${UUID.randomUUID().toString().take(8)}"
    }

    fun sendMessage(rawText: String) {
        val text = rawText.trim()
        if (text.isEmpty() || _isProcessing.value) return

        viewModelScope.launch {
            val sid = _currentSessionId.value
            withContext(Dispatchers.IO) {
                db.chatDao().insert(
                    ChatMessageEntity(sessionId = sid, role = "user", text = text)
                )
            }

            val service = apiService
            if (service == null) {
                _robotState.value = RobotState.Warning
                val msg = "Backend HTTPS URL set nahi hai. Settings mein Backend URL daalein, ya neeche Notes/Reminders/Finance tabs offline istemal karein."
                withContext(Dispatchers.IO) {
                    db.chatDao().insert(
                        ChatMessageEntity(sessionId = sid, role = "assistant", text = msg, robotState = "Warning")
                    )
                }
                return@launch
            }

            _isProcessing.value = true
            _robotState.value = RobotState.Thinking

            try {
                val personalityHint = prefs.customPersonality.ifBlank {
                    FourBroEditableConfig.DEFAULT_CUSTOM_PERSONALITY
                }
                val res = withContext(Dispatchers.IO) {
                    service.chat(
                        ChatRequestDto(
                            sessionId = sid,
                            message = "$text\n[Owner Style Preference: $personalityHint]",
                            preferredLanguage = prefs.preferredLanguage,
                            ownerName = prefs.ownerName
                        )
                    )
                }

                if (res.code() == 401) {
                    _connectionStatus.value = ConnectionStatus.AuthError
                    _robotState.value = RobotState.Error
                    insertAssistantMessage(sid, "Device Token ghalat ya missing hai. Settings mein sahi token daalein.", "Error")
                    return@launch
                }

                val body = res.body()
                if (body == null) {
                    _robotState.value = RobotState.Warning
                    insertAssistantMessage(
                        sid,
                        "AI service is waqt unavailable hai (Code ${res.code()}). Offline Notes/Reminders/Finance tabs chal rahe hain.",
                        "Warning"
                    )
                    return@launch
                }

                _connectionStatus.value = ConnectionStatus.Connected
                val parsedState = RobotState.fromBackendString(body.robotState)
                _robotState.value = parsedState

                insertAssistantMessage(sid, body.displayText, body.robotState, body.ttsSpeechText)
                voiceController.speak(body.ttsSpeechText, body.detectedLanguage, service)

                if (body.requiresConfirmation && body.deviceActions.isNotEmpty()) {
                    _robotState.value = RobotState.Waiting
                    _pendingConfirmation.value = (body.confirmationPrompt ?: "Kya main yeh action poora karoon?") to body.deviceActions
                } else if (body.deviceActions.isNotEmpty()) {
                    executeDeviceActions(sid, body.deviceActions)
                }
            } catch (_: Exception) {
                _connectionStatus.value = ConnectionStatus.Offline
                _robotState.value = RobotState.Error
                insertAssistantMessage(
                    sid,
                    "Internet ya Backend server se rabta nahi ho saka. Offline tabs (Notes, Tasks, Finance) bilkul kaam kar rahe hain.",
                    "Error"
                )
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun confirmPendingActions(approved: Boolean) {
        val pending = _pendingConfirmation.value ?: return
        _pendingConfirmation.value = null
        val sid = _currentSessionId.value

        if (!approved) {
            _robotState.value = RobotState.Idle
            viewModelScope.launch {
                insertAssistantMessage(sid, "Theek hai, maine woh action cancel kar diya.", "Idle")
            }
            return
        }

        viewModelScope.launch {
            executeDeviceActions(sid, pending.second)
        }
    }

    private suspend fun executeDeviceActions(sessionId: String, actions: List<DeviceActionDto>) {
        _robotState.value = RobotState.Working
        val summaries = mutableListOf<String>()
        var allSuccess = true

        for (action in actions) {
            val report = withContext(Dispatchers.IO) { toolBridge.executeAction(action) }
            if (report.status != "success") allSuccess = false
            summaries.add(report.summary)

            apiService?.let { service ->
                runCatching {
                    withContext(Dispatchers.IO) {
                        service.reportToolResult(
                            ToolResultRequestDto(
                                sessionId = sessionId,
                                tool = report.tool,
                                status = report.status,
                                summary = report.summary
                            )
                        )
                    }
                }
            }
        }

        val finalState = if (allSuccess) "Success" else "Warning"
        _robotState.value = RobotState.fromBackendString(finalState)
        insertAssistantMessage(sessionId, summaries.joinToString("\n"), finalState)
    }

    private suspend fun insertAssistantMessage(
        sessionId: String,
        text: String,
        robotState: String,
        ttsText: String = ""
    ) {
        withContext(Dispatchers.IO) {
            db.chatDao().insert(
                ChatMessageEntity(
                    sessionId = sessionId,
                    role = "assistant",
                    text = text,
                    ttsText = ttsText,
                    robotState = robotState
                )
            )
        }
    }

    // --- Direct Personal Assistant Operations (Offline First) ---
    fun addOrUpdateNote(id: Long = 0, title: String, content: String, category: String, source: String = "text") {
        viewModelScope.launch(Dispatchers.IO) {
            db.noteDao().insert(
                NoteEntity(id = id, title = title, content = content, category = category, source = source)
            )
            _robotState.value = RobotState.Success
        }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { db.noteDao().deleteById(id) }
    }

    fun addReminder(title: String, notes: String, triggerAtMillis: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val entity = ReminderEntity(title = title, notes = notes, triggerAtMillis = triggerAtMillis)
            val id = db.reminderDao().insert(entity)
            ReminderScheduler.schedule(context, entity.copy(id = id))
            _robotState.value = RobotState.Success
        }
    }

    fun cancelReminder(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            ReminderScheduler.cancel(context, id)
            db.reminderDao().updateStatus(id, "CANCELLED")
        }
    }

    fun addTask(title: String, priority: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.taskDao().insert(TaskEntity(title = title, priority = priority))
            _robotState.value = RobotState.Success
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val next = !task.isCompleted
            db.taskDao().setCompleted(task.id, next, if (next) System.currentTimeMillis() else null)
        }
    }

    fun addFinanceEntry(
        type: String,
        amountMajor: Double,
        counterparty: String,
        category: String,
        note: String
    ) {
        if (amountMajor <= 0.0) return
        viewModelScope.launch(Dispatchers.IO) {
            db.financeDao().insert(
                FinanceTransactionEntity(
                    type = type,
                    amountMinor = FinanceCalculator.toMinorUnits(amountMajor),
                    counterparty = counterparty.trim(),
                    category = category.trim().ifEmpty { "General" },
                    note = note.trim()
                )
            )
            _robotState.value = RobotState.Success
        }
    }

    fun reverseFinanceEntry(tx: FinanceTransactionEntity) {
        if (tx.isReversed) return
        viewModelScope.launch(Dispatchers.IO) {
            db.financeDao().markReversed(tx.id)
            _statusBanner.value = "Entry #${tx.id} safely reversed (history preserved)."
        }
    }

    fun exportFinanceCsv() {
        viewModelScope.launch {
            val all = withContext(Dispatchers.IO) { db.financeDao().getAllChronological() }
            val csv = FinanceCalculator.exportCsv(all)
            SafeAutomationManager.executeIntentAction(context, "SHARE_TEXT", csv)
        }
    }

    // --- Studio & Research ---
    fun runWebResearch(query: String, depth: String) {
        val service = apiService ?: run {
            _statusBanner.value = "Internet research ke liye Settings mein Backend URL set karein."
            return
        }
        viewModelScope.launch {
            _isProcessing.value = true
            _robotState.value = RobotState.Working
            try {
                val res = withContext(Dispatchers.IO) {
                    service.research(ResearchRequestDto(query, depth, prefs.preferredLanguage))
                }
                _researchResult.value = res.body()
                _robotState.value = if (res.isSuccessful) RobotState.Success else RobotState.Warning
            } catch (_: Exception) {
                _robotState.value = RobotState.Error
                _statusBanner.value = "Research failed — connection check karein."
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun generateYouTubePackage(
        topic: String,
        format: String,
        durationMin: Double,
        aspectRatio: String,
        style: String,
        useLiveTrends: Boolean
    ) {
        val service = apiService ?: run {
            _statusBanner.value = "YouTube Studio ke liye Settings mein Backend URL set karein."
            return
        }
        viewModelScope.launch {
            _isProcessing.value = true
            _robotState.value = RobotState.Working
            try {
                val res = withContext(Dispatchers.IO) {
                    service.generateYouTube(
                        YouTubeRequestDto(
                            topic = topic,
                            format = format,
                            durationMinutes = durationMin,
                            aspectRatio = aspectRatio,
                            language = prefs.preferredLanguage,
                            style = style,
                            useLiveTrends = useLiveTrends
                        )
                    )
                }
                _youtubeResult.value = res.body()
                _robotState.value = if (res.isSuccessful) RobotState.Success else RobotState.Warning
            } catch (_: Exception) {
                _robotState.value = RobotState.Error
                _statusBanner.value = "YouTube script generation failed."
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun generateFacebookPackage(topic: String, goal: String, includeResearch: Boolean) {
        val service = apiService ?: run {
            _statusBanner.value = "Facebook Manager ke liye Settings mein Backend URL set karein."
            return
        }
        viewModelScope.launch {
            _isProcessing.value = true
            _robotState.value = RobotState.Working
            try {
                val res = withContext(Dispatchers.IO) {
                    service.generateFacebook(
                        FacebookRequestDto(
                            topic = topic,
                            goal = goal,
                            language = prefs.preferredLanguage,
                            includeResearch = includeResearch
                        )
                    )
                }
                _facebookResult.value = res.body()
                _robotState.value = if (res.isSuccessful) RobotState.Success else RobotState.Warning
            } catch (_: Exception) {
                _robotState.value = RobotState.Error
                _statusBanner.value = "Facebook draft generation failed."
            } finally {
                _isProcessing.value = false
            }
        }
    }

    // --- Floating Bubble & Hands-Free ---
    fun startFloatingBubble(): Boolean {
        if (!Settings.canDrawOverlays(context)) {
            SafeAutomationManager.executeIntentAction(context, "OPEN_SETTINGS", "overlay")
            return false
        }
        val intent = Intent(context, FloatingRobotService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        return true
    }

    fun stopFloatingBubble() {
        val intent = Intent(context, FloatingRobotService::class.java).apply {
            action = FloatingRobotService.ACTION_STOP
        }
        context.startService(intent)
    }

    fun toggleHandsFreeMode(enable: Boolean) {
        prefs.handsFreeEnabled = enable
        val intent = Intent(context, HandsFreeVoiceService::class.java)
        if (enable) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            intent.action = HandsFreeVoiceService.ACTION_STOP
            context.startService(intent)
        }
    }

    fun exportAllDataJson() {
        viewModelScope.launch {
            val payload = withContext(Dispatchers.IO) {
                mapOf(
                    "exportedAt" to System.currentTimeMillis(),
                    "ownerName" to prefs.ownerName,
                    "notes" to notes.value,
                    "reminders" to reminders.value,
                    "tasks" to tasks.value,
                    "financeTransactions" to db.financeDao().getAllChronological()
                )
            }
            val json = GsonBuilder().setPrettyPrinting().create().toJson(payload)
            SafeAutomationManager.executeIntentAction(context, "SHARE_TEXT", json)
        }
    }

    fun deleteAllUserData() {
        viewModelScope.launch(Dispatchers.IO) {
            db.noteDao().deleteAll()
            db.reminderDao().deleteAll()
            db.taskDao().deleteAll()
            db.financeDao().deleteAll()
            db.chatDao().deleteAll()
            prefs.clearAll()
            _statusBanner.value = "Tamam local data safely delete ho gaya hai."
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun repeatLastVoice() {
        voiceController.repeatLast(apiService)
    }

    override fun onCleared() {
        voiceController.release()
        super.onCleared()
    }
}

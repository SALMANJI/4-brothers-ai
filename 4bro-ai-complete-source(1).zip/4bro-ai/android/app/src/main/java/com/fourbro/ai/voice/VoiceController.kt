package com.fourbro.ai.voice

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import com.fourbro.ai.data.local.SecurePrefsManager
import com.fourbro.ai.data.remote.FourBroApiService
import com.fourbro.ai.data.remote.SynthesizeRequestDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class VoiceController(
    private val context: Context,
    private val prefs: SecurePrefsManager,
    private val scope: CoroutineScope
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var androidTts: TextToSpeech? = null
    private var androidTtsReady = false
    private var mediaPlayer: MediaPlayer? = null

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude

    private var lastSpokenText: String = ""
    private var lastSpokenLang: String = "roman_ur"

    init {
        androidTts = TextToSpeech(context.applicationContext) { status ->
            androidTtsReady = status == TextToSpeech.SUCCESS
            if (androidTtsReady) {
                androidTts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            }
        }
    }

    fun startListening(
        languageCode: String,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        stopSpeaking() // Interrupt TTS smoothly when user wants to speak

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Is device par Speech Recognition available nahi hai.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val bcp47 = when (languageCode) {
            "ur" -> "ur-PK"
            "en" -> "en-US"
            else -> "ur-PK" // Handles Roman Urdu / mixed Pakistani speech best via ur-PK
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, bcp47)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                _amplitude.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
                _amplitude.value = 0f
            }

            override fun onError(error: Int) {
                _isListening.value = false
                _amplitude.value = 0f
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Awaaz saaf sunai nahi di, dobara bolein."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Koi awaaz nahi mili."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required hai."
                    SpeechRecognizer.ERROR_NETWORK -> "Internet connection check karein."
                    else -> "Voice recognition error ($error)."
                }
                onError(msg)
            }

            override fun onResults(results: Bundle?) {
                _isListening.value = false
                _amplitude.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim().orEmpty()
                if (text.isNotEmpty()) {
                    onResult(text)
                } else {
                    onError("Koi alfaaz record nahi hue.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        _isListening.value = false
        _amplitude.value = 0f
        speechRecognizer?.stopListening()
    }

    fun speak(
        text: String,
        detectedLanguage: String,
        apiService: FourBroApiService?
    ) {
        if (text.isBlank()) return
        lastSpokenText = text
        lastSpokenLang = detectedLanguage
        if (prefs.voiceMuted) return

        stopSpeaking()

        scope.launch {
            val azureLang = if (detectedLanguage == "en") "en-US" else "ur-PK"
            if (apiService != null) {
                val playedCloud = try {
                    val res = withContext(Dispatchers.IO) {
                        apiService.synthesize(
                            SynthesizeRequestDto(
                                text = text,
                                language = azureLang,
                                rate = prefs.voiceSpeed,
                                volume = prefs.voiceVolume
                            )
                        )
                    }
                    val audioB64 = res.body()?.audioBase64
                    if (res.isSuccessful && !audioB64.isNullOrBlank()) {
                        playBase64Mp3(audioB64)
                        true
                    } else {
                        false
                    }
                } catch (_: Exception) {
                    false
                }
                if (playedCloud) return@launch
            }
            speakOfflineFallback(text, detectedLanguage)
        }
    }

    fun repeatLast(apiService: FourBroApiService?) {
        if (lastSpokenText.isNotBlank()) {
            speak(lastSpokenText, lastSpokenLang, apiService)
        }
    }

    private fun playBase64Mp3(base64Audio: String) {
        val bytes = Base64.decode(base64Audio, Base64.DEFAULT)
        val tempFile = File.createTempFile("4bro_tts_", ".mp3", context.cacheDir)
        tempFile.writeBytes(bytes)

        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(tempFile.absolutePath)
            val vol = prefs.voiceVolume.coerceIn(0.1f, 1.0f)
            setVolume(vol, vol)
            setOnPreparedListener {
                _isSpeaking.value = true
                it.start()
            }
            setOnCompletionListener {
                _isSpeaking.value = false
                tempFile.delete()
            }
            setOnErrorListener { _, _, _ ->
                _isSpeaking.value = false
                tempFile.delete()
                true
            }
            prepareAsync()
        }
    }

    private fun speakOfflineFallback(text: String, lang: String) {
        if (!androidTtsReady) return
        val locale = if (lang == "en") Locale.US else Locale("ur", "PK")
        androidTts?.language = locale
        androidTts?.setSpeechRate(prefs.voiceSpeed)
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, prefs.voiceVolume)
        }
        androidTts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "4bro_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        _isSpeaking.value = false
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            mediaPlayer?.reset()
        } catch (_: Exception) {
        }
        androidTts?.stop()
    }

    fun release() {
        stopListening()
        stopSpeaking()
        speechRecognizer?.destroy()
        mediaPlayer?.release()
        androidTts?.shutdown()
    }
}

package com.fourbro.ai.data.remote

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClientFactory {

    fun create(baseUrl: String, deviceToken: String): FourBroApiService? {
        val cleanUrl = baseUrl.trim().trimEnd('/')
        if (!cleanUrl.startsWith("https://")) {
            return null // Security rule: production backend traffic uses HTTPS only
        }

        val authInterceptor = Interceptor { chain ->
            val req = chain.request().newBuilder()
                .addHeader("x-4bro-token", deviceToken)
                .addHeader("Content-Type", "application/json")
                .build()
            chain.proceed(req)
        }

        val client = OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .connectTimeout(45, TimeUnit.SECONDS) // Allows Render free tier cold-start wake
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(45, TimeUnit.SECONDS)
            .build()

        return Retrofit.Builder()
            .baseUrl("$cleanUrl/")
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FourBroApiService::class.java)
    }
}

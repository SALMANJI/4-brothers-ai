package com.fourbro.ai.automation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.fourbro.ai.data.local.FourBroDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootRescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val upcoming = FourBroDatabase.getInstance(context)
                    .reminderDao()
                    .getUpcoming(System.currentTimeMillis())
                upcoming.forEach { reminder ->
                    ReminderScheduler.schedule(context, reminder)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}

package com.fourbro.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class FourBroApp : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java) ?: return
            val channels = listOf(
                NotificationChannel(
                    CHANNEL_REMINDERS,
                    getString(R.string.reminder_notification_channel),
                    NotificationManager.IMPORTANCE_HIGH
                ),
                NotificationChannel(
                    CHANNEL_OVERLAY,
                    getString(R.string.overlay_notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                ),
                NotificationChannel(
                    CHANNEL_VOICE,
                    getString(R.string.voice_notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            channels.forEach { manager.createNotificationChannel(it) }
        }
    }

    companion object {
        const val CHANNEL_REMINDERS = "fourbro_reminders"
        const val CHANNEL_OVERLAY = "fourbro_overlay"
        const val CHANNEL_VOICE = "fourbro_voice"
    }
}

package com.fourbro.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val category: String = "General",
    val source: String = "text", // "text" | "voice"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val notes: String = "",
    val triggerAtMillis: Long,
    val status: String = "SCHEDULED", // "SCHEDULED" | "TRIGGERED" | "CANCELLED"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val priority: String = "MEDIUM", // "LOW" | "MEDIUM" | "HIGH"
    val dueAtMillis: Long? = null,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Immutable financial ledger row.
 * Corrections MUST insert a reversal or adjustment row rather than silently mutating history.
 */
@Entity(tableName = "finance_transactions")
data class FinanceTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // INCOME | EXPENSE | RECEIVABLE | PAYABLE | PAYMENT_RECEIVED | PAYMENT_MADE
    val amountMinor: Long, // Stored in paisa/cents (PKR * 100) for exact math
    val currency: String = "PKR",
    val counterparty: String = "",
    val category: String = "General",
    val note: String = "",
    val isReversed: Boolean = false,
    val reversesTransactionId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: String,
    val role: String, // "user" | "assistant" | "system"
    val text: String,
    val ttsText: String = "",
    val robotState: String = "Idle",
    val createdAt: Long = System.currentTimeMillis()
)

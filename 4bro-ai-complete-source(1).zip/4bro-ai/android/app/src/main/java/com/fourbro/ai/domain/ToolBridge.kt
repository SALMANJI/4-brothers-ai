package com.fourbro.ai.domain

import android.content.Context
import com.fourbro.ai.automation.ReminderScheduler
import com.fourbro.ai.automation.SafeAutomationManager
import com.fourbro.ai.data.local.FinanceCalculator
import com.fourbro.ai.data.local.FinanceTransactionEntity
import com.fourbro.ai.data.local.FourBroDatabase
import com.fourbro.ai.data.local.NoteEntity
import com.fourbro.ai.data.local.ReminderEntity
import com.fourbro.ai.data.local.TaskEntity
import com.fourbro.ai.data.remote.DeviceActionDto
import java.time.Instant

data class ToolExecutionReport(
    val tool: String,
    val status: String, // "success" | "error" | "cancelled"
    val summary: String
)

class ToolBridge(
    private val context: Context,
    private val db: FourBroDatabase
) {
    suspend fun executeAction(action: DeviceActionDto): ToolExecutionReport {
        val args = action.args
        fun str(key: String, default: String = ""): String =
            args[key]?.takeIf { !it.isJsonNull }?.asString ?: default

        fun dbl(key: String, default: Double = 0.0): Double =
            args[key]?.takeIf { !it.isJsonNull }?.asDouble ?: default

        return try {
            when (action.tool) {
                "note.create" -> {
                    val title = str("title", "4BRO Note")
                    val content = str("content")
                    val category = str("category", "General")
                    val source = str("source", "text")
                    val id = db.noteDao().insert(
                        NoteEntity(title = title, content = content, category = category, source = source)
                    )
                    ToolExecutionReport(action.tool, "success", "Note #$id '$title' mehfooz ho gaya.")
                }

                "note.search" -> {
                    val query = str("query")
                    val matches = db.noteDao().search(query)
                    val summary = if (matches.isEmpty()) {
                        "'$query' se milta koi note nahi mila."
                    } else {
                        "${matches.size} note(s) mile: ${matches.take(3).joinToString { it.title }}"
                    }
                    ToolExecutionReport(action.tool, "success", summary)
                }

                "reminder.create" -> {
                    val title = str("title", "Reminder")
                    val iso = str("triggerAtIso")
                    val notes = str("notes")
                    val triggerMillis = runCatching { Instant.parse(iso).toEpochMilli() }
                        .getOrElse { System.currentTimeMillis() + 3600_000L }

                    val entity = ReminderEntity(
                        title = title,
                        notes = notes,
                        triggerAtMillis = triggerMillis,
                        status = "SCHEDULED"
                    )
                    val id = db.reminderDao().insert(entity)
                    val scheduled = ReminderScheduler.schedule(context, entity.copy(id = id))
                    val msg = if (scheduled) {
                        "Reminder #$id '$title' schedule ho gaya."
                    } else {
                        "Reminder #$id database mein save hua, lekin alarm permission/waqt check karein."
                    }
                    ToolExecutionReport(action.tool, if (scheduled) "success" else "error", msg)
                }

                "reminder.list" -> {
                    val upcoming = db.reminderDao().getUpcoming(System.currentTimeMillis())
                    val msg = if (upcoming.isEmpty()) {
                        "Koi upcoming reminder nahi hai."
                    } else {
                        "${upcoming.size} upcoming reminders: ${upcoming.take(3).joinToString { it.title }}"
                    }
                    ToolExecutionReport(action.tool, "success", msg)
                }

                "task.create" -> {
                    val title = str("title", "Task")
                    val priority = str("priority", "MEDIUM")
                    val dueIso = str("dueAtIso")
                    val dueMillis = dueIso.takeIf { it.isNotBlank() }?.let {
                        runCatching { Instant.parse(it).toEpochMilli() }.getOrNull()
                    }
                    val id = db.taskDao().insert(
                        TaskEntity(title = title, priority = priority, dueAtMillis = dueMillis)
                    )
                    ToolExecutionReport(action.tool, "success", "Task #$id '$title' ($priority) add ho gaya.")
                }

                "task.complete" -> {
                    val key = str("taskTitleOrId").lowercase()
                    val pending = db.taskDao().getPending()
                    val match = pending.firstOrNull {
                        it.id.toString() == key || it.title.lowercase().contains(key)
                    }
                    if (match != null) {
                        db.taskDao().setCompleted(match.id, true, System.currentTimeMillis())
                        ToolExecutionReport(action.tool, "success", "Task '${match.title}' complete mark ho gaya.")
                    } else {
                        ToolExecutionReport(action.tool, "error", "Pending task '$key' nahi mila.")
                    }
                }

                "finance.record" -> {
                    val type = str("type", "EXPENSE")
                    val amount = dbl("amount", 0.0)
                    if (amount <= 0.0) {
                        return ToolExecutionReport(action.tool, "error", "Amount 0 se zyada honi chahiye.")
                    }
                    val currency = str("currency", "PKR")
                    val counterparty = str("counterparty")
                    val category = str("category", "General")
                    val note = str("note")
                    val minor = FinanceCalculator.toMinorUnits(amount)
                    val id = db.financeDao().insert(
                        FinanceTransactionEntity(
                            type = type,
                            amountMinor = minor,
                            currency = currency,
                            counterparty = counterparty,
                            category = category,
                            note = note
                        )
                    )
                    val formatted = FinanceCalculator.formatAmount(minor, currency)
                    val who = if (counterparty.isNotBlank()) " ($counterparty)" else ""
                    ToolExecutionReport(action.tool, "success", "Finance entry #$id [$type] $formatted$who save ho gayi.")
                }

                "finance.summary" -> {
                    val all = db.financeDao().getAllChronological()
                    val summary = FinanceCalculator.computeSummary(all)
                    val filterPerson = str("counterparty").lowercase()
                    val msg = if (filterPerson.isNotBlank()) {
                        val match = summary.counterpartyBalances.firstOrNull {
                            it.counterparty.lowercase().contains(filterPerson)
                        }
                        if (match == null) {
                            "$filterPerson ka koi baqaya hisaab nahi hai."
                        } else if (match.netReceivableMinor > 0) {
                            "${match.counterparty} se ${FinanceCalculator.formatAmount(match.netReceivableMinor)} lene hain."
                        } else {
                            "${match.counterparty} ko ${FinanceCalculator.formatAmount(-match.netReceivableMinor)} dene hain."
                        }
                    } else {
                        "Income: ${FinanceCalculator.formatAmount(summary.totalIncomeMinor)}, " +
                            "Expense: ${FinanceCalculator.formatAmount(summary.totalExpenseMinor)}, " +
                            "Lene hain: ${FinanceCalculator.formatAmount(summary.totalReceivableMinor)}, " +
                            "Dene hain: ${FinanceCalculator.formatAmount(summary.totalPayableMinor)}."
                    }
                    ToolExecutionReport(action.tool, "success", msg)
                }

                "android.intent" -> {
                    val intentAction = str("action")
                    val target = str("target")
                    val res = SafeAutomationManager.executeIntentAction(context, intentAction, target)
                    ToolExecutionReport(action.tool, if (res.success) "success" else "error", res.message)
                }

                else -> ToolExecutionReport(action.tool, "error", "Unknown device tool: ${action.tool}")
            }
        } catch (e: Exception) {
            ToolExecutionReport(action.tool, "error", e.message ?: "Execution failed")
        }
    }
}

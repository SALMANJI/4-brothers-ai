package com.fourbro.ai

import com.fourbro.ai.ui.mascot.RobotState
import org.junit.Assert.assertEquals
import org.junit.Test

class RobotStateTest {
    @Test
    fun `robot has exactly 12 required states and parses backend names safely`() {
        assertEquals(12, RobotState.entries.size)
        assertEquals(RobotState.Waiting, RobotState.fromBackendString("waiting"))
        assertEquals(RobotState.Working, RobotState.fromBackendString("Working"))
        assertEquals(RobotState.Speaking, RobotState.fromBackendString("unknown_state"))
    }
}

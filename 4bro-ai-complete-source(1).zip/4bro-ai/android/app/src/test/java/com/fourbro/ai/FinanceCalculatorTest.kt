package com.fourbro.ai

import com.fourbro.ai.data.local.FinanceCalculator
import com.fourbro.ai.data.local.FinanceTransactionEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceCalculatorTest {

    @Test
    fun `receivable and partial payment updates counterparty balance accurately`() {
        val txs = listOf(
            FinanceTransactionEntity(
                id = 1,
                type = "RECEIVABLE",
                amountMinor = FinanceCalculator.toMinorUnits(5000.0),
                counterparty = "Waqas",
                note = "Udhaar diya"
            ),
            FinanceTransactionEntity(
                id = 2,
                type = "PAYMENT_RECEIVED",
                amountMinor = FinanceCalculator.toMinorUnits(2000.0),
                counterparty = "Waqas",
                note = "Waqas ne wapis kiye"
            ),
            FinanceTransactionEntity(
                id = 3,
                type = "EXPENSE",
                amountMinor = FinanceCalculator.toMinorUnits(750.0),
                category = "Food"
            )
        )

        val summary = FinanceCalculator.computeSummary(txs)
        assertEquals(200000L, summary.totalIncomeMinor)
        assertEquals(75000L, summary.totalExpenseMinor)
        assertEquals(300000L, summary.totalReceivableMinor)
        assertEquals(0L, summary.totalPayableMinor)
        assertEquals(1, summary.counterpartyBalances.size)
        assertEquals("Waqas", summary.counterpartyBalances[0].counterparty)
        assertEquals(300000L, summary.counterpartyBalances[0].netReceivableMinor)
    }

    @Test
    fun `reversed transactions are excluded while preserving audit history`() {
        val txs = listOf(
            FinanceTransactionEntity(id = 1, type = "INCOME", amountMinor = 100000L, isReversed = true),
            FinanceTransactionEntity(id = 2, type = "INCOME", amountMinor = 250000L, isReversed = false)
        )
        val summary = FinanceCalculator.computeSummary(txs)
        assertEquals(250000L, summary.totalIncomeMinor)

        val csv = FinanceCalculator.exportCsv(txs)
        assertTrue(csv.contains("id,date,type,amount,currency"))
        assertTrue(csv.contains("true"))
        assertTrue(csv.contains("false"))
    }
}

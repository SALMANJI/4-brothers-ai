# 4BRO AI ProGuard / R8 Keep Rules
-keep class com.fourbro.ai.data.remote.** { *; }
-keep class com.fourbro.ai.data.local.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**

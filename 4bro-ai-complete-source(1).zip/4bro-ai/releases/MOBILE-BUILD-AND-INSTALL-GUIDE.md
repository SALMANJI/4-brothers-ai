# 4BRO AI — Mobile Phone Se Asli APK Banane Aur Chalane Ki Step-by-Step Guide

*(Is poore process mein PC ki bilkul zaroorat nahi hai.)*

---

## Step 1: GitHub Account Aur Code Upload (Free)
1. Phone ke Chrome browser mein `https://github.com` kholein aur **Sign up** karke free account banayein.
2. **Create a new repository** dabayein -> naam rakhein `4bro-ai` -> **Create repository**.
3. Is workspace ki `4bro-ai/` files ko is repository mein upload karein (ya Arena se download zip ko phone par extract karke GitHub par upload karein).  
   **Zaroori Check:** Confirm karein ke `.github/workflows/android-apk.yml` file repository ke root mein maujood ho.

---

## Step 2: Asli APK Download Karein (Cloud Build)
1. GitHub par apni `4bro-ai` repository mein upar **Actions** tab dabayein.
2. Wahan **"4BRO AI CI — Backend Tests & Android APK"** workflow chal raha hoga (ya **Run workflow** dabayein).
3. Jab green tick (✓) aa jaye (~3–5 minute baad), us run par tap karein.
4. Bilkul neeche **Artifacts** section mein **`4bro-ai-debug-apk`** par tap karke `.zip` download karein.
5. Phone ke Files app mein zip extract karein -> `app-debug.apk` par tap karein -> **Install** karein (agar Chrome/Files "Unknown apps" ki permission mange to Allow kar dein).

---

## Step 3: Free Backend Server Deploy Karein (Render.com)
1. Phone browser mein `https://render.com` par free account banayein (**Continue with GitHub**).
2. **New +** -> **Web Service** -> apni `4bro-ai` repository select karein.
3. Settings yeh rakhein:
   - **Root Directory:** `backend`
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
   - **Instance Type:** `Free`
4. **Environment Variables** mein yeh add karein:
   - `NODE_ENV` = `production`
   - `FOURBRO_DEVICE_TOKEN` = *(Koi bhi lamba secret password likhein, jaise `My4BroSecret2026_9988`)*
   - `GEMINI_API_KEY` = *(Google AI Studio `aistudio.google.com` se free key)*
   - `GROQ_API_KEY` = *(Optional backup & Whisper voice ke liye `console.groq.com` se free key)*
   - `AZURE_SPEECH_KEY` = *(Optional natural Pakistani male Urdu voice ke liye Azure F0 free key)*
   - `AZURE_SPEECH_REGION` = `southeastasia`
   - `TAVILY_API_KEY` = *(Real internet research ke liye `tavily.com` free key)*
5. **Create Web Service** dabayein. Jab live ho jaye, aapko aisa HTTPS URL milega:  
   `https://fourbro-ai-xxxx.onrender.com`

---

## Step 4: 4BRO AI App Ko Connect Karein
1. Phone mein **4BRO AI** app kholein.
2. Onboarding ya **Settings** tab mein jayein:
   - **Backend HTTPS URL:** Render wala URL paste karein.
   - **FOURBRO_DEVICE_TOKEN:** Wohi token paste karein jo Step 3 mein likha tha.
3. **Tamam Settings Save Karein** dabayein -> Home screen par status **● Online** ho jayega!

# 4BRO AI — Khud Modify Karne Ki Asaan Guide (Beginner Friendly)

Aap bina PC aur bina mushkil coding ke **2 tareeqon** se apni **4BRO AI** app ko khud badal (modify) kar sakte hain:

---

## Tareeqa 1: App Ke Andar Se Live Modify Karein (Sab se Asaan — Nayi APK ki zaroorat nahi!)
App khol kar **Settings** tab mein jayein. Wahan aap foran yeh sab khud badal sakte hain:
1. **Aapka Naam:** Greeting mein apna naam badlein.
2. **4BRO AI Personality Style:** Likh dein ke 4BRO kaise baat kare (maslan: *"Zyada friendly, short jawab de aur halka sa mazaahiya ho"*).
3. **Zubaan (Language):** `Roman Urdu`, `اردو`, ya `English`.
4. **Voice Speed & Volume:** Male awaaz ki tezi (`0.7x` se `1.5x`) aur volume.
5. **Dark Navy / Light Mode:** Ek tap mein theme badlein.
6. **Backend URL & Device Token:** Agar kabhi server badalna ho to yahan paste karein.
7. **Floating Bubble & Hands-Free Mode:** Jab chahein ON/OFF karein.

---

## Tareeqa 2: Mobile Phone Par GitHub Se App Ka Design / Buttons Badalna
Agar aap App ka naam, Greeting lines, Rang (Colors), ya Home Screen ke Quick Action buttons khud badalna chahte hain:

1. Apne phone mein **GitHub App** ya **Chrome Browser** mein apni repository kholein.
2. Neeche di gayi **sirf in asaan files** mein se kisi ko kholein aur **Pencil (Edit)** icon dabayein:
   - **Greeting, App Title & Quick Action Buttons badalne ke liye:**  
     `android/app/src/main/java/com/fourbro/ai/config/FourBroEditableConfig.kt`
   - **App ke Rang (Colors) badalne ke liye:**  
     `android/app/src/main/java/com/fourbro/ai/ui/theme/Color.kt`
   - **AI ke Rules / Tone badalne ke liye:**  
     `backend/src/services/aiBrain.ts` (`buildSystemPrompt` function)
3. Sirf double quotes `"..."` ke andar ka text badlein (brackets `{}` ya commas `,` na hatayein).
4. Upar **Commit changes** dabayein.
5. GitHub **khud-ba-khud** 3–4 minute mein nayi `.apk` compile kar dega jise aap download karke update install kar sakte hain!

# 4BRO AI — Branding, Visual Identity & 4BRO Robot 12-State Specification

## 1. Brand Identity & Color System

- **Brand Name:** 4BRO AI
- **Tagline:** *Aapka Apna Smart Dost* (Your Personal Smart Assistant)
- **Visual Personality:** Futuristic, Deep Navy, Crisp Electric Cyan Glow, Minimal Clutter, High Readability.

### Official Color Palette
| Token | Hex | Usage |
|---|---|---|
| `NavyDeep` | `#070D1F` | Primary screen background |
| `NavySurface` | `#0D1630` | Cards, chat bubbles (AI), sheets |
| `NavyElevated` | `#132042` | Elevated panels, quick action chips |
| `PureBlackGlass` | `#040711` | Top bar / bottom bar / overlay backdrop |
| `CyanGlow` | `#00D4FF` | Primary accent, active mic ring, robot visor |
| `SoftBlueGlow` | `#38BDF8` | Secondary highlights, focus states |
| `RoyalBlueAccent` | `#2563EB` | User chat bubble, primary CTA gradient end |
| `SuccessEmerald` | `#10B981` | Task complete, online status, verified checks |
| `WarningAmber` | `#F59E0B` | Permission warnings, cold-start wake notice |
| `ErrorCrimson` | `#EF4444` | Errors, destructive delete actions |
| `TextPrimary` | `#F8FAFC` | Primary headings & messages |
| `TextSecondary` | `#94A3B8` | Timestamps, hints, secondary labels |

### Typography
- **Display / Headings:** `Plus Jakarta Sans` / `Space Grotesk` (SemiBold / Bold)
- **UI & Roman Urdu / English Body:** `Inter` (Regular / Medium, min 14sp body, 12sp captions)
- **Urdu Script Support:** `Noto Nastaliq Urdu` or Android system `Noto Sans Arabic` fallback with extra `lineHeight` (`1.6x`) so Urdu glyphs never clip.

---

## 2. The 4BRO Robot Character (Canonical Design Spec)

To ensure **100% consistency** across Splash, Home, Chat, and Floating Bubble:
- **Proportions:** Compact chibi-futuristic torso + rounded square/capsule head (`head : body` ratio = `1.25 : 1`).
- **Head:** Deep Midnight Metallic (`#162447`) outer shell, rounded corners (`rx=28`), glowing cyan side ear-nodes (`#00D4FF`), single rounded-rectangle **Dark Glass Visor** (`#030816`) with glowing cyan eyes (`#00F0FF`) and subtle mouth/waveform bar.
- **Antenna:** Single centered flexible stem with a glowing cyan orb tip (`#38BDF8`) that changes pulse/color strictly for state cues (never changing head shape).
- **Body:** Rounded capsule chest with glowing **"4B"** micro-emblem core, two floating pill-shaped stubby arms that gesture subtly without detaching from visual balance.
- **Rule:** Face visor proportions, ear-nodes, antenna, and body silhouette NEVER change between states—only eye expressions, mouth/waveform, antenna glow, arm tilt, and subtle float offset animate.

---

## 3. All 12 Required Animation States

| # | State | Visual Animation Description | Trigger Condition | Duration / Transition | Return State | Performance Target |
|---|---|---|---|---|---|---|
| 1 | **Idle** | Gentle 3px vertical hover (2.8s sine loop), soft eye blink every 3.5–5s, calm cyan chest core pulse | App idle on Home or Bubble | Continuous loop (150ms crossfade on entry) | Remains `Idle` until trigger | `< 1%` CPU, 60fps Compose Canvas |
| 2 | **Listening** | Leaning slightly forward (-4°), ear-nodes expand with concentric cyan sound rings, eyes wide & attentive, mouth converts to real-time mic amplitude waveform | User taps Mic or Hands-Free active | Active while audio stream open | `Thinking` (on speech end) or `Idle` (cancel) | `< 3%` CPU; amplitude sampled at 30Hz |
| 3 | **Thinking** | Eyes look slightly up-right, antenna orb orbits/pulses cyan-blue, 3 subtle dots inside visor, gentle head tilt (+6°) | Speech/text sent to AI Brain; waiting for first token/plan | Loop until tool/response starts (max timeout 30s -> `Warning`/`Error`) | `Processing`, `Working`, or `Speaking` | `< 2%` CPU |
| 4 | **Processing** | Chest "4B" core spins softly, visor displays sleek dual progress chevrons, steady analytical blue glow | Backend parsing intent, normalizing Urdu/Roman Urdu, or running LLM stream | Continuous while response/data streaming | `Working` or `Speaking` or `Success` | `< 2%` CPU |
| 5 | **Speaking** | Eyes happy/curved, mouth waveform syncs smoothly with TTS audio playback / syllable envelope, subtle expressive hand bounce | TTS audio playback active | Duration of spoken audio (immediately stops on Interrupt/Mute) | `Idle` (or `Listening` if Hands-Free) | `< 3%` CPU |
| 6 | **Working** | Arms typing/gesturing rhythmically, antenna flashes fast sky-blue, mini tool badge icon next to chest (Note/Search/YT/Alarm) | Executing local DB write, Web Search, Script generation, or Export | Duration of tool execution | `Success` or `Error` | `< 2%` CPU |
| 7 | **Waiting** | Calm rhythmic breath glow (`#38BDF8`), eyes half-focused blinking slowly, waiting-clock micro ring on antenna | Waiting for user confirmation (e.g., "Publish?", "Delete?", permission dialog) or backend cold-start wake | Until user taps Confirm/Cancel or backend wakes | `Working` or `Idle` | `< 1%` CPU |
| 8 | **Success** | Happy crescent `^ ^` cyan eyes, celebratory quick upward hop (-10px), emerald-cyan (`#10B981` -> `#00D4FF`) ring burst | Task/Note/Reminder/Finance entry saved or action verified complete | `1.4s` one-shot animation | Automatically returns to `Idle` or `Speaking` | `< 2%` CPU |
| 9 | **Warning** | Amber (`#F59E0B`) antenna & visor outline tint, one eyebrow raised / concerned eyes, gentle side-to-side caution nudge | Missing permission, offline mode, uncertain research source, or low balance/conflict | `2.0s` hold (or until dismissed) | `Waiting` or `Idle` | `< 1.5%` CPU |
| 10 | **Error** | Crimson (`#EF4444`) soft visor tint, `x _ x` or dizzy/sad eyes, brief 4px horizontal shake, dropped shoulders | Network failure, API error, mic failed, tool failure | `1.8s` hold + clear error message shown | `Idle` | `< 1.5%` CPU |
| 11 | **Sleeping** | Dimmed navy-blue glow (25% opacity), closed peaceful `- -` eyes, floating mini `Z z` particles, zero chest pulse (battery saver) | No interaction for 45s in Floating Bubble OR 2 min on Home Screen | Low-FPS throttled loop (10fps) to save battery | `WakingUp` on tap/voice | `< 0.3%` CPU |
| 12 | **WakingUp** | Quick stretch upward, visor brightens smoothly `25% -> 100%`, eyes blink open wide, cheerful antenna flash | User taps sleeping robot/bubble OR app resumes | `0.7s` transition animation | `Idle` (or `Listening` if tapped mic) | `< 2%` CPU |

# 4BRO AI — Dynamic Development Roadmap, Feature Inventory & System Architecture

**Workflow:** RESEARCH → PLAN → ARCHITECTURE → DESIGN → IMPLEMENTATION → INTEGRATION → TESTING → ERROR FIXING → VERIFICATION → DELIVERY  
**Rule:** Step count is dynamic. Complex steps split into smaller independent tasks. No step is marked VERIFIED/COMPLETED without concrete test evidence.

---

## 1. Complete Project Folder Structure

```text
4bro-ai/
├── docs/
│   ├── 00-MASTER-PROGRESS.md
│   ├── 01-PROJECT-RESEARCH-AND-FEASIBILITY.md
│   ├── 02-DYNAMIC-ROADMAP-AND-ARCHITECTURE.md
│   ├── 03-BRANDING-AND-4BRO-ROBOT-SPEC.md
│   ├── 04-DATABASE-AND-PRIVACY-SPEC.md
│   ├── 05-TESTING-REPORT.md
│   └── steps/                          # Section-4 full specification per step
│       ├── STEP-001-workspace-and-branding.md
│       └── ...
├── branding/
│   ├── 4bro-logo.svg
│   ├── 4bro-app-icon.svg
│   └── 4bro-robot-mascot.svg
├── backend/                            # Node.js 20 + TypeScript + Fastify API
│   ├── package.json
│   ├── tsconfig.json
│   ├── .env.example
│   ├── src/
│   │   ├── server.ts
│   │   ├── config/env.ts
│   │   ├── middleware/auth.ts
│   │   ├── routes/
│   │   │   ├── health.ts
│   │   │   ├── chat.ts
│   │   │   ├── speech.ts
│   │   │   ├── research.ts
│   │   │   ├── content.ts
│   │   │   └── backup.ts
│   │   ├── services/
│   │   │   ├── aiBrain.ts
│   │   │   ├── intentRouter.ts
│   │   │   ├── toolExecutor.ts
│   │   │   ├── sttService.ts
│   │   │   ├── ttsService.ts
│   │   │   ├── webResearchService.ts
│   │   │   ├── youtubeService.ts
│   │   │   └── facebookService.ts
│   │   └── types/
│   └── tests/
├── android/                            # Native Kotlin + Jetpack Compose App
│   ├── .github/workflows/android-apk.yml
│   ├── build.gradle.kts
│   ├── settings.gradle.kts
│   ├── gradle.properties
│   └── app/
│       ├── build.gradle.kts
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── res/
│           └── java/com/fourbro/ai/
│               ├── FourBroApp.kt
│               ├── MainActivity.kt
│               ├── data/local/          # Room DB, Entities, DAOs, Migrations, SQLCipher/Keystore
│               ├── data/remote/         # Retrofit/OkHttp API client + SSE
│               ├── domain/              # UseCases, ToolBridge, AI Action Verifier
│               ├── voice/               # SpeechRecognizer, AudioRecorder, Azure/Native TTS
│               ├── overlay/             # FloatingRobotService (Android 13-16 compliant)
│               ├── automation/          # Safe Android Intents, Reminders, WorkManager
│               └── ui/
│                   ├── theme/           # Deep Navy, Cyan Glow, Typography
│                   ├── mascot/          # 4BRO Robot 12-state Canvas/Rive Renderer
│                   ├── splash/
│                   ├── onboarding/
│                   ├── home/
│                   ├── assistant/       # Notes, Reminders, Tasks, Finance
│                   ├── studio/          # YouTube & Facebook Managers
│                   ├── research/        # Web Research Reports
│                   └── settings/        # Voice, Privacy, Permissions, Backup/Export
└── releases/                           # Release notes, APK checksums, installation guides
```

---

## 2. Detailed Feature Inventory

| Module | Sub-Features | Execution Layer |
|---|---|---|
| **Branding & 4BRO Robot** | Original logo, app icon, splash screen, 3-step onboarding, 12-state cute cartoon robot (`Idle`, `Listening`, `Thinking`, `Processing`, `Speaking`, `Working`, `Waiting`, `Success`, `Warning`, `Error`, `Sleeping`, `WakingUp`) | Android Compose Canvas + Vector Assets |
| **Home Screen** | Logo, 4BRO Robot, dynamic Urdu/Roman Urdu/English greeting, Chat UI, Mic button, Text box + Send, Hands-free Voice Mode toggle, Conversation History drawer, Quick Actions (Note, Reminder, Expense, YT Script, Research), Notifications badge, Settings, Profile/Privacy, Connection Status pill, AI Processing indicator | Android HomeScreen + ViewModel |
| **AI Brain** | Gemini Flash primary + Groq fallback, Urdu/Roman Urdu/English intent detection, multi-step task planner, strict tool calling, tool result verifier, honest failure/limitation reporting, dual output (`display_text` + `tts_speech_text`) | Backend `aiBrain.ts` + Android `ToolBridge` |
| **Voice Assistant** | Runtime `RECORD_AUDIO` permission, Push-to-talk & Hands-free mode, `ur-PK` + Roman Urdu + `en` STT (Groq Whisper + Android fallback), `ur-PK-AsadNeural` male TTS + speed/volume/language controls, Interrupt, Repeat, Mute | Android `VoiceController` + Backend `speech.ts` |
| **Personal Assistant: Notes** | Add/Edit/Delete/Search/Categorize notes, Voice-to-Note creation | Local Room DB (`notes`) |
| **Personal Assistant: Reminders** | Create/Edit/Cancel reminders, Exact Alarm / WorkManager scheduling, `POST_NOTIFICATIONS` & `SCHEDULE_EXACT_ALARM` handling, Upcoming list | Local Room DB (`reminders`) + Android AlarmManager/Notifications |
| **Personal Assistant: Tasks** | Create tasks, Priority (`LOW/MED/HIGH`), Due dates, Complete toggle, Pending view, Daily AI summary | Local Room DB (`tasks`) |
| **Personal Assistant: Finance** | Income, Expense, Receivable ("lene wale paise" e.g. Waqas), Payable ("dene wale paise"), Partial/Full payment tracking, Immutable Transaction Ledger + Audit Log, Totals & Reports, CSV/JSON Export | Local Room DB (`finance_accounts`, `finance_transactions`) |
| **YouTube Content Manager** | Real-web trending research (with dates & links), Idea generator, Hooks, Full scripts (Shorts & Long-form), Scene-by-scene breakdown (Urdu/Roman Urdu dialogues + English visual/image/video/motion/effects prompts + consistent character bible), Titles, Descriptions, Tags, Hashtags, Thumbnail concepts, Optional YouTube Data API channel stats | Backend `youtubeService.ts` + `webResearchService.ts` + Android Studio UI |
| **Facebook Manager** | Content ideas, Post & Caption writing, Hashtags, Content Calendar, Audience & Monetization research (cited), Post drafting, Explicit-approval Publishing workflow (when Meta Page OAuth connected) | Backend `facebookService.ts` + Android Studio UI |
| **Internet Research** | Real web search, Multi-source comparison, Publication dates, Fact vs Opinion separation, Structured summaries, Mandatory clickable citations, Uncertainty flags, Exportable Markdown/PDF/Text reports | Backend `webResearchService.ts` + Android Research UI |
| **Floating 4BRO Robot** | `SYSTEM_ALERT_WINDOW` guided permission, Draggable bubble, Tap to expand mini-command/open app, Minimize, Close/Stop service, Saved screen coordinates, Battery-conscious idle sleep, Android 14/15/16 `specialUse` FGS compliance | Android `FloatingRobotService.kt` |
| **Safe App Automation** | Launch installed apps, Deep links, Settings shortcuts, Clipboard copy, Android Share Sheet, Intents (no hidden control, no OTP/CAPTCHA/login bypass, confirmation dialog before sensitive actions) | Android `SafeAutomationManager.kt` |
| **Security & Data Controls** | HTTPS TLS, Device Auth Token, Android Keystore encryption, Zero API keys in APK, Input validation, Sensitive-action confirmation, Safe error logs (redacted PII), Backup/Export/Delete All Data, In-app Privacy Policy | Backend + Android Security Layer |

---

## 3. Dynamic Development Roadmap (Phases & Granular Task IDs)

> *Note: Each task ID below expands into a full Section-4 specification file (`A` through `K`) as we enter its phase.*

### Phase 0 — Analysis, Architecture & Branding Foundation
- **T-001** `[COMPLETED]` — Full Project Research, Feasibility Report, Stack Selection & Mobile-Only Strategy
- **T-002** `[COMPLETED]` — Dynamic Roadmap, Folder Structure & Master Progress Tracker Setup
- **T-003** `[IN PROGRESS]` — Original 4BRO AI Brand Identity (Logo SVG, App Icon SVG, 4BRO Robot Mascot Concept & 12-State Specification)

### Phase 1 — Backend Core, Security & AI Brain Foundation (Runnable & Testable Now)
- **T-004** — Backend Project Setup (Node.js + TypeScript + Fastify + Env Validation + Health Endpoint + Automated Tests)
- **T-005** — Device Authentication, Rate Limiting, Input Validation & Safe Logging Middleware
- **T-006** — AI Brain Core (Gemini Flash + Groq Fallback, Multilingual System Prompt for Urdu/Roman Urdu/English, Personality & Honesty Guardrails)
- **T-007** — Intent Classifier, Multi-Task Planner & Strict Tool-Calling Schema (Notes, Reminders, Tasks, Finance, Research, YouTube, Facebook, App Intents)

### Phase 2 — Speech, Web Research & Content Backend Services
- **T-008** — Speech-to-Text Service (Groq `whisper-large-v3-turbo` audio endpoint + Urdu/Roman Urdu normalization)
- **T-009** — Text-to-Speech Service (Azure Neural `ur-PK-AsadNeural` & English male voices + speed/pitch controls + caching)
- **T-010** — Internet Research Engine (Real Web Search API + Page Fetcher + Date/Citation Extractor + Fact vs. Opinion Analyzer)
- **T-011** — YouTube Content Studio Backend (Trending Research, Script/Hook/Scene/Prompt Generator, Character Consistency Bible)
- **T-012** — Facebook Manager Backend (Post/Caption/Hashtag Generator, Calendar, Monetization/Audience Research, Safe Draft Workflow)

### Phase 3 — Android App Skeleton, CI/CD APK Pipeline & Theme
- **T-013** — Android Gradle Project Setup (Kotlin 2.x, Jetpack Compose, Material 3, Hilt/Manual DI, GitHub Actions `.apk` Workflow)
- **T-014** — Design System Implementation (Deep Navy `#070D1F`, Cyan Glow `#00D4FF`, Typography, Accessible Controls)
- **T-015** — 4BRO Robot 12-State Animated Component (Consistent proportions/face, smooth 60fps transitions, low-memory optimization)
- **T-016** — Splash Screen & Beginner-Friendly Onboarding (Language choice, Voice preview, Clear permission explanations)

### Phase 4 — Local Encrypted Database & Core Personal Assistant Modules
- **T-017** — Room Database Architecture, Entities, DAOs, Migrations & Keystore Encryption
- **T-018** — Notes Module (CRUD, Categories, Full-Text Search, Voice-to-Note Integration)
- **T-019** — Reminders & Notification Scheduler (Exact Alarms, Boot Reschedule, `POST_NOTIFICATIONS`, Snooze/Cancel)
- **T-020** — Task Manager Module (Priorities, Due Dates, Completion, Daily Summary)
- **T-021** — Personal Finance & Udhaar/Ledger Module (Income, Expense, Receivable/Payable e.g. "Waqas", Immutable Ledger, Reports, CSV/JSON Export)

### Phase 5 — Home Screen, Chat & AI Tool Bridge
- **T-022** — Main Home Screen UI (All 15 required functional controls, zero dead buttons, responsive layout)
- **T-023** — Conversation Sessions, History Drawer & Context Window Sync
- **T-024** — Android-to-AI Tool Bridge & Action Verification Loop (Executes local DB tools from AI commands, asks user confirmation for sensitive actions, reports real status back to AI)

### Phase 6 — Complete Android Voice Assistant
- **T-025** — Microphone Permission & Audio Capture Controller
- **T-026** — Hybrid Speech Recognition (Android `SpeechRecognizer` + Backend Groq Whisper)
- **T-027** — Natural Male Voice Output Controller (Azure TTS Player + Android TTS Offline Fallback + Speed/Volume/Mute/Interrupt/Repeat)
- **T-028** — Hands-Free Foreground Voice Mode (Compliant with Android microphone FGS rules — honest, battery-aware)

### Phase 7 — Content Studios & Internet Research UI
- **T-029** — YouTube Studio Screen (Duration, Aspect Ratio, Language, Style inputs, Scene-by-Scene viewer, Copyable Prompts, Export)
- **T-030** — Facebook Manager Screen (Content Calendar, Drafts, Approval-gated Publish flow)
- **T-031** — Internet Research Screen (Live Citations, Dates, Uncertainty tags, Report Export)

### Phase 8 — Floating 4BRO Robot Bubble & Safe App Automation
- **T-032** — Overlay Permission Flow & Explainer UI (`SYSTEM_ALERT_WINDOW`)
- **T-033** — `FloatingRobotService` (Android 13–16 `specialUse` FGS, Draggable Bubble, Tap Menu, Saved Position, Stop/Battery Controls)
- **T-034** — Safe App Automation Manager (Launch Apps, Links, Settings Pages, Share Sheet, Clipboard, Confirmation Dialogs)

### Phase 9 — Settings, Privacy, Backup/Export & Optional Cloud Connectors
- **T-035** — Settings, Profile & Privacy Screen (Data Export, Delete All Data, In-App Privacy Policy, Permission Dashboard)
- **T-036** — Encrypted Google Drive / JSON Backup & Restore
- **T-037** — Optional YouTube Data API & Meta Page OAuth Connectors (Only if user connects accounts)

### Phase 10 — End-to-End QA, Security Audit & APK Release
- **T-038** — Automated Backend & Android Unit/UI Test Suite Execution (All 17 required test categories)
- **T-039** — Security & Privacy Penetration Checklist (Zero leaked keys, no PII in logs, input sanitization)
- **T-040** — Signed Release APK Generation via GitHub Actions, Checksum Verification & Mobile Installation Guide

---

## 4. API & External Service Requirements Summary

1. **Google AI Studio (Gemini API)** — Primary AI Brain (`GEMINI_API_KEY` on backend)
2. **Groq Cloud API** — Whisper Speech-to-Text + Backup Llama LLM (`GROQ_API_KEY` on backend)
3. **Microsoft Azure Cognitive Services (Speech)** — `ur-PK-AsadNeural` Male TTS (`AZURE_SPEECH_KEY`, `AZURE_SPEECH_REGION` on backend)
4. **Tavily or Serper API** — Real-time web research & trending verification (`SEARCH_API_KEY` on backend)
5. **GitHub** — Source control + GitHub Actions free Android APK builder
6. **Render.com (or Koyeb)** — Cloud backend hosting (HTTPS endpoint for the Android app)
7. **Optional later:** YouTube Data API v3, Meta Graph API, Google Drive Backup API

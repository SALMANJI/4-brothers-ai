# STEPS T-013 to T-017 & T-021 (Data Layer) — Android Core, Theme, 12-State Robot & Encrypted Room DB

## A. STEP IDENTIFICATION
- **Step IDs:** T-013, T-014, T-015, T-016, T-017, T-021 (Data Core)
- **Development Phases:** Phase 3 & Phase 4 Foundation
- **Priority:** Critical (P0)
- **Status:** `NEEDS TESTING` (Source & JUnit tests written; Gradle compilation awaits GitHub Actions Android SDK runner)

## B. PURPOSE
Establishes the real native Android Kotlin + Jetpack Compose project structure, CI/CD GitHub Actions APK pipeline, Deep Navy + Cyan Glow branding, canonical 12-state 4BRO Robot Canvas component, Splash/Onboarding screens, Keystore-encrypted preferences, and Room SQLite database with an immutable financial ledger.

## F. FILES CREATED
- `.github/workflows/android-apk.yml` & `android/.github/workflows/android-apk.yml`
- `android/settings.gradle.kts`, `android/build.gradle.kts`, `android/gradle.properties`, `android/app/build.gradle.kts`, `android/app/proguard-rules.pro`
- `android/app/src/main/AndroidManifest.xml` (Android 14/15/16 `specialUse` + `microphone` FGS declarations)
- `android/app/src/main/res/values/{strings,colors,themes}.xml` + adaptive launcher icon XMLs
- `android/app/src/main/java/com/fourbro/ai/FourBroApp.kt`
- `android/app/src/main/java/com/fourbro/ai/ui/theme/{Color,Type,Theme}.kt`
- `android/app/src/main/java/com/fourbro/ai/ui/mascot/{RobotState,FourBroRobotMascot}.kt`
- `android/app/src/main/java/com/fourbro/ai/ui/splash/SplashScreen.kt`
- `android/app/src/main/java/com/fourbro/ai/ui/onboarding/OnboardingScreen.kt`
- `android/app/src/main/java/com/fourbro/ai/data/local/{SecurePrefsManager,Entities,Daos,FinanceCalculator,FourBroDatabase}.kt`
- `android/app/src/test/java/com/fourbro/ai/{FinanceCalculatorTest,RobotStateTest}.kt`

## J. COMPLETION CRITERIA
Must pass `gradle testDebugUnitTest assembleDebug` in GitHub Actions once remaining Android screens (`MainActivity`, `HomeScreen`, `Voice`, `FloatingRobotService`, `ReminderReceiver`, etc.) are added in Phases 4–8.

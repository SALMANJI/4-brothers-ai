# STEPS T-005 to T-012 — Backend Security, AI Brain, Voice, Research & Content Studios

## A. STEP IDENTIFICATION
- **Step IDs:** T-005, T-006, T-007, T-008, T-009, T-010, T-011, T-012
- **Development Phases:** Phase 1 & Phase 2 (Complete 4BRO AI Backend API)
- **Priority:** Critical (P0)
- **Dependencies:** T-004 (`health.ts`, `server.ts`, `env.ts`)
- **Estimated Complexity:** High

## B. PURPOSE
Implements the complete secure cloud brain for 4BRO AI: protects third-party API keys off the APK, handles Urdu/Roman Urdu/English AI orchestration with Gemini Flash + Groq fallback, validates strict tool schemas, converts voice via Groq Whisper STT and Azure `ur-PK-AsadNeural` male TTS, conducts real cited web research, and powers YouTube & Facebook content studios.

## C. COMPLETE DESIGN
Headless Fastify 5 JSON API (`1 MB` chat/research limit, `24 MB` speech upload limit) with redacted request logging and structured error responses (`400`, `401`, `503`, `500`).

## D. FUNCTIONAL REQUIREMENTS
- **T-005:** Constant-time token verification (`x-4bro-token` or `Authorization: Bearer`) on all `/api/v1/*` routes; safe error masking.
- **T-006 & T-007:** `POST /api/v1/chat`, `POST /api/v1/chat/tool-result`, `GET /api/v1/sessions/:id`, `DELETE /api/v1/sessions/:id`. Dual `displayText` + markdown-free `ttsSpeechText`, strict `ToolCallSchema` separating `android_client` vs `backend_server` tools, automatic `requiresConfirmation=true` + `robotState="Waiting"` on sensitive Android intents (`SHARE_TEXT`, `OPEN_URL`).
- **T-008 & T-009:** `POST /api/v1/speech/transcribe` (Groq Whisper `whisper-large-v3-turbo`) & `POST /api/v1/speech/synthesize` (Azure Neural `ur-PK-AsadNeural` & `en-US-AndrewNeural` with XML escaping + speed/volume prosody). Honest `503` fallback guidance when keys are missing.
- **T-010:** `POST /api/v1/research/search` (Tavily / Serper) with `retrievedAt`, source publication dates, verified facts vs opinions, uncertainty flags, and exportable Markdown.
- **T-011 & T-012:** `POST /api/v1/content/youtube` & `POST /api/v1/content/facebook` with consistent character bible, scene-by-scene Urdu/Roman Urdu dialogues + English visual/image/video/motion/effects prompts, content calendar, and `approvalRequiredBeforePublish: true`.

## E. TECHNICAL IMPLEMENTATION
- **Language/Framework:** TypeScript 5.7 (ESM), Node.js 20, Fastify 5.1, Zod 3.23.
- **Files Created/Updated:**
  - `backend/src/middleware/auth.ts`
  - `backend/src/services/sessionStore.ts`
  - `backend/src/services/toolSchemas.ts`
  - `backend/src/services/aiBrain.ts`
  - `backend/src/services/speechService.ts`
  - `backend/src/services/webResearchService.ts`
  - `backend/src/services/contentStudioService.ts`
  - `backend/src/routes/chat.ts`
  - `backend/src/routes/speech.ts`
  - `backend/src/routes/research.ts`
  - `backend/src/routes/content.ts`
  - `backend/src/server.ts`

## F. INTEGRATION
- Android Retrofit client attaches `x-4bro-token`, sends user text/voice, executes `deviceActions` against local Room DB, and posts verification back to `/api/v1/chat/tool-result`.

## G. SECURITY
- Timing-safe token comparison (`crypto.timingSafeEqual`).
- XML escaping in Azure SSML prevents SSML injection.
- Invalid LLM-emitted tool names are dropped (`droppedToolCount`), never executed.

## H. TESTING & VERIFICATION
- `npm run build` (`tsc`): **PASS (0 errors)**
- `npm test` (`tsx --test tests/*.test.ts`): **8/8 PASS** across `health.test.ts`, `auth_and_chat.test.ts`, `phase2_services.test.ts`.

## I. COMPLETION CRITERIA & ERROR RECOVERY
- All 8 automated tests pass and TypeScript compiles strictly. -> **MET**
- *Error Recovery:* Missing provider keys return `503` with clear Roman Urdu/Urdu fallback messages so the Android client seamlessly switches to offline Room DB & native Android TTS/STT.

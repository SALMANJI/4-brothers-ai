# STEP-004 — 4BRO AI Backend Core Skeleton & Health Endpoint

## A. STEP IDENTIFICATION
- **Step ID:** T-004
- **Step Title:** Backend Core Setup (Node.js + TypeScript + Fastify + Env Validation + Health Endpoint)
- **Development Phase:** Phase 1 — Backend Core, Security & AI Brain Foundation
- **Priority:** Critical (P0)
- **Dependencies:** T-001 (Research), T-002 (Roadmap & Folder Structure)
- **Estimated Complexity:** Low-Medium

## B. PURPOSE
- Protects all secret API keys (Gemini, Groq, Azure Speech, Search APIs) off the Android APK.
- Provides a central orchestration server that wakes up fast, checks which external services are configured honestly (never faking readiness), and handles rate limiting & safe logging.

## C. COMPLETE DESIGN
- Backend API service (headless JSON API).
- `GET /health` returns JSON payload used by the Android Splash/Home Screen Connection Status indicator (`Connected`, `Waking Up`, `Missing Keys`, or `Offline`).

## D. FUNCTIONAL REQUIREMENTS
- **Input:** HTTP `GET /health` request from Android app or monitoring ping.
- **Data Stored:** None (stateless config check).
- **Output:** JSON with `status`, `service`, `version`, `timestamp`, and `capabilities` (`configured` vs `missing_key` per external service).
- **Involved Components:** `env.ts` (Zod validation), `server.ts` (Fastify + CORS + Rate Limit + Redacted Logger), `routes/health.ts`.

## E. TECHNICAL IMPLEMENTATION
- **Language:** TypeScript 5.7 (Node.js 20 ESM)
- **Framework:** Fastify 5.1
- **Libraries:** `@fastify/cors`, `@fastify/rate-limit`, `zod`, `dotenv`, `tsx`
- **Security/Logging:** Redacts `authorization` and `x-4bro-token` headers automatically in Fastify logs.

## F. COMPLETE FILE REQUIREMENTS
1. `/home/user/4bro-ai/backend/package.json` — Scripts (`dev`, `build`, `start`, `test`) and dependencies.
2. `/home/user/4bro-ai/backend/tsconfig.json` — Strict TypeScript ESM configuration.
3. `/home/user/4bro-ai/backend/.env.example` — Template environment variables.
4. `/home/user/4bro-ai/backend/src/config/env.ts` — Zod env parser + `getCapabilityStatus()`.
5. `/home/user/4bro-ai/backend/src/routes/health.ts` — `GET /health` route.
6. `/home/user/4bro-ai/backend/src/server.ts` — `buildServer()` factory + entrypoint.
7. `/home/user/4bro-ai/backend/tests/health.test.ts` — Automated integration test.

## G. INTEGRATION
- Android Splash Screen pings `GET /health` immediately on launch to wake Render free tier and display live status on Home Screen.

## H. SECURITY
- No secrets committed to repo; `.env.example` holds placeholders only.
- Rate limiter caps requests to 100/min per IP.
- Logger redacts auth headers.

## I. TESTING
- **Test 1:** `npm run build` (`tsc` compiles with 0 errors). -> **PASS**
- **Test 2:** `GET /health` returns HTTP `200`, `status: "ok"`, and accurately distinguishes `configured` vs `missing_key` capabilities. -> **PASS** (`1/1` tests passed via `tsx --test`).

## J. COMPLETION CRITERIA
- `tsc` compiles cleanly, `GET /health` test passes, and `.env.example` documents all required keys. -> **MET**

## K. ERROR RECOVERY
- *Error:* `tsx --test` fails to find files with `**` glob on Node shell. -> *Fix:* Use `tests/*.test.ts` in `package.json`.
- *Error:* Invalid `PORT` in `.env`. -> *Fix:* Zod throws clear startup validation error pointing to `PORT`.

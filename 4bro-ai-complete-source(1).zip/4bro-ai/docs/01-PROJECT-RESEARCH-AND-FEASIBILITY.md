# 4BRO AI — Complete Technical Research & Feasibility Report

**Date:** 2026-11-21  
**Project:** 4BRO AI (Personal Android AI Assistant)  
**Owner Profile:** Single primary user, Beginner, Mobile-Only Development (No PC)  
**Primary Languages:** Urdu (`ur-PK`), Roman Urdu, English (`en`)

---

## 1. Technical Feasibility Summary

Building **4BRO AI** as a real, secure, installable Android APK without owning a PC is **FEASIBLE**, provided we separate:
1. **Android Client (App on Phone):** Built with cloud CI/CD (GitHub Actions) compiling real signed `.apk` files without needing local Android Studio.
2. **Backend API Server:** Hosted in the cloud (e.g., Render / Railway / Koyeb / Cloudflare) to protect API keys, run AI orchestration, execute web research, and sync encrypted backups.
3. **Device-Native Capabilities:** Microphone speech capture, TTS playback, local encrypted database, Android alarms/notifications, share sheets, intents, and optional floating overlay bubble.

### What IS Feasible vs. What Has Strict Android / Policy Limitations

| Capability | Feasibility | Exact Limitation / Constraint | Honest Engineering Solution |
|---|---|---|---|
| **Voice Assistant (Urdu, Roman Urdu, English)** | **High** | Android's built-in `SpeechRecognizer` handles `ur-PK` and `en` well online, but often struggles with mixed Urdu+English ("Roman Urdu" code-switching) and offline Urdu accuracy. | Hybrid pipeline: Android `SpeechRecognizer` for fast dictation/offline fallback + **Groq Whisper (`whisper-large-v3` / `turbo`)** via backend for accurate Urdu/English code-switching; LLM normalizes Roman Urdu. |
| **Natural Friendly Male Voice (TTS)** | **High** | Built-in Android TTS Urdu voice sounds robotic and varies by phone OEM. | Primary: **Microsoft Azure Neural TTS (`ur-PK-AsadNeural`)** — natural Pakistani male Urdu voice (500,000 chars/month free F0 tier) + English male neural voice, with Android `TextToSpeech` as offline fallback. Note: Roman Urdu text must be converted to Urdu script/phonetic mixed text by the AI Brain before sending to Urdu TTS. |
| **3D Cute Robot Mascot (12 States)** | **High** | Heavy real-time Unity/Unreal 3D engines bloat APK size (50–100+ MB) and drain battery, especially inside a floating overlay. | **2-Tier Visual System:** (A) Main screen uses **Rive / Lottie / Hardware-accelerated 3D-styled vector or lightweight WebGL/Filament asset** with 60fps state machine; (B) Floating bubble uses lightweight **animated Canvas/Lottie vector sprite** matching identical proportions & face so battery stays low. |
| **Floating Robot Bubble (`SYSTEM_ALERT_WINDOW`)** | **Medium-High (Strict Android 13–16 Rules)** | 1. **Android 14+**: Foreground Services MUST declare `foregroundServiceType="specialUse"` (or `microphone` when actively listening) + runtime notification permission (`POST_NOTIFICATIONS`).<br>2. **Android 15+**: Holding `SYSTEM_ALERT_WINDOW` no longer lets an app start a foreground service silently from background — an active `TYPE_APPLICATION_OVERLAY` window MUST already be visible before starting the service, or Android throws `ForegroundServiceStartNotAllowedException`.<br>3. **Cross-platform frameworks** (standard Expo Go / Capacitor) cannot render native `TYPE_APPLICATION_OVERLAY` windows without writing native Kotlin code. | Build the Android app in **Native Kotlin + Jetpack Compose** (or custom native Kotlin service module). Always start the visible overlay from user foreground interaction, declare `specialUse` foreground service type properly, show a clear persistent notification with Stop button, and follow Android 15+ lifecycle rules. |
| **Always-On Wake Word ("Hey 4BRO")** | **Restricted** | Android 12–16 blocks background microphone access without a persistent visible foreground notification (`foregroundServiceType="microphone"`), drains battery, and Play Store restricts third-party always-on hotword listeners. | **Do NOT promise hidden background wake-word.** Implement: (1) Tap-to-talk on Home/Floating bubble, (2) Quick Settings Tile / Home Widget, and (3) Optional foreground "Hands-Free Mode" (active only while user turns it ON with visible microphone indicator & notification). |
| **App Automation** | **Medium (Permission-Scoped)** | Android blocks silent control of third-party apps (WhatsApp, YouTube, Banking apps). AccessibilityService abuse is restricted, and bypassing logins/CAPTCHAs/OTPs is unsafe and prohibited. | Safe Android Intents only: open apps, launch deep links, system Settings pages, Android Share Sheet, Clipboard copy, Alarms/Calendar/Notifications, and authorized OAuth APIs. Never touch PINs/OTPs/passwords. |
| **YouTube & Facebook Publishing / Analytics** | **Conditional** | Creating scripts, hooks, prompts, thumbnails concepts, calendars = 100% feasible immediately. Live channel analytics or auto-posting to Facebook Pages requires official OAuth app verification (YouTube Data API v3 / Meta Graph API) and user approval. | Build full local/AI content studio first; add OAuth-connected YouTube Data API (read-only channel stats) and Facebook Graph API (draft/publish with explicit user confirmation dialog) as optional connected modules. |
| **Internet Research with Live Citations** | **High** | An LLM alone hallucinates URLs and recent trends. | Backend integrates a real web search API (e.g., Tavily / Serper / Brave Search / DuckDuckGo fallback) + page fetcher, returns actual URLs, titles, and retrieval timestamps (`retrieved_at`), and forces LLM to cite only fetched sources. |
| **Mobile-Only Development & APK Generation** | **High** | Cannot run Android Studio or local Gradle comfortably on a phone. | Source code lives on **GitHub**. **GitHub Actions** (`ubuntu-latest` runner with pre-installed Android SDK & Java) automatically compiles, tests, signs, and outputs a downloadable `.apk` artifact whenever code is pushed — accessible from any mobile browser. |

---

## 2. Android Framework Comparison

| Framework | Floating Overlay (`SYSTEM_ALERT_WINDOW`) | APK Size | Performance & Battery | Mobile-Only Cloud Build | Verdict |
|---|---|---|---|---|---|
| **Native Kotlin + Jetpack Compose** | **100% Native Support** (`WindowManager`, `Service`, Android 15 `specialUse`) | Small (~12–25 MB) | Best CPU/RAM/Battery | **GitHub Actions** (Free 2,000 mins/mo public/private; unlimited on public repos) | **RECOMMENDED** |
| **React Native + Expo (EAS Build)** | Requires custom native Kotlin module + `expo prebuild` (breaks Expo Go) | Large (~45–70 MB) | Medium (JS bridge + Hermes overhead) | EAS Free Tier = 15 Android builds/month, 90+ min peak wait queue | Runner-up |
| **Flutter** | Requires Android native Kotlin plugin (`flutter_overlay_window` has Android 15 edge-case bugs) | Medium (~25–45 MB) | Good | Codemagic (500 free mins/mo) or GitHub Actions | Not ideal for complex native overlay |
| **Capacitor / WebView** | No true native floating overlay without full Kotlin service anyway | Medium | Poor for 3D mascot + continuous voice | GitHub Actions | Rejected |

**Decision:** **Native Android (Kotlin + Jetpack Compose + Material 3)** compiled via **GitHub Actions** is the strongest, cleanest, smallest, most battery-efficient, and Android 15/16-compliant choice.

---

## 3. Backend & Database Comparison

| Layer | Recommended Option | Free Tier Allowance | Why Selected |
|---|---|---|---|
| **Backend Runtime** | **Node.js 20 + TypeScript + Fastify (or Express)** | Runs free on **Render** (750 hrs/mo), **Koyeb**, or **Railway** trial; zero-cost local testing in sandbox | Same JS/TS ecosystem, fast JSON/streaming SSE, huge SDK support for Gemini, Groq, Azure, Search APIs, easy to edit on mobile GitHub web editor. |
| **Local Android Database** | **Room (SQLite) + SQLCipher / EncryptedSharedPreferences** | 100% Free, offline-first | Stores Notes, Tasks, Reminders, Finance Ledger, Chat Cache, Preferences locally with instant speed and offline access. |
| **Cloud Backup / Sync DB** | **Supabase (PostgreSQL)** or **Encrypted JSON Backup to Google Drive** | Supabase Free Tier: 500 MB DB, Auth, RLS; Google Drive AppData: Free 15 GB user quota | **Primary:** Local Room DB + optional **Google Drive encrypted backup** (note: `google_drive` is already connected in this workspace!) + optional **Supabase** when multi-device sync is wanted. |

---

## 4. AI Model, STT, TTS & Web Search Comparison

| Service Role | Primary Recommended (Free-First) | Backup / Upgrade Option | Verified Limits & Language Notes |
|---|---|---|---|
| **AI Brain (LLM)** | **Google Gemini API (`gemini-2.5-flash` / `gemini-3-flash` via Google AI Studio)** | **Groq (`llama-3.3-70b-versatile`)** or **OpenAI (`gpt-4o-mini`)** | Gemini free tier offers ~10–15 RPM & ~1,500 RPD on Flash models (Pro is paid-only as of 2026). Excellent Urdu, Roman Urdu, English, and tool-calling support. *Note: Free tier data may be used by Google for product improvement unless paid billing is enabled.* |
| **Speech-to-Text (STT)** | **Hybrid: Android `SpeechRecognizer` + Groq `whisper-large-v3-turbo`** | **OpenAI Whisper API** / **Google Cloud STT** | Groq offers a true no-card free tier for `whisper-large-v3` / `turbo` (~2,000 req/day, ~8 hrs audio/day, 25 MB upload limit; paid turbo is $0.04/hr). Great for Urdu + English mixed speech. |
| **Text-to-Speech (TTS)** | **Microsoft Azure Speech (`ur-PK-AsadNeural` male Pakistani Urdu + `en-US-AndrewNeural` / `GuyNeural`)** | **Android Native `TextToSpeech`** (offline fallback) / **ElevenLabs** (paid natural voice) | Azure Free (F0) tier gives **500,000 neural characters/month free**. `ur-PK-AsadNeural` is a true Pakistani Urdu male voice. |
| **Web Research API** | **Tavily AI Search / Serper.dev (Google SERP) / Brave Search API** | **DuckDuckGo HTML + Page Fetcher** | Tavily gives 1,000 free searches/month; Serper gives 2,500 free queries on signup; Brave Search has a free tier. Never fabricate links. |

---

## 5. Mobile-Only Development & APK Generation Strategy

Since the owner **does not have a PC**, every tool in our workflow must work on an Android phone + cloud:
1. **Code Creation & Editing:** Built directly in this Arena workspace by our AI engineering team, then synced to a **GitHub** repository (owner creates a free GitHub account in Chrome on Android and uses GitHub Mobile app / mobile browser).
2. **Automated Testing & APK Building:** **GitHub Actions** (`.github/workflows/android-apk.yml`) runs Gradle unit tests, lint checks, and builds `4bro-ai-debug.apk` / signed `4bro-ai-release.apk` automatically in the cloud.
3. **Installing on Phone:** Owner opens GitHub Actions run (or GitHub Releases) in Android Chrome -> taps **Download APK** -> taps **Install** (enabling "Install unknown apps" for Chrome once).
4. **Backend Deployment:** Owner connects the GitHub repo to **Render.com** (or Koyeb) via mobile browser -> pastes environment API keys once in Render Dashboard -> gets a permanent `https://fourbro-backend.onrender.com` URL.
5. **Backups:** Project docs, source code, and APK releases stored in GitHub + optional Google Drive backup.

---

## 6. Estimated Cost Categories (Transparent Breakdown)

| Category | Phase 1–MVP Cost (Free Path) | Optional Paid Upgrade Later |
|---|---|---|
| **GitHub + GitHub Actions** | **$0/month** (2,000 free mins/mo private; unlimited public) | $4/mo GitHub Pro (optional) |
| **Backend Hosting (Render)** | **$0/month** (spins down after 15 min idle — 30–50s wake delay) | $7/mo Starter (always-on, zero cold start) |
| **Gemini LLM API** | **$0/month** (Free tier ~1,500 req/day on Flash) | Pay-as-you-go (~$1–$5/mo personal use) |
| **Groq Whisper STT** | **$0/month** (Free tier ~8 hrs audio/day) | $0.04/hr turbo |
| **Azure Neural TTS** | **$0/month** (Free F0: 500k chars/mo) | $15 per 1M chars neural |
| **Web Search (Tavily/Serper)** | **$0/month** (1,000–2,500 free searches) | $5–$20/mo if heavy daily research |
| **Google Play Store (Optional)** | **$0** (Direct APK install on owner's own phone) | $25 one-time (only if publishing publicly) |
| **Total to Launch Personal App** | **$0 / month** | **~$7–$15 / month** (only if wanting zero sleep + private AI data terms) |

---

## 7. Major Technical & Security Risks + Mitigations

1. **Android 15/16 Floating Bubble Crashes (`ForegroundServiceStartNotAllowedException`):**
   - *Mitigation:* Strictly attach the floating service from foreground user interaction only after `Settings.canDrawOverlays(context)` is true AND immediately attach the visible `TYPE_APPLICATION_OVERLAY` view before promoting foreground service; declare `android:foregroundServiceType="specialUse"` in `AndroidManifest.xml`.
2. **Roman Urdu Speech & TTS Mismatch:**
   - *Mitigation:* Speech-to-Text outputs either Urdu script (`ur-PK`) or mixed Latin/Urdu. AI Brain processes Urdu + Roman Urdu + English seamlessly, outputs **both** display text (in user's preferred script: Roman Urdu or Urdu) and a **spoken TTS script** (clean Urdu/English script for `ur-PK-AsadNeural` so pronunciation is natural, not robotic English spelling of Urdu words).
3. **API Key Theft inside APK:**
   - *Mitigation:* Zero third-party API keys (Gemini, Groq, Azure, Search) ever touch the APK. APK talks only to 4BRO Backend over HTTPS using a per-user Device Auth Token + HMAC/JWT + rate limiting.
4. **Render Free Tier Cold Start (30–50 seconds sleep):**
   - *Mitigation:* App shows friendly 4BRO "Waking up..." robot animation on cold start + pings `/health` immediately on Splash Screen so backend wakes up while Splash/Home loads.
5. **Financial Ledger Corruption:**
   - *Mitigation:* Append-only **Transaction Ledger** (`transactions` table) alongside `people_balances` summary; edits create adjustment/reversal entries or preserve `audit_log` so history is never silently lost.
6. **Hallucinated Research or Fake Actions:**
   - *Mitigation:* Strict tool-verification layer: AI cannot say "Done" unless tool returned `status: "success"`; research responses enforce URL + `retrieved_at` date from actual search results.

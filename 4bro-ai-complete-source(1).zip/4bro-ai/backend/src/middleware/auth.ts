import crypto from 'node:crypto';
import { FastifyReply, FastifyRequest } from 'fastify';
import { AppEnv } from '../config/env.js';

function safeCompareTokens(provided: string, expected: string): boolean {
  const providedBuf = Buffer.from(provided, 'utf8');
  const expectedBuf = Buffer.from(expected, 'utf8');
  if (providedBuf.length !== expectedBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(providedBuf, expectedBuf);
}

export function extractDeviceToken(request: FastifyRequest): string | null {
  const customHeader = request.headers['x-4bro-token'];
  if (typeof customHeader === 'string' && customHeader.trim().length > 0) {
    return customHeader.trim();
  }

  const authHeader = request.headers.authorization;
  if (typeof authHeader === 'string' && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice('Bearer '.length).trim();
    return token.length > 0 ? token : null;
  }

  return null;
}

export function createDeviceAuthGuard(env: AppEnv) {
  return async function verifyDeviceToken(
    request: FastifyRequest,
    reply: FastifyReply
  ): Promise<void> {
    const token = extractDeviceToken(request);
    if (!token || !safeCompareTokens(token, env.FOURBRO_DEVICE_TOKEN)) {
      reply.code(401).send({
        error: 'unauthorized',
        message: 'Invalid or missing 4BRO device token.'
      });
    }
  };
}

import 'dotenv/config';
import { z } from 'zod';

const envSchema = z.object({
  PORT: z.coerce.number().int().min(1).max(65535).default(8080),
  HOST: z.string().default('0.0.0.0'),
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  FOURBRO_DEVICE_TOKEN: z.string().min(8).default('dev-local-token-change-in-prod'),
  GEMINI_API_KEY: z.string().optional().default(''),
  GROQ_API_KEY: z.string().optional().default(''),
  AZURE_SPEECH_KEY: z.string().optional().default(''),
  AZURE_SPEECH_REGION: z.string().optional().default('southeastasia'),
  TAVILY_API_KEY: z.string().optional().default(''),
  SERPER_API_KEY: z.string().optional().default('')
});

export type AppEnv = z.infer<typeof envSchema>;

export function loadEnv(overrides?: Partial<Record<string, string>>): AppEnv {
  const merged = { ...process.env, ...overrides };
  return envSchema.parse(merged);
}

export function getCapabilityStatus(env: AppEnv) {
  return {
    aiBrainPrimary: env.GEMINI_API_KEY.length > 0 ? 'configured' : 'missing_key',
    aiBrainFallback: env.GROQ_API_KEY.length > 0 ? 'configured' : 'missing_key',
    sttCloudWhisper: env.GROQ_API_KEY.length > 0 ? 'configured' : 'missing_key',
    ttsAzureNeural: env.AZURE_SPEECH_KEY.length > 0 ? 'configured' : 'missing_key',
    webResearch:
      env.TAVILY_API_KEY.length > 0 || env.SERPER_API_KEY.length > 0
        ? 'configured'
        : 'missing_key'
  };
}

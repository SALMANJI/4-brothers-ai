import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppEnv } from '../config/env.js';
import { createDeviceAuthGuard } from '../middleware/auth.js';
import { SpeechService } from '../services/speechService.js';

const TranscribeBodySchema = z.object({
  audioBase64: z.string().min(4).max(21_000_000),
  mimeType: z.enum(['audio/m4a', 'audio/mp3', 'audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm']),
  languageHint: z.enum(['ur', 'en', 'auto']).optional(),
  promptHint: z.string().max(300).optional()
});

const SynthesizeBodySchema = z.object({
  text: z.string().min(1).max(2000),
  language: z.enum(['ur-PK', 'en-US']).default('ur-PK'),
  rate: z.number().min(0.7).max(1.5).optional(),
  volume: z.number().min(0.1).max(1.0).optional()
});

export async function registerSpeechRoutes(app: FastifyInstance, env: AppEnv) {
  const authGuard = createDeviceAuthGuard(env);
  const speech = new SpeechService(env);

  app.post('/api/v1/speech/transcribe', { preHandler: authGuard }, async (request, reply) => {
    const parsed = TranscribeBodySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid audio transcription request.'
      });
    }

    const result = await speech.transcribe(parsed.data);
    return reply.code(result.status === 'ok' ? 200 : 503).send(result);
  });

  app.post('/api/v1/speech/synthesize', { preHandler: authGuard }, async (request, reply) => {
    const parsed = SynthesizeBodySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid speech synthesis request.'
      });
    }

    const result = await speech.synthesize(parsed.data);
    return reply.code(result.status === 'ok' ? 200 : 503).send(result);
  });
}

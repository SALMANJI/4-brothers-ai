import { FastifyInstance } from 'fastify';
import { AppEnv, getCapabilityStatus } from '../config/env.js';

export async function registerHealthRoutes(app: FastifyInstance, env: AppEnv) {
  app.get('/health', async () => {
    return {
      status: 'ok',
      service: '4bro-ai-backend',
      version: '0.1.0',
      timestamp: new Date().toISOString(),
      capabilities: getCapabilityStatus(env)
    };
  });
}

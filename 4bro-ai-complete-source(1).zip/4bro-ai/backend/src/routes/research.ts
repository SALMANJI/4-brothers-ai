import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppEnv } from '../config/env.js';
import { createDeviceAuthGuard } from '../middleware/auth.js';
import { GeminiFlashProvider, GroqLlamaProvider, LlmProvider } from '../services/aiBrain.js';
import { SearchBackend, WebResearchService } from '../services/webResearchService.js';

const ResearchBodySchema = z.object({
  query: z.string().min(2).max(250),
  depth: z.enum(['quick', 'deep']).default('quick'),
  language: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur')
});

export interface ResearchRouteDeps {
  searchBackends?: SearchBackend[];
  llmProvider?: LlmProvider;
}

export async function registerResearchRoutes(
  app: FastifyInstance,
  env: AppEnv,
  deps: ResearchRouteDeps = {}
) {
  const authGuard = createDeviceAuthGuard(env);
  const llm =
    deps.llmProvider ??
    (env.GEMINI_API_KEY
      ? new GeminiFlashProvider(env.GEMINI_API_KEY)
      : env.GROQ_API_KEY
        ? new GroqLlamaProvider(env.GROQ_API_KEY)
        : undefined);

  const researchService = new WebResearchService(env, deps.searchBackends, llm);

  app.post('/api/v1/research/search', { preHandler: authGuard }, async (request, reply) => {
    const parsed = ResearchBodySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid research query payload.'
      });
    }

    const report = await researchService.research(
      parsed.data.query,
      parsed.data.depth,
      parsed.data.language
    );
    return reply.code(report.status === 'ok' ? 200 : 503).send(report);
  });
}

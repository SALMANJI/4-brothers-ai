import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { AppEnv } from '../config/env.js';
import { createDeviceAuthGuard } from '../middleware/auth.js';
import { AiBrainService, LlmProvider } from '../services/aiBrain.js';
import { InMemorySessionStore } from '../services/sessionStore.js';

const ChatRequestSchema = z.object({
  sessionId: z.string().min(3).max(100),
  message: z.string().min(1).max(4000),
  preferredLanguage: z.enum(['ur', 'roman_ur', 'en']).optional(),
  ownerName: z.string().max(60).optional()
});

const ToolResultSchema = z.object({
  sessionId: z.string().min(3).max(100),
  tool: z.string().min(1).max(80),
  status: z.enum(['success', 'error', 'cancelled']),
  summary: z.string().min(1).max(1000)
});

export interface ChatRouteDeps {
  sessionStore?: InMemorySessionStore;
  llmProviders?: LlmProvider[];
}

export async function registerChatRoutes(
  app: FastifyInstance,
  env: AppEnv,
  deps: ChatRouteDeps = {}
) {
  const authGuard = createDeviceAuthGuard(env);
  const sessions = deps.sessionStore ?? new InMemorySessionStore();
  const aiBrain = new AiBrainService(env, deps.llmProviders);

  app.post('/api/v1/chat', { preHandler: authGuard }, async (request, reply) => {
    const parsed = ChatRequestSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid chat request payload.',
        details: parsed.error.issues.map((i) => ({ path: i.path, message: i.message }))
      });
    }

    const { sessionId, message, preferredLanguage, ownerName } = parsed.data;
    const session = sessions.getOrCreate(sessionId, {
      ...(preferredLanguage ? { preferredLanguage } : {}),
      ...(ownerName ? { ownerName } : {})
    });

    const result = await aiBrain.processTurn(session, message);

    sessions.appendTurn(sessionId, {
      role: 'user',
      content: message,
      language: result.detectedLanguage
    });

    if (result.status === 'ok') {
      sessions.appendTurn(sessionId, {
        role: 'assistant',
        content: result.displayText,
        language: result.detectedLanguage
      });
    }

    const code = result.status === 'ok' ? 200 : 503;
    return reply.code(code).send({
      sessionId,
      ...result
    });
  });

  app.post('/api/v1/chat/tool-result', { preHandler: authGuard }, async (request, reply) => {
    const parsed = ToolResultSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid tool result payload.'
      });
    }

    const { sessionId, tool, status, summary } = parsed.data;
    sessions.appendTurn(sessionId, {
      role: 'tool',
      content: `[${tool}:${status}] ${summary}`
    });

    return reply.code(200).send({
      recorded: true,
      sessionId,
      tool,
      status
    });
  });

  app.get('/api/v1/sessions/:sessionId', { preHandler: authGuard }, async (request, reply) => {
    const params = z.object({ sessionId: z.string().min(3).max(100) }).safeParse(request.params);
    if (!params.success) {
      return reply.code(400).send({ error: 'invalid_session_id' });
    }
    const session = sessions.getSession(params.data.sessionId);
    if (!session) {
      return reply.code(404).send({ error: 'session_not_found' });
    }
    return reply.code(200).send(session);
  });

  app.delete('/api/v1/sessions/:sessionId', { preHandler: authGuard }, async (request, reply) => {
    const params = z.object({ sessionId: z.string().min(3).max(100) }).safeParse(request.params);
    if (!params.success) {
      return reply.code(400).send({ error: 'invalid_session_id' });
    }
    const deleted = sessions.deleteSession(params.data.sessionId);
    return reply.code(200).send({ deleted, sessionId: params.data.sessionId });
  });
}

import { FastifyInstance } from 'fastify';
import { AppEnv } from '../config/env.js';
import { createDeviceAuthGuard } from '../middleware/auth.js';
import { LlmProvider } from '../services/aiBrain.js';
import {
  ContentStudioService,
  FacebookStudioInputSchema,
  YouTubeStudioInputSchema
} from '../services/contentStudioService.js';
import { SearchBackend, WebResearchService } from '../services/webResearchService.js';

export interface ContentRouteDeps {
  llmProviders?: LlmProvider[];
  searchBackends?: SearchBackend[];
}

export async function registerContentRoutes(
  app: FastifyInstance,
  env: AppEnv,
  deps: ContentRouteDeps = {}
) {
  const authGuard = createDeviceAuthGuard(env);
  const researchService = new WebResearchService(env, deps.searchBackends, deps.llmProviders?.[0]);
  const studio = new ContentStudioService(env, researchService, deps.llmProviders);

  app.post('/api/v1/content/youtube', { preHandler: authGuard }, async (request, reply) => {
    const parsed = YouTubeStudioInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid YouTube Studio request payload.'
      });
    }
    const result = await studio.generateYouTubePackage(parsed.data);
    return reply.code(result.status === 'ok' ? 200 : 503).send(result);
  });

  app.post('/api/v1/content/facebook', { preHandler: authGuard }, async (request, reply) => {
    const parsed = FacebookStudioInputSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.code(400).send({
        error: 'validation_error',
        message: 'Invalid Facebook Manager request payload.'
      });
    }
    const result = await studio.generateFacebookPackage(parsed.data);
    return reply.code(result.status === 'ok' ? 200 : 503).send(result);
  });
}

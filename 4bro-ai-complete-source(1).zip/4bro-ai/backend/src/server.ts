import Fastify, { FastifyInstance } from 'fastify';
import cors from '@fastify/cors';
import rateLimit from '@fastify/rate-limit';
import { AppEnv, loadEnv } from './config/env.js';
import { registerHealthRoutes } from './routes/health.js';
import { ChatRouteDeps, registerChatRoutes } from './routes/chat.js';
import { registerSpeechRoutes } from './routes/speech.js';
import { registerResearchRoutes, ResearchRouteDeps } from './routes/research.js';
import { ContentRouteDeps, registerContentRoutes } from './routes/content.js';

export interface BuildServerOptions {
  env?: AppEnv;
  chatDeps?: ChatRouteDeps;
  researchDeps?: ResearchRouteDeps;
  contentDeps?: ContentRouteDeps;
}

export async function buildServer(options: BuildServerOptions = {}): Promise<FastifyInstance> {
  const env = options.env ?? loadEnv();

  const app = Fastify({
    bodyLimit: 24 * 1024 * 1024, // Supports base64 audio uploads up to 15 MB binary
    logger: env.NODE_ENV !== 'test'
      ? {
          redact: ['req.headers.authorization', 'req.headers["x-4bro-token"]']
        }
      : false
  });

  await app.register(cors, {
    origin: true
  });

  await app.register(rateLimit, {
    max: 100,
    timeWindow: '1 minute'
  });

  app.setErrorHandler((error, _request, reply) => {
    const errObj = error as { statusCode?: unknown; message?: unknown };
    const statusCode = typeof errObj?.statusCode === 'number' ? errObj.statusCode : 500;
    const message = typeof errObj?.message === 'string' ? errObj.message : 'Bad request.';
    reply.code(statusCode).send({
      error: statusCode >= 500 ? 'internal_error' : 'request_error',
      message: statusCode >= 500 ? 'Server encountered an unexpected error.' : message
    });
  });

  await registerHealthRoutes(app, env);
  await registerChatRoutes(app, env, options.chatDeps);
  await registerSpeechRoutes(app, env);
  await registerResearchRoutes(app, env, options.researchDeps);
  await registerContentRoutes(app, env, options.contentDeps);

  return app;
}

const isMainModule =
  process.argv[1] !== undefined &&
  (process.argv[1].endsWith('server.ts') || process.argv[1].endsWith('server.js'));

if (isMainModule) {
  const env = loadEnv();
  const app = await buildServer({ env });
  try {
    await app.listen({ port: env.PORT, host: env.HOST });
    console.log(`4BRO AI Backend listening on http://${env.HOST}:${env.PORT}`);
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
}

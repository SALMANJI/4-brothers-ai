import { AppEnv } from '../config/env.js';

export interface TranscribeRequest {
  audioBase64: string;
  mimeType: 'audio/m4a' | 'audio/mp3' | 'audio/mpeg' | 'audio/wav' | 'audio/ogg' | 'audio/webm';
  languageHint?: 'ur' | 'en' | 'auto';
  promptHint?: string;
}

export interface TranscribeResult {
  status: 'ok' | 'stt_unavailable';
  provider: 'groq-whisper' | 'none';
  text: string;
  language: string;
  message?: string;
}

export interface SynthesizeRequest {
  text: string;
  language: 'ur-PK' | 'en-US';
  rate?: number; // 0.7 to 1.5
  volume?: number; // 0.1 to 1.0
}

export interface SynthesizeResult {
  status: 'ok' | 'tts_unavailable';
  provider: 'azure-neural' | 'none';
  voiceName: string;
  audioBase64?: string;
  contentType?: 'audio/mpeg';
  fallbackHint?: string;
}

export function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function buildAzureSsml(req: SynthesizeRequest): { ssml: string; voiceName: string } {
  const voiceName = req.language === 'ur-PK' ? 'ur-PK-AsadNeural' : 'en-US-AndrewNeural';
  const clampedRate = Math.min(1.5, Math.max(0.7, req.rate ?? 1.0));
  const ratePct = `${Math.round((clampedRate - 1) * 100)}%`;
  const signedRate = ratePct.startsWith('-') ? ratePct : `+${ratePct}`;
  const clampedVol = Math.min(1.0, Math.max(0.1, req.volume ?? 1.0));
  const volPct = `${Math.round(clampedVol * 100)}%`;

  const ssml = `<speak version="1.0" xml:lang="${req.language}">
  <voice xml:lang="${req.language}" name="${voiceName}">
    <prosody rate="${signedRate}" volume="${volPct}">${escapeXml(req.text)}</prosody>
  </voice>
</speak>`;

  return { ssml, voiceName };
}

export class SpeechService {
  constructor(private readonly env: AppEnv) {}

  async transcribe(req: TranscribeRequest): Promise<TranscribeResult> {
    if (!this.env.GROQ_API_KEY) {
      return {
        status: 'stt_unavailable',
        provider: 'none',
        text: '',
        language: req.languageHint ?? 'auto',
        message: 'GROQ_API_KEY backend par set nahi hai. Phone ka built-in Android SpeechRecognizer istemal karein.'
      };
    }

    const audioBuffer = Buffer.from(req.audioBase64, 'base64');
    if (audioBuffer.byteLength === 0 || audioBuffer.byteLength > 15 * 1024 * 1024) {
      throw new Error('Invalid audio size (must be 1 byte to 15 MB).');
    }

    const extMap: Record<TranscribeRequest['mimeType'], string> = {
      'audio/m4a': 'm4a',
      'audio/mp3': 'mp3',
      'audio/mpeg': 'mp3',
      'audio/wav': 'wav',
      'audio/ogg': 'ogg',
      'audio/webm': 'webm'
    };

    const formData = new FormData();
    const blob = new Blob([audioBuffer], { type: req.mimeType });
    formData.append('file', blob, `voice.${extMap[req.mimeType]}`);
    formData.append('model', 'whisper-large-v3-turbo');
    formData.append('response_format', 'verbose_json');
    if (req.languageHint && req.languageHint !== 'auto') {
      formData.append('language', req.languageHint);
    }
    if (req.promptHint) {
      formData.append('prompt', req.promptHint);
    }

    const res = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.env.GROQ_API_KEY}`
      },
      body: formData
    });

    if (!res.ok) {
      throw new Error(`Groq Whisper HTTP ${res.status}`);
    }

    const data = (await res.json()) as { text?: string; language?: string };
    return {
      status: 'ok',
      provider: 'groq-whisper',
      text: (data.text ?? '').trim(),
      language: data.language ?? req.languageHint ?? 'unknown'
    };
  }

  async synthesize(req: SynthesizeRequest): Promise<SynthesizeResult> {
    const { ssml, voiceName } = buildAzureSsml(req);

    if (!this.env.AZURE_SPEECH_KEY) {
      return {
        status: 'tts_unavailable',
        provider: 'none',
        voiceName,
        fallbackHint: 'AZURE_SPEECH_KEY missing on backend; use on-device Android TextToSpeech fallback.'
      };
    }

    const endpoint = `https://${this.env.AZURE_SPEECH_REGION}.tts.speech.microsoft.com/cognitiveservices/v1`;
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Ocp-Apim-Subscription-Key': this.env.AZURE_SPEECH_KEY,
        'Content-Type': 'application/ssml+xml',
        'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3',
        'User-Agent': '4BRO-AI-Backend'
      },
      body: ssml
    });

    if (!res.ok) {
      throw new Error(`Azure TTS HTTP ${res.status}`);
    }

    const arrayBuf = await res.arrayBuffer();
    const audioBase64 = Buffer.from(arrayBuf).toString('base64');

    return {
      status: 'ok',
      provider: 'azure-neural',
      voiceName,
      audioBase64,
      contentType: 'audio/mpeg'
    };
  }
}

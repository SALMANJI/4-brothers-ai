import { z } from 'zod';

export const NoteCreateSchema = z.object({
  tool: z.literal('note.create'),
  args: z.object({
    title: z.string().min(1).max(160),
    content: z.string().min(1).max(10000),
    category: z.string().min(1).max(60).default('General'),
    source: z.enum(['text', 'voice']).default('text')
  })
});

export const NoteSearchSchema = z.object({
  tool: z.literal('note.search'),
  args: z.object({
    query: z.string().min(1).max(120),
    category: z.string().optional()
  })
});

export const ReminderCreateSchema = z.object({
  tool: z.literal('reminder.create'),
  args: z.object({
    title: z.string().min(1).max(200),
    triggerAtIso: z.string().min(10),
    notes: z.string().max(500).optional()
  })
});

export const ReminderListSchema = z.object({
  tool: z.literal('reminder.list'),
  args: z.object({
    upcomingOnly: z.boolean().default(true)
  })
});

export const TaskCreateSchema = z.object({
  tool: z.literal('task.create'),
  args: z.object({
    title: z.string().min(1).max(200),
    priority: z.enum(['LOW', 'MEDIUM', 'HIGH']).default('MEDIUM'),
    dueAtIso: z.string().optional()
  })
});

export const TaskCompleteSchema = z.object({
  tool: z.literal('task.complete'),
  args: z.object({
    taskTitleOrId: z.string().min(1).max(200)
  })
});

export const FinanceRecordSchema = z.object({
  tool: z.literal('finance.record'),
  args: z.object({
    type: z.enum([
      'INCOME',
      'EXPENSE',
      'RECEIVABLE', // Money owed TO the owner ("lene wale paise")
      'PAYABLE',    // Money owner owes ("dene wale paise")
      'PAYMENT_RECEIVED',
      'PAYMENT_MADE'
    ]),
    amount: z.number().positive().max(1_000_000_000),
    currency: z.string().min(3).max(6).default('PKR'),
    counterparty: z.string().max(120).optional(),
    category: z.string().max(80).default('General'),
    note: z.string().max(300).optional()
  })
});

export const FinanceSummarySchema = z.object({
  tool: z.literal('finance.summary'),
  args: z.object({
    counterparty: z.string().max(120).optional(),
    period: z.enum(['today', 'week', 'month', 'all']).default('all')
  })
});

export const ResearchSearchSchema = z.object({
  tool: z.literal('research.search'),
  args: z.object({
    query: z.string().min(2).max(250),
    depth: z.enum(['quick', 'deep']).default('quick')
  })
});

export const YouTubeGenerateSchema = z.object({
  tool: z.literal('youtube.generate_package'),
  args: z.object({
    topic: z.string().min(2).max(250),
    format: z.enum(['short', 'long']).default('long'),
    durationMinutes: z.number().min(0.25).max(60).default(5),
    aspectRatio: z.enum(['16:9', '9:16']).default('16:9'),
    language: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur'),
    style: z.string().max(120).default('engaging storytelling')
  })
});

export const FacebookGenerateSchema = z.object({
  tool: z.literal('facebook.generate_package'),
  args: z.object({
    topic: z.string().min(2).max(250),
    goal: z.enum(['engagement', 'education', 'promotion', 'calendar']).default('engagement'),
    language: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur')
  })
});

export const AndroidIntentSchema = z.object({
  tool: z.literal('android.intent'),
  args: z.object({
    action: z.enum(['OPEN_APP', 'OPEN_URL', 'OPEN_SETTINGS', 'COPY_CLIPBOARD', 'SHARE_TEXT']),
    target: z.string().min(1).max(1000),
    requiresConfirmation: z.boolean().default(false)
  })
});

export const ToolCallSchema = z.discriminatedUnion('tool', [
  NoteCreateSchema,
  NoteSearchSchema,
  ReminderCreateSchema,
  ReminderListSchema,
  TaskCreateSchema,
  TaskCompleteSchema,
  FinanceRecordSchema,
  FinanceSummarySchema,
  ResearchSearchSchema,
  YouTubeGenerateSchema,
  FacebookGenerateSchema,
  AndroidIntentSchema
]);

export type ValidatedToolCall = z.infer<typeof ToolCallSchema>;

export const SERVER_TOOLS = new Set<ValidatedToolCall['tool']>([
  'research.search',
  'youtube.generate_package',
  'facebook.generate_package'
]);

export function classifyToolExecutionTarget(tool: ValidatedToolCall['tool']): 'backend_server' | 'android_client' {
  return SERVER_TOOLS.has(tool) ? 'backend_server' : 'android_client';
}

export function isSensitiveToolCall(call: ValidatedToolCall): boolean {
  if (call.tool === 'android.intent') {
    return (
      call.args.requiresConfirmation ||
      call.args.action === 'SHARE_TEXT' ||
      call.args.action === 'OPEN_URL'
    );
  }
  return false;
}

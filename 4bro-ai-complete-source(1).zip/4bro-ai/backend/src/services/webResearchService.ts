import { AppEnv } from '../config/env.js';
import { LlmProvider } from './aiBrain.js';

export interface ResearchSource {
  id: number;
  title: string;
  url: string;
  snippet: string;
  publishedDate: string | null;
}

export interface ResearchReport {
  status: 'ok' | 'search_unavailable';
  provider: 'tavily' | 'serper' | 'none';
  query: string;
  retrievedAt: string;
  sources: ResearchSource[];
  verifiedFacts: string[];
  opinionsAndClaims: string[];
  uncertainties: string[];
  summary: string;
  exportMarkdown: string;
}

export interface SearchBackend {
  name: 'tavily' | 'serper';
  search(query: string, depth: 'quick' | 'deep'): Promise<ResearchSource[]>;
}

export class TavilySearchBackend implements SearchBackend {
  name = 'tavily' as const;
  constructor(private readonly apiKey: string) {}

  async search(query: string, depth: 'quick' | 'deep'): Promise<ResearchSource[]> {
    const res = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: this.apiKey,
        query,
        search_depth: depth === 'deep' ? 'advanced' : 'basic',
        max_results: depth === 'deep' ? 8 : 5,
        include_raw_content: false
      })
    });
    if (!res.ok) {
      throw new Error(`Tavily HTTP ${res.status}`);
    }
    const data = (await res.json()) as {
      results?: Array<{
        title?: string;
        url?: string;
        content?: string;
        published_date?: string;
      }>;
    };
    return (data.results ?? [])
      .filter((r) => r.url && r.title)
      .map((r, idx) => ({
        id: idx + 1,
        title: r.title ?? 'Untitled',
        url: r.url ?? '',
        snippet: r.content ?? '',
        publishedDate: r.published_date ?? null
      }));
  }
}

export class SerperSearchBackend implements SearchBackend {
  name = 'serper' as const;
  constructor(private readonly apiKey: string) {}

  async search(query: string, depth: 'quick' | 'deep'): Promise<ResearchSource[]> {
    const res = await fetch('https://google.serper.dev/search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': this.apiKey
      },
      body: JSON.stringify({
        q: query,
        num: depth === 'deep' ? 8 : 5
      })
    });
    if (!res.ok) {
      throw new Error(`Serper HTTP ${res.status}`);
    }
    const data = (await res.json()) as {
      organic?: Array<{
        title?: string;
        link?: string;
        snippet?: string;
        date?: string;
      }>;
    };
    return (data.organic ?? [])
      .filter((r) => r.link && r.title)
      .map((r, idx) => ({
        id: idx + 1,
        title: r.title ?? 'Untitled',
        url: r.link ?? '',
        snippet: r.snippet ?? '',
        publishedDate: r.date ?? null
      }));
  }
}

export function formatResearchMarkdown(report: Omit<ResearchReport, 'exportMarkdown'>): string {
  const lines: string[] = [
    `# 4BRO AI Research Report: ${report.query}`,
    `- **Retrieved At:** ${report.retrievedAt}`,
    `- **Search Provider:** ${report.provider}`,
    '',
    '## Summary',
    report.summary,
    '',
    '## Verified Facts',
    ...(report.verifiedFacts.length > 0
      ? report.verifiedFacts.map((f) => `- ${f}`)
      : ['- No independently corroborated facts extracted.']),
    '',
    '## Opinions / Claims',
    ...(report.opinionsAndClaims.length > 0
      ? report.opinionsAndClaims.map((o) => `- ${o}`)
      : ['- None noted.']),
    '',
    '## Uncertainties / Missing Dates',
    ...(report.uncertainties.length > 0
      ? report.uncertainties.map((u) => `- ${u}`)
      : ['- None flagged.']),
    '',
    '## Sources'
  ];

  for (const s of report.sources) {
    lines.push(`[${s.id}] **${s.title}** (${s.publishedDate ?? 'Date unavailable'}) — ${s.url}`);
  }
  return lines.join('\n');
}

export class WebResearchService {
  private readonly backends: SearchBackend[];

  constructor(
    env: AppEnv,
    customBackends?: SearchBackend[],
    private readonly llmProvider?: LlmProvider
  ) {
    if (customBackends) {
      this.backends = customBackends;
    } else {
      const list: SearchBackend[] = [];
      if (env.TAVILY_API_KEY) list.push(new TavilySearchBackend(env.TAVILY_API_KEY));
      if (env.SERPER_API_KEY) list.push(new SerperSearchBackend(env.SERPER_API_KEY));
      this.backends = list;
    }
  }

  async research(
    query: string,
    depth: 'quick' | 'deep' = 'quick',
    language: 'ur' | 'roman_ur' | 'en' = 'roman_ur'
  ): Promise<ResearchReport> {
    const retrievedAt = new Date().toISOString();

    if (this.backends.length === 0) {
      const base = {
        status: 'search_unavailable' as const,
        provider: 'none' as const,
        query,
        retrievedAt,
        sources: [],
        verifiedFacts: [],
        opinionsAndClaims: [],
        uncertainties: [
          'Web search API key (TAVILY_API_KEY ya SERPER_API_KEY) configure nahi hai, isliye live internet search nahi ho saki.'
        ],
        summary:
          'Main internet search ke bina andaze se trends ya links nahi bana sakta. Live research ke liye backend par Tavily ya Serper API key set karein.'
      };
      return { ...base, exportMarkdown: formatResearchMarkdown(base) };
    }

    let sources: ResearchSource[] = [];
    let usedProvider: 'tavily' | 'serper' | 'none' = 'none';

    for (const backend of this.backends) {
      try {
        sources = await backend.search(query, depth);
        usedProvider = backend.name;
        break;
      } catch {
        // try next backend
      }
    }

    if (usedProvider === 'none' || sources.length === 0) {
      const base = {
        status: 'search_unavailable' as const,
        provider: usedProvider,
        query,
        retrievedAt,
        sources: [],
        verifiedFacts: [],
        opinionsAndClaims: [],
        uncertainties: ['Live search se koi verified result wapas nahi aaya.'],
        summary: 'Search API se is waqt results nahi mile. Query change karke dobara check karein.'
      };
      return { ...base, exportMarkdown: formatResearchMarkdown(base) };
    }

    const missingDates = sources.filter((s) => !s.publishedDate).length;
    const defaultUncertainties: string[] = [];
    if (missingDates > 0) {
      defaultUncertainties.push(
        `${missingDates} source(s) par exact publication date metadata maujood nahi tha.`
      );
    }

    if (this.llmProvider) {
      try {
        const prompt = `Analyze ONLY these real retrieved search results (retrievedAt: ${retrievedAt}) for query "${query}".
Language for summary: ${language}.
Separate verified facts (with [id] citations), opinions/claims (with [id] citations), and uncertainties. NEVER invent URLs or facts outside the snippets.
Return strict JSON:
{
  "summary": "...",
  "verifiedFacts": ["... [1]"],
  "opinionsAndClaims": ["... [2]"],
  "uncertainties": ["..."]
}`;
        const raw = await this.llmProvider.completeJson({
          systemPrompt: prompt,
          messages: [{ role: 'user', content: JSON.stringify(sources) }]
        });
        const parsed = JSON.parse(raw) as {
          summary?: string;
          verifiedFacts?: string[];
          opinionsAndClaims?: string[];
          uncertainties?: string[];
        };
        const base = {
          status: 'ok' as const,
          provider: usedProvider,
          query,
          retrievedAt,
          sources,
          verifiedFacts: parsed.verifiedFacts ?? [],
          opinionsAndClaims: parsed.opinionsAndClaims ?? [],
          uncertainties: [...defaultUncertainties, ...(parsed.uncertainties ?? [])],
          summary: parsed.summary ?? `Retrieved ${sources.length} real sources.`
        };
        return { ...base, exportMarkdown: formatResearchMarkdown(base) };
      } catch {
        // Fallback to deterministic structured report below
      }
    }

    const base = {
      status: 'ok' as const,
      provider: usedProvider,
      query,
      retrievedAt,
      sources,
      verifiedFacts: sources.map((s) => `${s.snippet.slice(0, 180)} [${s.id}]`),
      opinionsAndClaims: [],
      uncertainties: defaultUncertainties,
      summary: `${sources.length} real web sources retrieved at ${retrievedAt}.`
    };
    return { ...base, exportMarkdown: formatResearchMarkdown(base) };
  }
}

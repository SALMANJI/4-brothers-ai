import { z } from 'zod';
import { AppEnv } from '../config/env.js';
import { ConversationSession } from './sessionStore.js';
import {
  classifyToolExecutionTarget,
  isSensitiveToolCall,
  ToolCallSchema,
  ValidatedToolCall
} from './toolSchemas.js';

export type RobotState =
  | 'Idle'
  | 'Listening'
  | 'Thinking'
  | 'Processing'
  | 'Speaking'
  | 'Working'
  | 'Waiting'
  | 'Success'
  | 'Warning'
  | 'Error'
  | 'Sleeping'
  | 'WakingUp';

export interface BrainResponse {
  status: 'ok' | 'ai_unavailable';
  provider: 'gemini' | 'groq' | 'none';
  displayText: string;
  ttsSpeechText: string;
  detectedLanguage: 'ur' | 'roman_ur' | 'en';
  robotState: RobotState;
  requiresConfirmation: boolean;
  confirmationPrompt?: string;
  deviceActions: Array<{
    tool: ValidatedToolCall['tool'];
    args: ValidatedToolCall['args'];
    requiresConfirmation: boolean;
  }>;
  serverToolRequests: Array<{
    tool: ValidatedToolCall['tool'];
    args: ValidatedToolCall['args'];
  }>;
  droppedToolCount: number;
}

const RawLlmOutputSchema = z.object({
  displayText: z.string().min(1),
  ttsSpeechText: z.string().min(1),
  detectedLanguage: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur'),
  robotState: z
    .enum(['Speaking', 'Working', 'Waiting', 'Success', 'Warning', 'Error'])
    .default('Speaking'),
  requiresConfirmation: z.boolean().default(false),
  confirmationPrompt: z.string().optional(),
  toolCalls: z.array(z.unknown()).default([])
});

export interface LlmCompletionInput {
  systemPrompt: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
}

export interface LlmProvider {
  name: 'gemini' | 'groq';
  completeJson(input: LlmCompletionInput): Promise<string>;
}

export function buildSystemPrompt(session: ConversationSession, currentDateIso: string): string {
  return `You are 4BRO AI, a loyal, friendly, intelligent, respectful, slightly humorous personal Android AI assistant for ONE primary user.
Current date/time (ISO): ${currentDateIso}
User preferred language: ${session.preferences.preferredLanguage}

LANGUAGES YOU MASTER:
- Urdu script (اردو)
- Roman Urdu (e.g. "Waqas se lene wale 5000 note karo", "kal subah yaad dilana")
- English

HONESTY & SAFETY RULES (CRITICAL):
1. NEVER claim an action (like saving a note, setting a reminder, recording money, or publishing a post) is ALREADY completed if it runs on the Android phone. Instead say you are sending/preparing that action for 4BRO on the phone to save/verify (e.g. "Main note save kar raha hoon..." / "Note request bhej di hai...").
2. Distinguish clearly between:
   - Tasks you can do directly
   - Tasks needing external connected services / web search
   - Tasks requiring user confirmation (set requiresConfirmation=true)
   - Tasks you cannot do (e.g. reading WhatsApp chats secretly, bypassing OTP/CAPTCHA/login, touching banking PINs)
3. NEVER fabricate URLs, trending facts, or dates. If web research is needed, emit a "research.search" tool call.
4. NEVER ask for banking PINs, passwords, or OTPs.

OUTPUT FORMAT:
Return ONLY valid JSON matching this structure:
{
  "displayText": "Clear response for screen in user's language (Roman Urdu, Urdu, or English)",
  "ttsSpeechText": "Natural spoken conversational text with NO markdown, NO URLs, NO asterisks. If user speaks Roman Urdu, write natural Urdu script or easy clean words so Pakistani male TTS pronounces it smoothly.",
  "detectedLanguage": "roman_ur" | "ur" | "en",
  "robotState": "Speaking" | "Working" | "Waiting" | "Success" | "Warning" | "Error",
  "requiresConfirmation": false,
  "confirmationPrompt": "optional short question if confirmation is needed",
  "toolCalls": [
    { "tool": "<tool_name>", "args": { ... } }
  ]
}

AVAILABLE TOOLS:
- note.create: { title, content, category, source }
- note.search: { query, category? }
- reminder.create: { title, triggerAtIso, notes? }
- reminder.list: { upcomingOnly }
- task.create: { title, priority: "LOW"|"MEDIUM"|"HIGH", dueAtIso? }
- task.complete: { taskTitleOrId }
- finance.record: { type: "INCOME"|"EXPENSE"|"RECEIVABLE"|"PAYABLE"|"PAYMENT_RECEIVED"|"PAYMENT_MADE", amount, currency, counterparty?, category?, note? }
- finance.summary: { counterparty?, period: "today"|"week"|"month"|"all" }
- research.search: { query, depth: "quick"|"deep" }
- youtube.generate_package: { topic, format: "short"|"long", durationMinutes, aspectRatio: "16:9"|"9:16", language: "ur"|"roman_ur"|"en", style }
- facebook.generate_package: { topic, goal: "engagement"|"education"|"promotion"|"calendar", language: "ur"|"roman_ur"|"en" }
- android.intent: { action: "OPEN_APP"|"OPEN_URL"|"OPEN_SETTINGS"|"COPY_CLIPBOARD"|"SHARE_TEXT", target, requiresConfirmation }`;
}

export class GeminiFlashProvider implements LlmProvider {
  name = 'gemini' as const;
  constructor(private readonly apiKey: string, private readonly model = 'gemini-2.5-flash') {}

  async completeJson(input: LlmCompletionInput): Promise<string> {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent?key=${encodeURIComponent(this.apiKey)}`;
    const contents = input.messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }));

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: input.systemPrompt }] },
        contents,
        generationConfig: {
          temperature: 0.4,
          responseMimeType: 'application/json'
        }
      })
    });

    if (!res.ok) {
      throw new Error(`Gemini API HTTP ${res.status}`);
    }

    const data = (await res.json()) as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) {
      throw new Error('Gemini returned empty completion');
    }
    return text;
  }
}

export class GroqLlamaProvider implements LlmProvider {
  name = 'groq' as const;
  constructor(
    private readonly apiKey: string,
    private readonly model = 'llama-3.3-70b-versatile'
  ) {}

  async completeJson(input: LlmCompletionInput): Promise<string> {
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.model,
        temperature: 0.4,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: input.systemPrompt },
          ...input.messages
        ]
      })
    });

    if (!res.ok) {
      throw new Error(`Groq API HTTP ${res.status}`);
    }

    const data = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const text = data.choices?.[0]?.message?.content;
    if (!text) {
      throw new Error('Groq returned empty completion');
    }
    return text;
  }
}

export function stripMarkdownForTts(text: string): string {
  return text
    .replace(/https?:\/\/\S+/g, '')
    .replace(/[*_`#>~]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function parseBrainJson(
  rawText: string,
  provider: 'gemini' | 'groq'
): BrainResponse {
  const cleaned = rawText
    .trim()
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '');

  const parsedJson = JSON.parse(cleaned);
  const validated = RawLlmOutputSchema.parse(parsedJson);

  const deviceActions: BrainResponse['deviceActions'] = [];
  const serverToolRequests: BrainResponse['serverToolRequests'] = [];
  let droppedToolCount = 0;
  let requiresConfirmation = validated.requiresConfirmation;

  for (const candidate of validated.toolCalls) {
    const toolRes = ToolCallSchema.safeParse(candidate);
    if (!toolRes.success) {
      droppedToolCount += 1;
      continue;
    }
    const call = toolRes.data;
    const sensitive = isSensitiveToolCall(call);
    if (sensitive) {
      requiresConfirmation = true;
    }

    if (classifyToolExecutionTarget(call.tool) === 'backend_server') {
      serverToolRequests.push({ tool: call.tool, args: call.args });
    } else {
      deviceActions.push({
        tool: call.tool,
        args: call.args,
        requiresConfirmation: sensitive
      });
    }
  }

  return {
    status: 'ok',
    provider,
    displayText: validated.displayText,
    ttsSpeechText: stripMarkdownForTts(validated.ttsSpeechText),
    detectedLanguage: validated.detectedLanguage,
    robotState: requiresConfirmation ? 'Waiting' : validated.robotState,
    requiresConfirmation,
    confirmationPrompt: validated.confirmationPrompt,
    deviceActions,
    serverToolRequests,
    droppedToolCount
  };
}

export class AiBrainService {
  private readonly providers: LlmProvider[];

  constructor(env: AppEnv, customProviders?: LlmProvider[]) {
    if (customProviders) {
      this.providers = customProviders;
    } else {
      const list: LlmProvider[] = [];
      if (env.GEMINI_API_KEY) {
        list.push(new GeminiFlashProvider(env.GEMINI_API_KEY));
      }
      if (env.GROQ_API_KEY) {
        list.push(new GroqLlamaProvider(env.GROQ_API_KEY));
      }
      this.providers = list;
    }
  }

  async processTurn(
    session: ConversationSession,
    userMessage: string,
    currentDateIso = new Date().toISOString()
  ): Promise<BrainResponse> {
    if (this.providers.length === 0) {
      return {
        status: 'ai_unavailable',
        provider: 'none',
        displayText:
          '4BRO AI Backend chal raha hai, lekin abhi AI Brain ki API key (Gemini ya Groq) server par set nahi hai. Aap phone ke offline Notes, Tasks, Reminders aur Finance tools seedha istemal kar sakte hain.',
        ttsSpeechText:
          'فور برو اے آئی سرور چل رہا ہے، لیکن ابھی اے آئی کی اے پی آئی کی سیٹ نہیں ہے۔ آپ آف لائن نوٹس، ریمائنڈرز اور حساب کتاب استعمال کر سکتے ہیں۔',
        detectedLanguage: 'roman_ur',
        robotState: 'Warning',
        requiresConfirmation: false,
        deviceActions: [],
        serverToolRequests: [],
        droppedToolCount: 0
      };
    }

    const systemPrompt = buildSystemPrompt(session, currentDateIso);
    const messages = [
      ...session.turns
        .filter((t): t is typeof t & { role: 'user' | 'assistant' } => t.role === 'user' || t.role === 'assistant')
        .map((t) => ({ role: t.role, content: t.content })),
      { role: 'user' as const, content: userMessage }
    ];

    for (const provider of this.providers) {
      try {
        const raw = await provider.completeJson({ systemPrompt, messages });
        return parseBrainJson(raw, provider.name);
      } catch {
        // Fall through to next provider without leaking credentials
      }
    }

    return {
      status: 'ai_unavailable',
      provider: 'none',
      displayText:
        'Maaf kijiye, is waqt AI service se rabta nahi ho saka. Thori der baad dobara koshish karein, ya offline Notes/Reminders istemal karein.',
      ttsSpeechText:
        'معاف کیجیے، اس وقت اے آئی سروس سے رابطہ نہیں ہو سکا۔ تھوڑی دیر بعد دوبارہ کوشش کریں۔',
      detectedLanguage: 'roman_ur',
      robotState: 'Error',
      requiresConfirmation: false,
      deviceActions: [],
      serverToolRequests: [],
      droppedToolCount: 0
    };
  }
}

export type ChatRole = 'user' | 'assistant' | 'tool';

export interface ChatTurn {
  id: string;
  role: ChatRole;
  content: string;
  language?: 'ur' | 'roman_ur' | 'en';
  timestamp: string;
}

export interface UserPreferences {
  preferredLanguage: 'ur' | 'roman_ur' | 'en';
  voiceSpeed: number;
  voiceEnabled: boolean;
  ownerName?: string;
}

export interface ConversationSession {
  sessionId: string;
  createdAt: string;
  updatedAt: string;
  turns: ChatTurn[];
  preferences: UserPreferences;
}

const DEFAULT_PREFERENCES: UserPreferences = {
  preferredLanguage: 'roman_ur',
  voiceSpeed: 1.0,
  voiceEnabled: true
};

export class InMemorySessionStore {
  private sessions = new Map<string, ConversationSession>();
  private readonly maxTurnsPerSession: number;

  constructor(maxTurnsPerSession = 24) {
    this.maxTurnsPerSession = maxTurnsPerSession;
  }

  getOrCreate(sessionId: string, prefs?: Partial<UserPreferences>): ConversationSession {
    const existing = this.sessions.get(sessionId);
    if (existing) {
      if (prefs) {
        existing.preferences = { ...existing.preferences, ...prefs };
        existing.updatedAt = new Date().toISOString();
      }
      return existing;
    }

    const now = new Date().toISOString();
    const created: ConversationSession = {
      sessionId,
      createdAt: now,
      updatedAt: now,
      turns: [],
      preferences: { ...DEFAULT_PREFERENCES, ...prefs }
    };
    this.sessions.set(sessionId, created);
    return created;
  }

  appendTurn(sessionId: string, turn: Omit<ChatTurn, 'id' | 'timestamp'>): ChatTurn {
    const session = this.getOrCreate(sessionId);
    const entry: ChatTurn = {
      ...turn,
      id: `turn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date().toISOString()
    };
    session.turns.push(entry);
    if (session.turns.length > this.maxTurnsPerSession) {
      session.turns = session.turns.slice(-this.maxTurnsPerSession);
    }
    session.updatedAt = entry.timestamp;
    return entry;
  }

  getSession(sessionId: string): ConversationSession | null {
    return this.sessions.get(sessionId) ?? null;
  }

  deleteSession(sessionId: string): boolean {
    return this.sessions.delete(sessionId);
  }

  clearAll(): void {
    this.sessions.clear();
  }
}

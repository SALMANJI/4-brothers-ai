import { z } from 'zod';
import { AppEnv } from '../config/env.js';
import { GeminiFlashProvider, GroqLlamaProvider, LlmProvider } from './aiBrain.js';
import { ResearchReport, WebResearchService } from './webResearchService.js';

export const YouTubeStudioInputSchema = z.object({
  topic: z.string().min(2).max(250),
  format: z.enum(['short', 'long']).default('long'),
  durationMinutes: z.number().min(0.25).max(60).default(5),
  aspectRatio: z.enum(['16:9', '9:16']).default('16:9'),
  language: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur'),
  style: z.string().min(2).max(120).default('engaging educational storytelling'),
  characterDescription: z.string().max(400).optional(),
  useLiveTrends: z.boolean().default(false)
});

export type YouTubeStudioInput = z.infer<typeof YouTubeStudioInputSchema>;

export const FacebookStudioInputSchema = z.object({
  topic: z.string().min(2).max(250),
  goal: z.enum(['engagement', 'education', 'promotion', 'calendar']).default('engagement'),
  language: z.enum(['ur', 'roman_ur', 'en']).default('roman_ur'),
  includeResearch: z.boolean().default(false),
  daysInCalendar: z.number().int().min(3).max(30).default(7)
});

export type FacebookStudioInput = z.infer<typeof FacebookStudioInputSchema>;

export interface YouTubeScene {
  sceneNumber: number;
  timeRange: string;
  dialogue: string;
  visualPromptEn: string;
  imagePromptEn: string;
  videoPromptEn: string;
  motionInstruction: string;
  effectsInstruction: string;
}

export interface YouTubePackage {
  status: 'ok' | 'ai_unavailable';
  topic: string;
  format: 'short' | 'long';
  durationMinutes: number;
  aspectRatio: '16:9' | '9:16';
  language: 'ur' | 'roman_ur' | 'en';
  style: string;
  trendResearch: ResearchReport | null;
  characterBible: string;
  hooks: string[];
  fullScript: string;
  scenes: YouTubeScene[];
  titles: string[];
  description: string;
  tags: string[];
  hashtags: string[];
  thumbnailConcepts: Array<{ titleOverlay: string; visualDescriptionEn: string }>;
}

export interface FacebookPackage {
  status: 'ok' | 'ai_unavailable';
  topic: string;
  goal: string;
  language: 'ur' | 'roman_ur' | 'en';
  approvalRequiredBeforePublish: true;
  publishingStatus: 'draft_only_requires_meta_oauth_and_owner_approval';
  research: ResearchReport | null;
  postIdeas: string[];
  postDraft: string;
  captions: string[];
  hashtags: string[];
  contentCalendar: Array<{ day: number; theme: string; postHook: string; bestFormat: string }>;
}

export class ContentStudioService {
  private readonly llmProviders: LlmProvider[];

  constructor(
    env: AppEnv,
    private readonly researchService: WebResearchService,
    customProviders?: LlmProvider[]
  ) {
    if (customProviders) {
      this.llmProviders = customProviders;
    } else {
      const list: LlmProvider[] = [];
      if (env.GEMINI_API_KEY) list.push(new GeminiFlashProvider(env.GEMINI_API_KEY));
      if (env.GROQ_API_KEY) list.push(new GroqLlamaProvider(env.GROQ_API_KEY));
      this.llmProviders = list;
    }
  }

  async generateYouTubePackage(input: YouTubeStudioInput): Promise<YouTubePackage> {
    const trendResearch = input.useLiveTrends
      ? await this.researchService.research(`${input.topic} YouTube trending`, 'quick', input.language)
      : null;

    if (this.llmProviders.length === 0) {
      return {
        status: 'ai_unavailable',
        topic: input.topic,
        format: input.format,
        durationMinutes: input.durationMinutes,
        aspectRatio: input.aspectRatio,
        language: input.language,
        style: input.style,
        trendResearch,
        characterBible: input.characterDescription ?? 'Not generated (missing AI key).',
        hooks: [],
        fullScript: 'AI Brain key (GEMINI_API_KEY ya GROQ_API_KEY) backend par missing hai.',
        scenes: [],
        titles: [],
        description: '',
        tags: [],
        hashtags: [],
        thumbnailConcepts: []
      };
    }

    const systemPrompt = `You are 4BRO AI YouTube Production Director.
Generate a complete YouTube production package for:
- Topic: ${input.topic}
- Format: ${input.format} (${input.durationMinutes} min, aspect ratio ${input.aspectRatio})
- Dialogue Language: ${input.language}
- Style: ${input.style}
- Character Consistency Anchor: ${input.characterDescription ?? 'Create a vivid consistent lead character description and reuse it identically in every scene imagePromptEn & videoPromptEn'}
${trendResearch?.status === 'ok' ? `- Verified Trend Research (retrieved ${trendResearch.retrievedAt}): ${JSON.stringify(trendResearch.sources)}` : ''}

RULES:
- Dialogues must be in ${input.language}.
- visualPromptEn, imagePromptEn, videoPromptEn MUST be detailed English prompts keeping the character's appearance, outfit, lighting, and ${input.aspectRatio} framing consistent across all scenes.
- NEVER invent fake trend stats.

Return ONLY valid JSON:
{
  "characterBible": "...",
  "hooks": ["hook 1", "hook 2", "hook 3"],
  "fullScript": "...",
  "scenes": [
    {
      "sceneNumber": 1,
      "timeRange": "00:00 - 00:15",
      "dialogue": "...",
      "visualPromptEn": "...",
      "imagePromptEn": "...",
      "videoPromptEn": "...",
      "motionInstruction": "...",
      "effectsInstruction": "..."
    }
  ],
  "titles": ["..."],
  "description": "...",
  "tags": ["..."],
  "hashtags": ["#..."],
  "thumbnailConcepts": [{ "titleOverlay": "...", "visualDescriptionEn": "..." }]
}`;

    for (const provider of this.llmProviders) {
      try {
        const raw = await provider.completeJson({
          systemPrompt,
          messages: [{ role: 'user', content: `Generate full YouTube package for: ${input.topic}` }]
        });
        const parsed = JSON.parse(raw) as Partial<YouTubePackage>;
        return {
          status: 'ok',
          topic: input.topic,
          format: input.format,
          durationMinutes: input.durationMinutes,
          aspectRatio: input.aspectRatio,
          language: input.language,
          style: input.style,
          trendResearch,
          characterBible: parsed.characterBible ?? '',
          hooks: parsed.hooks ?? [],
          fullScript: parsed.fullScript ?? '',
          scenes: parsed.scenes ?? [],
          titles: parsed.titles ?? [],
          description: parsed.description ?? '',
          tags: parsed.tags ?? [],
          hashtags: parsed.hashtags ?? [],
          thumbnailConcepts: parsed.thumbnailConcepts ?? []
        };
      } catch {
        // try fallback
      }
    }

    return {
      status: 'ai_unavailable',
      topic: input.topic,
      format: input.format,
      durationMinutes: input.durationMinutes,
      aspectRatio: input.aspectRatio,
      language: input.language,
      style: input.style,
      trendResearch,
      characterBible: '',
      hooks: [],
      fullScript: 'AI service temporarily unavailable.',
      scenes: [],
      titles: [],
      description: '',
      tags: [],
      hashtags: [],
      thumbnailConcepts: []
    };
  }

  async generateFacebookPackage(input: FacebookStudioInput): Promise<FacebookPackage> {
    const research = input.includeResearch
      ? await this.researchService.research(
          `${input.topic} Facebook audience monetization insights`,
          'quick',
          input.language
        )
      : null;

    if (this.llmProviders.length === 0) {
      return {
        status: 'ai_unavailable',
        topic: input.topic,
        goal: input.goal,
        language: input.language,
        approvalRequiredBeforePublish: true,
        publishingStatus: 'draft_only_requires_meta_oauth_and_owner_approval',
        research,
        postIdeas: [],
        postDraft: 'AI Brain key (GEMINI_API_KEY ya GROQ_API_KEY) backend par missing hai.',
        captions: [],
        hashtags: [],
        contentCalendar: []
      };
    }

    const systemPrompt = `You are 4BRO AI Facebook Content Strategist.
Create Facebook content in ${input.language} for topic "${input.topic}", goal "${input.goal}", calendar days=${input.daysInCalendar}.
${research?.status === 'ok' ? `Verified Research (retrieved ${research.retrievedAt}): ${JSON.stringify(research.sources)}` : ''}
Return ONLY valid JSON:
{
  "postIdeas": ["..."],
  "postDraft": "...",
  "captions": ["..."],
  "hashtags": ["#..."],
  "contentCalendar": [{ "day": 1, "theme": "...", "postHook": "...", "bestFormat": "Reel|Image|Carousel|Text" }]
}`;

    for (const provider of this.llmProviders) {
      try {
        const raw = await provider.completeJson({
          systemPrompt,
          messages: [{ role: 'user', content: `Generate Facebook content package for: ${input.topic}` }]
        });
        const parsed = JSON.parse(raw) as Partial<FacebookPackage>;
        return {
          status: 'ok',
          topic: input.topic,
          goal: input.goal,
          language: input.language,
          approvalRequiredBeforePublish: true,
          publishingStatus: 'draft_only_requires_meta_oauth_and_owner_approval',
          research,
          postIdeas: parsed.postIdeas ?? [],
          postDraft: parsed.postDraft ?? '',
          captions: parsed.captions ?? [],
          hashtags: parsed.hashtags ?? [],
          contentCalendar: parsed.contentCalendar ?? []
        };
      } catch {
        // try fallback
      }
    }

    return {
      status: 'ai_unavailable',
      topic: input.topic,
      goal: input.goal,
      language: input.language,
      approvalRequiredBeforePublish: true,
      publishingStatus: 'draft_only_requires_meta_oauth_and_owner_approval',
      research,
      postIdeas: [],
      postDraft: 'AI service temporarily unavailable.',
      captions: [],
      hashtags: [],
      contentCalendar: []
    };
  }
}

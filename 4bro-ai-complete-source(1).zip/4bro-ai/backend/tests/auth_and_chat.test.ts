import test from 'node:test';
import assert from 'node:assert/strict';
import { buildServer } from '../src/server.js';
import { loadEnv } from '../src/config/env.js';
import { LlmProvider } from '../src/services/aiBrain.js';

const TEST_TOKEN = 'super-secret-4bro-device-token-123';

function makeTestEnv() {
  return loadEnv({
    NODE_ENV: 'test',
    FOURBRO_DEVICE_TOKEN: TEST_TOKEN,
    GEMINI_API_KEY: '',
    GROQ_API_KEY: ''
  });
}

test('Auth guard rejects missing or wrong device token with 401', async () => {
  const app = await buildServer({ env: makeTestEnv() });

  const noTokenRes = await app.inject({
    method: 'POST',
    url: '/api/v1/chat',
    payload: { sessionId: 'sess-1', message: 'Assalam o Alaikum' }
  });
  assert.equal(noTokenRes.statusCode, 401);

  const wrongTokenRes = await app.inject({
    method: 'POST',
    url: '/api/v1/chat',
    headers: { 'x-4bro-token': 'wrong-token' },
    payload: { sessionId: 'sess-1', message: 'Assalam o Alaikum' }
  });
  assert.equal(wrongTokenRes.statusCode, 401);

  await app.close();
});

test('Chat endpoint returns honest 503 ai_unavailable when no LLM keys configured', async () => {
  const app = await buildServer({ env: makeTestEnv(), chatDeps: { llmProviders: [] } });

  const res = await app.inject({
    method: 'POST',
    url: '/api/v1/chat',
    headers: { 'x-4bro-token': TEST_TOKEN },
    payload: { sessionId: 'sess-missing-key', message: '4BRO hello' }
  });

  assert.equal(res.statusCode, 503);
  const body = res.json();
  assert.equal(body.status, 'ai_unavailable');
  assert.equal(body.provider, 'none');
  assert.equal(body.robotState, 'Warning');

  await app.close();
});

test('AI Brain falls back from failing Gemini to Groq, validates tools, strips TTS markdown, and enforces confirmation on sensitive actions', async () => {
  const failingGemini: LlmProvider = {
    name: 'gemini',
    async completeJson() {
      throw new Error('Simulated 429 rate limit');
    }
  };

  const workingGroq: LlmProvider = {
    name: 'groq',
    async completeJson() {
      return JSON.stringify({
        displayText: 'Ji bilkul! **Waqas** se lene wale 5000 PKR record bhej raha hoon. https://example.com',
        ttsSpeechText: '**Waqas** se lene wale 5000 rupay record kiye ja rahe hain https://example.com',
        detectedLanguage: 'roman_ur',
        robotState: 'Working',
        requiresConfirmation: false,
        toolCalls: [
          {
            tool: 'finance.record',
            args: {
              type: 'RECEIVABLE',
              amount: 5000,
              currency: 'PKR',
              counterparty: 'Waqas',
              category: 'Udhaar'
            }
          },
          {
            tool: 'android.intent',
            args: {
              action: 'SHARE_TEXT',
              target: 'Waqas balance 5000 PKR',
              requiresConfirmation: false
            }
          },
          {
            tool: 'fake.illegal_tool',
            args: { hack: true }
          }
        ]
      });
    }
  };

  const app = await buildServer({
    env: makeTestEnv(),
    chatDeps: { llmProviders: [failingGemini, workingGroq] }
  });

  const res = await app.inject({
    method: 'POST',
    url: '/api/v1/chat',
    headers: { authorization: `Bearer ${TEST_TOKEN}` },
    payload: {
      sessionId: 'sess-waqas',
      message: '4BRO, Waqas se lene wale 5000 paise note karo'
    }
  });

  assert.equal(res.statusCode, 200);
  const body = res.json();
  assert.equal(body.status, 'ok');
  assert.equal(body.provider, 'groq');
  assert.equal(body.droppedToolCount, 1);
  assert.equal(body.deviceActions.length, 2);
  assert.equal(body.deviceActions[0].tool, 'finance.record');
  assert.equal(body.deviceActions[0].args.type, 'RECEIVABLE');
  assert.equal(body.deviceActions[0].args.amount, 5000);
  assert.equal(body.requiresConfirmation, true);
  assert.equal(body.robotState, 'Waiting');
  assert.equal(body.ttsSpeechText.includes('**'), false);
  assert.equal(body.ttsSpeechText.includes('https://'), false);

  // Record verified tool execution result
  const toolRes = await app.inject({
    method: 'POST',
    url: '/api/v1/chat/tool-result',
    headers: { 'x-4bro-token': TEST_TOKEN },
    payload: {
      sessionId: 'sess-waqas',
      tool: 'finance.record',
      status: 'success',
      summary: 'Saved 5000 PKR receivable from Waqas in Room DB.'
    }
  });
  assert.equal(toolRes.statusCode, 200);

  // Inspect session history
  const sessRes = await app.inject({
    method: 'GET',
    url: '/api/v1/sessions/sess-waqas',
    headers: { 'x-4bro-token': TEST_TOKEN }
  });
  assert.equal(sessRes.statusCode, 200);
  assert.equal(sessRes.json().turns.length, 3);

  // Delete session for privacy
  const delRes = await app.inject({
    method: 'DELETE',
    url: '/api/v1/sessions/sess-waqas',
    headers: { 'x-4bro-token': TEST_TOKEN }
  });
  assert.equal(delRes.statusCode, 200);
  assert.equal(delRes.json().deleted, true);

  await app.close();
});

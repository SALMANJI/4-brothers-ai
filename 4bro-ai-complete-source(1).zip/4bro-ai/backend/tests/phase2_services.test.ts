import test from 'node:test';
import assert from 'node:assert/strict';
import { buildServer } from '../src/server.js';
import { loadEnv } from '../src/config/env.js';
import { buildAzureSsml } from '../src/services/speechService.js';
import { SearchBackend } from '../src/services/webResearchService.js';
import { LlmProvider } from '../src/services/aiBrain.js';

const TOKEN = 'phase2-secret-token-999';

function testEnv() {
  return loadEnv({
    NODE_ENV: 'test',
    FOURBRO_DEVICE_TOKEN: TOKEN
  });
}

test('Azure SSML builder selects Pakistani male voice ur-PK-AsadNeural and escapes XML safely', () => {
  const { ssml, voiceName } = buildAzureSsml({
    text: 'Assalam o Alaikum & welcome <4BRO>!',
    language: 'ur-PK',
    rate: 1.1,
    volume: 0.9
  });

  assert.equal(voiceName, 'ur-PK-AsadNeural');
  assert.equal(ssml.includes('ur-PK-AsadNeural'), true);
  assert.equal(ssml.includes('&amp; welcome &lt;4BRO&gt;!'), true);
  assert.equal(ssml.includes('rate="+10%"'), true);
});

test('Speech TTS & STT return honest 503 fallback instructions when keys are missing', async () => {
  const app = await buildServer({ env: testEnv() });

  const ttsRes = await app.inject({
    method: 'POST',
    url: '/api/v1/speech/synthesize',
    headers: { 'x-4bro-token': TOKEN },
    payload: { text: 'Salam dost', language: 'ur-PK' }
  });
  assert.equal(ttsRes.statusCode, 503);
  assert.equal(ttsRes.json().status, 'tts_unavailable');
  assert.equal(ttsRes.json().voiceName, 'ur-PK-AsadNeural');

  const sttRes = await app.inject({
    method: 'POST',
    url: '/api/v1/speech/transcribe',
    headers: { 'x-4bro-token': TOKEN },
    payload: { audioBase64: 'UklGRg==', mimeType: 'audio/wav', languageHint: 'ur' }
  });
  assert.equal(sttRes.statusCode, 503);
  assert.equal(sttRes.json().status, 'stt_unavailable');

  await app.close();
});

test('Web Research returns cited sources, retrieval timestamp, and never fabricates links', async () => {
  const mockSearch: SearchBackend = {
    name: 'tavily',
    async search() {
      return [
        {
          id: 1,
          title: 'Pakistan Tech Exports Report 2026',
          url: 'https://example.org/pk-tech-2026',
          snippet: 'IT exports grew 24% year-over-year in Q3 2026.',
          publishedDate: '2026-10-15'
        },
        {
          id: 2,
          title: 'Developer Opinion Blog',
          url: 'https://example.org/blog',
          snippet: 'AI startups might double next year.',
          publishedDate: null
        }
      ];
    }
  };

  const mockLlm: LlmProvider = {
    name: 'gemini',
    async completeJson() {
      return JSON.stringify({
        summary: 'Pakistan IT exports rose 24% in Q3 2026 [1].',
        verifiedFacts: ['IT exports grew 24% in Q3 2026 [1]'],
        opinionsAndClaims: ['Startups might double next year [2]'],
        uncertainties: ['Blog post [2] is speculative']
      });
    }
  };

  const app = await buildServer({
    env: testEnv(),
    researchDeps: { searchBackends: [mockSearch], llmProvider: mockLlm }
  });

  const res = await app.inject({
    method: 'POST',
    url: '/api/v1/research/search',
    headers: { 'x-4bro-token': TOKEN },
    payload: { query: 'Pakistan IT exports 2026', depth: 'quick', language: 'roman_ur' }
  });

  assert.equal(res.statusCode, 200);
  const body = res.json();
  assert.equal(body.status, 'ok');
  assert.equal(body.sources.length, 2);
  assert.equal(body.sources[0].url, 'https://example.org/pk-tech-2026');
  assert.equal(typeof body.retrievedAt, 'string');
  assert.equal(body.exportMarkdown.includes('https://example.org/pk-tech-2026'), true);
  assert.equal(body.uncertainties.length >= 1, true);

  await app.close();
});

test('YouTube Studio and Facebook Manager generate complete structured packages with approval safety', async () => {
  const mockLlm: LlmProvider = {
    name: 'gemini',
    async completeJson(input) {
      if (input.systemPrompt.includes('YouTube Production Director')) {
        return JSON.stringify({
          characterBible: '26yo Pakistani tech host in navy hoodie inside neon studio',
          hooks: ['Aaj main aapko woh AI secret dikhaunga jo kisi ne nahi bataya!'],
          fullScript: 'Salam dosto! Aaj hum AI assistant banana seekhenge...',
          scenes: [
            {
              sceneNumber: 1,
              timeRange: '00:00 - 00:10',
              dialogue: 'Salam dosto! Kya aap apna AI dost banana chahte hain?',
              visualPromptEn: '26yo Pakistani tech host in navy hoodie inside neon studio speaking to camera',
              imagePromptEn: 'Cinematic 9:16 portrait of 26yo Pakistani tech host in navy hoodie, glowing cyan studio',
              videoPromptEn: 'Smooth push-in shot of host smiling and gesturing towards floating holographic phone',
              motionInstruction: 'Slow 5% camera push-in',
              effectsInstruction: 'Subtle cyan particle glow'
            }
          ],
          titles: ['Apna Personal AI Assistant Kaise Banayein'],
          description: 'Complete guide to building 4BRO AI',
          tags: ['4bro ai', 'urdu ai'],
          hashtags: ['#4BROAI', '#UrduTech'],
          thumbnailConcepts: [{ titleOverlay: 'APNA AI DOST!', visualDescriptionEn: 'Host pointing at glowing blue robot' }]
        });
      }
      return JSON.stringify({
        postIdeas: ['Behind the scenes of 4BRO AI'],
        postDraft: 'Dosto milte hain 4BRO AI se — aapka apna smart dost!',
        captions: ['Smart kaam, asaan zindagi!'],
        hashtags: ['#4BROAI', '#PakistanTech'],
        contentCalendar: [
          { day: 1, theme: 'Intro', postHook: 'Mera naya AI assistant!', bestFormat: 'Reel' }
        ]
      });
    }
  };

  const app = await buildServer({
    env: testEnv(),
    contentDeps: { llmProviders: [mockLlm], searchBackends: [] }
  });

  const ytRes = await app.inject({
    method: 'POST',
    url: '/api/v1/content/youtube',
    headers: { 'x-4bro-token': TOKEN },
    payload: {
      topic: 'Build Personal AI Assistant',
      format: 'short',
      durationMinutes: 1,
      aspectRatio: '9:16',
      language: 'roman_ur',
      style: 'energetic'
    }
  });
  assert.equal(ytRes.statusCode, 200);
  const yt = ytRes.json();
  assert.equal(yt.aspectRatio, '9:16');
  assert.equal(yt.scenes.length, 1);
  assert.equal(yt.hooks.length, 1);

  const fbRes = await app.inject({
    method: 'POST',
    url: '/api/v1/content/facebook',
    headers: { 'x-4bro-token': TOKEN },
    payload: {
      topic: '4BRO AI Launch',
      goal: 'engagement',
      language: 'roman_ur'
    }
  });
  assert.equal(fbRes.statusCode, 200);
  const fb = fbRes.json();
  assert.equal(fb.approvalRequiredBeforePublish, true);
  assert.equal(fb.contentCalendar.length, 1);

  await app.close();
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { buildServer } from '../src/server.js';
import { loadEnv } from '../src/config/env.js';

test('GET /health returns ok status and honest capability reporting', async () => {
  const env = loadEnv({
    NODE_ENV: 'test',
    GEMINI_API_KEY: 'test-gemini-placeholder',
    GROQ_API_KEY: '',
    AZURE_SPEECH_KEY: '',
    TAVILY_API_KEY: '',
    SERPER_API_KEY: ''
  });

  const app = await buildServer({ env });
  const res = await app.inject({
    method: 'GET',
    url: '/health'
  });

  assert.equal(res.statusCode, 200);
  const body = res.json();
  assert.equal(body.status, 'ok');
  assert.equal(body.service, '4bro-ai-backend');
  assert.equal(body.capabilities.aiBrainPrimary, 'configured');
  assert.equal(body.capabilities.aiBrainFallback, 'missing_key');
  assert.equal(body.capabilities.ttsAzureNeural, 'missing_key');
  assert.equal(body.capabilities.webResearch, 'missing_key');

  await app.close();
});
